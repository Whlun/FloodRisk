/**
 * 综合态势 · 地图「搜索」统一点位数据集
 * 聚合：设施管理、生态整治、应急协同、系统管理 四个原型中的演示数据（与各自源表字段语义一致，不接后端）。
 */
import {
  pumpStationData,
  outletData,
  plantData,
} from '../韶山水环境设施管理系统/facility-points-data';
import { initialRiverSectionData } from '../生态整治/riverChiefDb4401';
import { PARK_MAPLIBRE_DEFAULT_CENTER } from '../韶山水环境系统管理/park-boundary-maplibre';
import { ZHT_MONITORING_POI_DEMO } from './zhtPoiMonitoringDemo';

/** 来源项目（与产品口径一致） */
export type ZhtSearchSourceProject = '设施管理' | '生态整治' | '应急协同' | '系统管理';

/** 统一查询/导出用的一条「点位」 */
export interface ZhtUnifiedSearchPoint {
  /** 全局唯一键（跨项目拼接） */
  id: string;
  /** 业务主键或编码（与源台账一致时可反查） */
  code: string;
  name: string;
  /** 设施类型 / 业务类型（下拉筛选用） */
  pointType: string;
  status: string;
  region: string;
  lng: number;
  lat: number;
  sourceProject: ZhtSearchSourceProject;
}

/** 与应急协同原型 `initialEmergencyEvents` 前两条一致（避免整包引入 index.tsx） */
const EMERGENCY_DEMO_EVENTS = [
  {
    id: 'evt-1',
    eventCode: '水应〔2025〕0312-01',
    eventTitle: '湘江湘潭段不明油污带漂移',
    region: '清溪镇',
    longitude: '112.942000',
    latitude: '27.831000',
    disposalStatus: '现场处置',
  },
  {
    id: 'evt-2',
    eventCode: '水应〔2025〕0128-02',
    eventTitle: '韶山河流域暴雨后面源高浊度冲击',
    region: '银田镇',
    longitude: '112.526000',
    latitude: '27.915000',
    disposalStatus: '后期跟踪',
  },
] as const;

function inferPumpRegion(r: (typeof pumpStationData)[0]): string {
  if (r.addr.includes('南环')) return '杨林乡';
  if (r.name.includes('南部')) return '杨林乡';
  return '高新区';
}

function inferOutletRegion(r: (typeof outletData)[0]): string {
  if (r.name.includes('韶河')) return '韶山乡';
  return '高新区';
}

function inferPlantRegion(_r: (typeof plantData)[0]): string {
  return '高新区';
}

function normalizePumpStatus(s: string): string {
  if (s === '1') return '运行';
  if (s === '2') return '维护';
  return s;
}

function normalizePlantStatus(s: string): string {
  if (s === '1') return '运行';
  return s;
}

function addvcdToRegionLabel(addvcd: string): string {
  if (addvcd.startsWith('430104')) return '岳麓区';
  if (addvcd.startsWith('430181')) return '浏阳市';
  if (addvcd.startsWith('430121')) return '长沙县';
  if (addvcd.startsWith('430112')) return '望城区';
  return '其它行政区';
}

/** 构建全量演示点位（模块级单例，供条件/空间查询共用） */
export function getZhtUnifiedSearchPoints(): ZhtUnifiedSearchPoint[] {
  const out: ZhtUnifiedSearchPoint[] = [];

  for (const r of pumpStationData) {
    out.push({
      id: `zht-fac-pump-${r.id}`,
      code: r.id,
      name: r.name,
      pointType: '泵站',
      status: normalizePumpStatus(r.status),
      region: inferPumpRegion(r),
      lng: r.x,
      lat: r.y,
      sourceProject: '设施管理',
    });
  }
  for (const r of outletData) {
    out.push({
      id: `zht-fac-outlet-${r.id}`,
      code: r.id,
      name: r.name,
      pointType: '排口',
      status: r.status,
      region: inferOutletRegion(r),
      lng: r.x,
      lat: r.y,
      sourceProject: '设施管理',
    });
  }
  for (const r of plantData) {
    out.push({
      id: `zht-fac-plant-${r.id}`,
      code: r.id,
      name: r.name,
      pointType: '污水厂',
      status: normalizePlantStatus(r.status),
      region: inferPlantRegion(r),
      lng: r.x,
      lat: r.y,
      sourceProject: '设施管理',
    });
  }

  /** 与地图监测 DOM 圆点同源，避免查询结果 WebGL 点与监测 Marker 叠在一起 */
  for (const mon of ZHT_MONITORING_POI_DEMO) {
    const statusLabel =
      mon.pointState === 'normal' ? '正常' : mon.pointState === 'alarm' ? '报警' : mon.pointState === 'offline' ? '离线' : '普通';
    out.push({
      id: `zht-mon-${mon.id}`,
      code: mon.id,
      name: mon.title,
      pointType: '水质监测站',
      status: statusLabel,
      region: '高新区',
      lng: mon.lng,
      lat: mon.lat,
      sourceProject: '设施管理',
    });
  }

  for (const row of initialRiverSectionData) {
    const lng = (row.startLgtd + row.endLgtd) / 2;
    const lat = (row.startLttd + row.endLttd) / 2;
    out.push({
      id: `zht-river-sec-${row.key}`,
      code: row.sectionId,
      name: row.sectionName,
      pointType: '责任河段',
      status: row.remarks?.trim() ? row.remarks : '在管',
      region: addvcdToRegionLabel(row.addvcd),
      lng,
      lat,
      sourceProject: '生态整治',
    });
  }

  for (const e of EMERGENCY_DEMO_EVENTS) {
    const lng = Number.parseFloat(e.longitude);
    const lat = Number.parseFloat(e.latitude);
    if (!Number.isFinite(lng) || !Number.isFinite(lat)) continue;
    out.push({
      id: `zht-emg-${e.id}`,
      code: e.eventCode,
      name: e.eventTitle,
      pointType: '应急事件',
      status: e.disposalStatus,
      region: e.region,
      lng,
      lat,
      sourceProject: '应急协同',
    });
  }

  const [plng, plat] = PARK_MAPLIBRE_DEFAULT_CENTER;
  /** 系统管理 · 水利设施七类演示点（`pointType` 与 `zhtWaterEnvPoiMeta` 子图层映射一致） */
  const SYS_HYDRO_DEMO_ROWS: {
    id: string;
    code: string;
    name: string;
    pointType: string;
    lng: number;
    lat: number;
  }[] = [
    { id: 'zht-sys-hydro-zhaba-1', code: 'ZHABA-001', name: '韶河闸坝演示点', pointType: '闸坝', lng: plng - 0.012, lat: plat + 0.004 },
    { id: 'zht-sys-hydro-diba-1', code: 'DIBA-001', name: '堤防巡查演示点', pointType: '堤坝', lng: plng + 0.011, lat: plat - 0.005 },
    {
      id: 'zht-sys-park-default-view',
      code: 'SYS-PARK-DEFAULT-VIEW',
      name: '工业园区地图默认视野锚点',
      pointType: '水库',
      lng: plng,
      lat: plat,
    },
    {
      id: 'zht-sys-park-config-sample',
      code: 'SYS-PARK-CFG-001',
      name: '园区边界绘制配置样例点',
      pointType: '水库',
      lng: plng + 0.008,
      lat: plat + 0.006,
    },
    { id: 'zht-sys-hydro-shuizha-1', code: 'SZ-001', name: '渠首水闸演示点', pointType: '水闸', lng: plng - 0.006, lat: plat - 0.009 },
    { id: 'zht-sys-hydro-weiqu-1', code: 'WQ-001', name: '联圩防护演示点', pointType: '圩区', lng: plng + 0.014, lat: plat + 0.008 },
    { id: 'zht-sys-hydro-yandi-1', code: 'YD-001', name: '堰体加固演示点', pointType: '堰堤', lng: plng - 0.015, lat: plat - 0.004 },
    { id: 'zht-sys-hydro-shantang-1', code: 'ST-001', name: '山塘除险演示点', pointType: '山塘', lng: plng + 0.005, lat: plat - 0.012 },
  ];
  for (const r of SYS_HYDRO_DEMO_ROWS) {
    out.push({
      id: r.id,
      code: r.code,
      name: r.name,
      pointType: r.pointType,
      status: '演示',
      region: '高新区',
      lng: r.lng,
      lat: r.lat,
      sourceProject: '系统管理',
    });
  }

  return out;
}

/** 与全量演示数据一致；每次调用重建（数据量小，避免 HMR 后旧缓存缺监测站等项） */
export function getZhtUnifiedSearchPointsCached(): ZhtUnifiedSearchPoint[] {
  return getZhtUnifiedSearchPoints();
}

/** Haversine 球面距离（千米） */
export function haversineKm(aLng: number, aLat: number, bLng: number, bLat: number): number {
  const R = 6371;
  const dLat = ((bLat - aLat) * Math.PI) / 180;
  const dLng = ((bLng - aLng) * Math.PI) / 180;
  const lat1 = (aLat * Math.PI) / 180;
  const lat2 = (bLat * Math.PI) / 180;
  const s1 = Math.sin(dLat / 2);
  const s2 = Math.sin(dLng / 2);
  const h = s1 * s1 + Math.cos(lat1) * Math.cos(lat2) * s2 * s2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
}

export function pointInLngLatBbox(
  lng: number,
  lat: number,
  minLng: number,
  minLat: number,
  maxLng: number,
  maxLat: number,
): boolean {
  return lng >= minLng && lng <= maxLng && lat >= minLat && lat <= maxLat;
}

/** 与地图设施 DOM 圆点 kind 一致（泵站 / 排口 / 污水厂） */
export type ZhtFacilityMapKind = 'pump' | 'outlet' | 'plant';

/**
 * 解析统一点位 id 是否为「设施管理」地图台账点（与 `facility-points-data` 主键拼接规则一致）。
 * 例如 `zht-fac-pump-PS2025040700001` → pump + PS2025040700001。
 */
export function parseZhtFacilityUnifiedSearchId(
  unifiedId: string,
): { kind: ZhtFacilityMapKind; rawId: string } | null {
  const m = unifiedId.match(/^zht-fac-(pump|outlet|plant)-(.+)$/);
  if (!m) return null;
  return { kind: m[1] as ZhtFacilityMapKind, rawId: m[2] };
}

/** 统一点位 id 是否为地图监测 DOM 圆点（`zht-mon-${ZHT_MONITORING_POI_DEMO.id}`） */
export function parseZhtMonitorUnifiedSearchId(unifiedId: string): { rawMonId: string } | null {
  const m = unifiedId.match(/^zht-mon-(.+)$/);
  if (!m) return null;
  return { rawMonId: m[1] };
}

/** 与左侧指标四段标题对应，用于搜索命中后高亮对应看板区块 */
export type ZhtLeftRailSectionTitle = '管网概况' | '动态感知' | '水利设施' | '应急协同';

/** 由点位来源/类型映射到左侧某一指标段（演示逻辑） */
export function mapSearchPointToLeftRailSection(p: ZhtUnifiedSearchPoint): ZhtLeftRailSectionTitle {
  if (p.sourceProject === '应急协同') return '应急协同';
  if (p.sourceProject === '生态整治') return '水利设施';
  if (p.sourceProject === '系统管理') return '管网概况';
  return '动态感知';
}
