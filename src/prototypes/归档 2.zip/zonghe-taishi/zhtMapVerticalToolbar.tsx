/**
 * 综合态势 · 地图左侧纵向工具条（与设计稿 **13** 项一致；**图层控制** 为树形折叠 + 勾选，说明文案在标题后 **?** 的 **`Tooltip`** 内（`zhtLayerControlPopover`）；**POI提示配置** 仅影响已显示点位上的 HTML 提示板，**水环境 POI** 显隐以图层为准；Lucide 线框图标占位）
 */
import React, { useCallback, useEffect, useState } from 'react';
import { Button, Checkbox, message, Popover, Select, Tooltip } from 'antd';
import type { ZhtPoiHintFontPreset } from './zhtPoiHintFont';
import { ZHT_POI_HINT_FONT_OPTIONS } from './zhtPoiHintFont';
import { ZhtLayerControlPopover } from './zhtLayerControlPopover';
import type { ZhtLayerControlState } from './zhtLayerControlState';
import type { Map } from 'maplibre-gl';
import {
  Compass,
  ImageDown,
  Layers,
  LocateFixed,
  Maximize2,
  MessageSquare,
  Minus,
  Palette,
  Pencil,
  Plus,
  Ruler,
  Search,
  Video,
  View,
} from 'lucide-react';

const ICON_SIZE = 18;
const ICON_STROKE = 1.75;

function IconWrap({ children }: { children: React.ReactNode }) {
  return <span className="zht-map-tool-icon">{children}</span>;
}

export interface ZhtMapVerticalToolbarProps {
  mapRef: React.MutableRefObject<Map | null>;
  /** 进入全屏的 DOM（地图栈容器，含工具条） */
  fullscreenTargetRef: React.RefObject<HTMLElement | null>;
  /** 打开「地图搜索」弹窗；未传入时搜索按钮为占位提示 */
  onSearchClick?: () => void;
  layerControl: ZhtLayerControlState;
  onLayerControlChange: (patch: Partial<ZhtLayerControlState>) => void;
  /** 设施类 POI 提示板：标题显示（关则整板不展示） */
  poiFacilityTitle: boolean;
  onPoiFacilityTitleChange: (v: boolean) => void;
  /** 监测类 POI 提示板：标题 / 多指标数值 */
  poiMonitorTitle: boolean;
  poiMonitorValues: boolean;
  onPoiMonitorTitleChange: (v: boolean) => void;
  onPoiMonitorValuesChange: (v: boolean) => void;
  /** 设施类标题字号档位 */
  poiFacilityTitleFont: ZhtPoiHintFontPreset;
  onPoiFacilityTitleFontChange: (v: ZhtPoiHintFontPreset) => void;
  /** 监测类标题字号档位 */
  poiMonitorTitleFont: ZhtPoiHintFontPreset;
  onPoiMonitorTitleFontChange: (v: ZhtPoiHintFontPreset) => void;
  /** 监测类数值区字号档位 */
  poiMonitorValuesFont: ZhtPoiHintFontPreset;
  onPoiMonitorValuesFontChange: (v: ZhtPoiHintFontPreset) => void;
  /** 将 POI 提示三项勾选与三档字号恢复为页面默认值 */
  onPoiHintsReset?: () => void;
  /** 与地图初始视图一致（与园区常量同源，由父组件传入） */
  defaultCenter: [number, number];
  defaultZoom: number;
}

export const ZhtMapVerticalToolbar: React.FC<ZhtMapVerticalToolbarProps> = ({
  mapRef,
  fullscreenTargetRef,
  onSearchClick,
  layerControl,
  onLayerControlChange,
  poiFacilityTitle,
  onPoiFacilityTitleChange,
  poiMonitorTitle,
  poiMonitorValues,
  onPoiMonitorTitleChange,
  onPoiMonitorValuesChange,
  poiFacilityTitleFont,
  onPoiFacilityTitleFontChange,
  poiMonitorTitleFont,
  onPoiMonitorTitleFontChange,
  poiMonitorValuesFont,
  onPoiMonitorValuesFontChange,
  onPoiHintsReset,
  defaultCenter,
  defaultZoom,
}) => {
  const [layerPopoverOpen, setLayerPopoverOpen] = useState(false);
  const [poiPopoverOpen, setPoiPopoverOpen] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);

  useEffect(() => {
    const onFs = () => setFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', onFs);
    return () => document.removeEventListener('fullscreenchange', onFs);
  }, []);

  const getMap = useCallback(() => mapRef.current, [mapRef]);

  const toolBtn = (
    label: string,
    onClick: () => void,
    node: React.ReactNode,
    extraClass = '',
  ) => (
    <Tooltip title={label} placement="right">
      <button
        type="button"
        className={`zht-map-tool-btn${extraClass ? ` ${extraClass}` : ''}`}
        aria-label={label}
        onClick={onClick}
      >
        {node}
      </button>
    </Tooltip>
  );

  const layerContent = (
    <ZhtLayerControlPopover value={layerControl} onChange={onLayerControlChange} />
  );

  const poiContent = (
    <div className="zht-map-poi-popover" onClick={e => e.stopPropagation()}>
      <div className="zht-map-poi-popover__head">
        <span className="zht-map-poi-popover__head-title">POI提示配置</span>
        {onPoiHintsReset ? (
          <Button type="link" size="small" className="zht-map-poi-popover__reset" onClick={onPoiHintsReset}>
            恢复默认
          </Button>
        ) : null}
      </div>
      <div className="zht-map-poi-popover__group">
        <div className="zht-map-poi-popover__group-title">设施类</div>
        <div className="zht-map-poi-popover__row zht-map-poi-popover__row--with-font">
          <Checkbox checked={poiFacilityTitle} onChange={e => onPoiFacilityTitleChange(e.target.checked)}>
            标题显示
          </Checkbox>
          <Select<ZhtPoiHintFontPreset>
            size="small"
            className="zht-map-poi-popover__font-select"
            aria-label="设施标题字体"
            value={poiFacilityTitleFont}
            options={ZHT_POI_HINT_FONT_OPTIONS}
            onChange={onPoiFacilityTitleFontChange}
          />
        </div>
      </div>
      <div className="zht-map-poi-popover__group">
        <div className="zht-map-poi-popover__group-title">监测类</div>
        <div className="zht-map-poi-popover__row zht-map-poi-popover__row--with-font">
          <Checkbox checked={poiMonitorTitle} onChange={e => onPoiMonitorTitleChange(e.target.checked)}>
            标题显示
          </Checkbox>
          <Select<ZhtPoiHintFontPreset>
            size="small"
            className="zht-map-poi-popover__font-select"
            aria-label="监测标题字体"
            value={poiMonitorTitleFont}
            options={ZHT_POI_HINT_FONT_OPTIONS}
            onChange={onPoiMonitorTitleFontChange}
          />
        </div>
        <div className="zht-map-poi-popover__row zht-map-poi-popover__row--with-font">
          <Checkbox checked={poiMonitorValues} onChange={e => onPoiMonitorValuesChange(e.target.checked)}>
            数值显示
          </Checkbox>
          <Select<ZhtPoiHintFontPreset>
            size="small"
            className="zht-map-poi-popover__font-select"
            aria-label="监测数值字体"
            value={poiMonitorValuesFont}
            options={ZHT_POI_HINT_FONT_OPTIONS}
            onChange={onPoiMonitorValuesFontChange}
          />
        </div>
      </div>
    </div>
  );

  return (
    <aside className="zht-map-vertical-toolbar" aria-label="地图工具条">
      {toolBtn('搜索', () => (onSearchClick ? onSearchClick() : message.info('搜索：功能待与设计对接')), (
        <IconWrap>
          <Search size={ICON_SIZE} strokeWidth={ICON_STROKE} />
        </IconWrap>
      ))}
      <Tooltip title="POI提示配置" placement="right">
        <Popover
          trigger="click"
          placement="rightTop"
          open={poiPopoverOpen}
          onOpenChange={setPoiPopoverOpen}
          content={poiContent}
        >
          <button
            type="button"
            className={`zht-map-tool-btn${poiPopoverOpen ? ' zht-map-tool-btn--on' : ''}`}
            aria-label="POI提示配置"
            aria-expanded={poiPopoverOpen}
          >
            <IconWrap>
              <MessageSquare size={ICON_SIZE} strokeWidth={ICON_STROKE} />
            </IconWrap>
          </button>
        </Popover>
      </Tooltip>
      <Tooltip title="图层控制" placement="right">
        <Popover
          trigger="click"
          placement="rightTop"
          open={layerPopoverOpen}
          onOpenChange={setLayerPopoverOpen}
          content={layerContent}
          overlayInnerStyle={{
            padding: '6px 4px 10px',
            maxWidth: 392,
            maxHeight: 'min(72vh, 580px)',
            overflowY: 'auto',
          }}
        >
          <button
            type="button"
            className={`zht-map-tool-btn${layerPopoverOpen ? ' zht-map-tool-btn--on' : ''}`}
            aria-label="图层控制"
            aria-expanded={layerPopoverOpen}
          >
            <IconWrap>
              <Layers size={ICON_SIZE} strokeWidth={ICON_STROKE} />
            </IconWrap>
          </button>
        </Popover>
      </Tooltip>
      {toolBtn('视频点位', () => message.info('视频点位：功能待与设计对接'), (
        <IconWrap>
          <Video size={ICON_SIZE} strokeWidth={ICON_STROKE} />
        </IconWrap>
      ))}
      {toolBtn('地图样式', () => message.info('地图样式：功能待与设计对接'), (
        <IconWrap>
          <Palette size={ICON_SIZE} strokeWidth={ICON_STROKE} />
        </IconWrap>
      ))}
      {toolBtn('地图标注', () => message.info('地图标注：功能待与设计对接'), (
        <IconWrap>
          <Pencil size={ICON_SIZE} strokeWidth={ICON_STROKE} />
        </IconWrap>
      ))}
      {toolBtn('地图视角', () => message.info('地图视角：功能待与设计对接'), (
        <IconWrap>
          <View size={ICON_SIZE} strokeWidth={ICON_STROKE} />
        </IconWrap>
      ))}
      {toolBtn('地图视图导出', () => message.info('地图视图导出：功能待与设计对接'), (
        <IconWrap>
          <ImageDown size={ICON_SIZE} strokeWidth={ICON_STROKE} />
        </IconWrap>
      ))}
      {toolBtn('量尺工具', () => message.info('量尺工具：功能待与设计对接'), (
        <IconWrap>
          <Ruler size={ICON_SIZE} strokeWidth={ICON_STROKE} />
        </IconWrap>
      ))}
      {toolBtn(fullscreen ? '退出全屏' : '地图全屏', () => {
        const el = fullscreenTargetRef.current;
        if (!el) {
          message.warning('未找到全屏容器');
          return;
        }
        if (!document.fullscreenElement) {
          void el.requestFullscreen?.().catch(() => message.error('当前环境无法全屏'));
        } else {
          void document.exitFullscreen?.().catch(() => {});
        }
      }, (
        <IconWrap>
          <Maximize2 size={ICON_SIZE} strokeWidth={ICON_STROKE} />
        </IconWrap>
      ))}
      {toolBtn('地图中心恢复默认位置', () => {
        const map = getMap();
        if (!map) return;
        map.flyTo({
          center: defaultCenter,
          zoom: defaultZoom,
          bearing: 0,
          pitch: 0,
          essential: true,
        });
      }, (
        <IconWrap>
          <LocateFixed size={ICON_SIZE} strokeWidth={ICON_STROKE} />
        </IconWrap>
      ))}
      <div className="zht-map-tool-zoom" role="group" aria-label="地图缩放">
        {toolBtn(
          '放大',
          () => {
            const map = getMap();
            map?.zoomIn({ duration: 220 });
          },
          (
            <IconWrap>
              <Plus size={ICON_SIZE} strokeWidth={ICON_STROKE} />
            </IconWrap>
          ),
          'zht-map-tool-btn--zoom',
        )}
        {toolBtn(
          '缩小',
          () => {
            const map = getMap();
            map?.zoomOut({ duration: 220 });
          },
          (
            <IconWrap>
              <Minus size={ICON_SIZE} strokeWidth={ICON_STROKE} />
            </IconWrap>
          ),
          'zht-map-tool-btn--zoom',
        )}
      </div>
      {toolBtn('指北（复位旋转）', () => {
        const map = getMap();
        if (!map) return;
        map.resetNorth({ duration: 320 });
      }, (
        <IconWrap>
          <Compass size={ICON_SIZE} strokeWidth={ICON_STROKE} />
        </IconWrap>
      ))}
    </aside>
  );
};
