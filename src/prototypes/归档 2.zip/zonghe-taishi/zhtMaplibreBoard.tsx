/**
 * 综合态势 · MapLibre 地图区（与页面其它 UI 解耦）
 *
 * 规范来源：https://github.com/maplibre/maplibre-agent-skills
 * 本仓库同步副本：`skills-lock.json` → `maplibre/maplibre-agent-skills` → `.agents/skills/maplibre-*`
 *
 * 底图与 **工业园区** `park-boundary-maplibre.tsx` 严格同源：仅 **OpenFreeMap Liberty**（`PARK_MAPLIBRE_STYLE_URL`），不引入 Esri、OSM、Carto 等其它底图来源。中心与默认缩放与园区导出常量一致。**分析看板**：全量 **设施 / 监测** DOM 圆点 + 可选 **POI 提示板**（图层控制 / POI 提示配置）；有条件/空间查询结果时，命中项叠 **橙圈+序号**，非台账点用 **WebGL 橙点**。**地图搜索面板打开**（`mapSearchPanelOpen`）：默认隐藏全量台账/监测；有 **`searchMapOverlay.results`** 时 **仅结果**：**设施 / 监测** 叠 **POI 提示板 + 台账圆点（命中橙态）**；其它统一点位在开启设施类提示标题时叠 **简要标题 + 橙点**，否则 **居中橙色序号 Marker**。**例外**：**空间 + 数据原点 + 尚无覆盖层**（`mapSearchShowDefaultPoiMarkers`）时恢复全量 DOM/POI。此「仅结果」模式 **不**叠 WebGL 结果点。空间查询另绘测地圆与原点。`spatialMapPickActive` 时选原点穿透 DOM。点位详情 **Modal** 的 **`styles` / 宽度** 与 **`韶山水环境设施管理系统/index.tsx`** 列表详情对齐；非台账内容用 **`detail-section` + `Descriptions`**（`facility-detail-panel.css`）。
 */

import React, { useCallback, useEffect, useRef, useState } from 'react';
import type { DescriptionsProps } from 'antd';
import { Descriptions, Modal } from 'antd';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import {
  PumpDetailContent,
  OutletDetailContent,
  PlantDetailContent,
} from '../韶山水环境设施管理系统/facility-pump-outlet-plant-details';
import {
  pumpStationData,
  outletData,
  plantData,
} from '../韶山水环境设施管理系统/facility-points-data';
import {
  PARK_MAPLIBRE_STYLE_URL,
  PARK_MAPLIBRE_DEFAULT_CENTER,
  PARK_MAPLIBRE_DEFAULT_ZOOM,
} from '../韶山水环境系统管理/park-boundary-maplibre';
import { ZhtMapVerticalToolbar } from './zhtMapVerticalToolbar';
import {
  ZHT_POI_HINT_UI_DEFAULTS,
  zhtPoiHintFontPx,
  type ZhtPoiHintFontPreset,
} from './zhtPoiHintFont';
import {
  ZHT_MONITORING_POI_DEMO,
  zhtMonitorMetricNumClass,
  type ZhtMonitoringPoiDemo,
} from './zhtPoiMonitoringDemo';
import { ZHT_ADMIN_DIVISION_HINTS_DEMO, type ZhtAdminDivisionHintDemo } from './zhtAdminDivisionHints';
import { waterEnvPoiLayerControlSlice, type ZhtLayerControlState } from './zhtLayerControlState';
import {
  deriveDisplayStateForUnifiedPoint,
  deriveFacilityDisplayState,
  facilityPassesWaterEnvLayer,
  getWaterEnvCategoryForUnifiedPoint,
  monitorDemoPassesWaterEnvLayer,
  monitorPointStateToDisplay,
  unifiedPointPassesWaterEnvLayer,
  type ZhtPoiDisplayState,
  type ZhtWaterEnvCategoryId,
} from './zhtWaterEnvPoiMeta';
import { appendWaterEnvPoiDotIcon } from './zhtWaterEnvPoiDotIcons';
import {
  getZhtUnifiedSearchPointsCached,
  parseZhtFacilityUnifiedSearchId,
  parseZhtMonitorUnifiedSearchId,
  type ZhtUnifiedSearchPoint,
} from './zhtSearchUnifiedData';
import {
  buildGeodesicCirclePolygon,
  spatialHitPropsToUnifiedPoint,
  type ZhtSearchMapOverlay,
  type ZhtSpatialQueryPreview,
} from './zhtSpatialSearchGeo';

/** 空间查询地图覆盖（圆、原点、序号点） */
const SRC_SR_CIRCLE = 'zht-src-spatial-circle';
const SRC_SR_ORIGIN = 'zht-src-spatial-origin';
const SRC_SR_RESULTS = 'zht-src-spatial-results';
const LYR_SR_FILL = 'zht-lyr-spatial-circle-fill';
const LYR_SR_LINE = 'zht-lyr-spatial-circle-line';
const LYR_SR_ORIGIN = 'zht-lyr-spatial-origin';
const LYR_SR_RES_PT = 'zht-lyr-spatial-res-pt';
const LYR_SR_RES_TX = 'zht-lyr-spatial-res-txt';

/** 与 OpenFreeMap Liberty 的 glyphs 栈一致，避免未声明 text-font 时回退字体发虚、边缘锯齿感重 */
const SPATIAL_RES_TEXT_FONT: string[] = ['Noto Sans Bold'];

const SPATIAL_LAYERS = [LYR_SR_RES_TX, LYR_SR_RES_PT, LYR_SR_ORIGIN, LYR_SR_LINE, LYR_SR_FILL] as const;
const SPATIAL_SOURCES = [SRC_SR_RESULTS, SRC_SR_ORIGIN, SRC_SR_CIRCLE] as const;

/** 空间要素查询「仅预览」图层（与查询结果覆盖 id 分离，避免互相 remove） */
const SRC_SQ_PREVIEW_CIRCLE = 'zht-src-spatial-query-preview-circle';
const SRC_SQ_PREVIEW_ORIGIN = 'zht-src-spatial-query-preview-origin';
const LYR_SQ_PREVIEW_FILL = 'zht-lyr-spatial-query-preview-fill';
const LYR_SQ_PREVIEW_LINE = 'zht-lyr-spatial-query-preview-line';
const LYR_SQ_PREVIEW_ORIGIN = 'zht-lyr-spatial-query-preview-origin';
const SQ_PREVIEW_LAYERS = [LYR_SQ_PREVIEW_ORIGIN, LYR_SQ_PREVIEW_LINE, LYR_SQ_PREVIEW_FILL] as const;
const SQ_PREVIEW_SOURCES = [SRC_SQ_PREVIEW_ORIGIN, SRC_SQ_PREVIEW_CIRCLE] as const;

function removeSpatialQueryPreview(map: maplibregl.Map) {
  for (const lid of SQ_PREVIEW_LAYERS) {
    if (map.getLayer(lid)) map.removeLayer(lid);
  }
  for (const sid of SQ_PREVIEW_SOURCES) {
    if (map.getSource(sid)) map.removeSource(sid);
  }
}

function removeSearchMapOverlay(map: maplibregl.Map) {
  for (const lid of SPATIAL_LAYERS) {
    if (map.getLayer(lid)) map.removeLayer(lid);
  }
  for (const sid of SPATIAL_SOURCES) {
    if (map.getSource(sid)) map.removeSource(sid);
  }
}

/** 与 `韶山水环境设施管理系统/index.tsx` 列表「详情」弹窗 `detailModalStyles` 一致 */
const zhtFormModalBody = {
  maxHeight: 'calc(100vh - 240px)',
  overflowY: 'auto' as const,
  overflowX: 'hidden' as const,
  minWidth: 0,
};
const detailModalStyles = {
  body: { ...zhtFormModalBody, maxHeight: 'min(85vh, 900px)', overflowY: 'auto' as const },
};

/** 台账类（泵站/排口/污水厂）与设施管理「详情」同宽；其余统一点位与管点类详情同 800px */
const ZHT_MAP_FACILITY_DETAIL_WIDTH: number | string = 'min(1200px, 96vw)';
const ZHT_MAP_OTHER_DETAIL_WIDTH = 800;

/**
 * 非台账统一点位详情：与设施管理只读详情同源 —— `detail-section` + `Descriptions bordered`
 *（`facility-detail-panel.css` 已引入综合态势入口）
 */
function UnifiedSearchPointDetailContent({
  pt,
  demo,
}: {
  pt: ZhtUnifiedSearchPoint;
  demo?: ZhtMonitoringPoiDemo | null;
}) {
  const basicItems: NonNullable<DescriptionsProps['items']> = [
    { key: 'src', label: '来源项目', children: pt.sourceProject },
    { key: 'ptype', label: '类型', children: pt.pointType },
    { key: 'code', label: '编码', children: pt.code },
    { key: 'name', label: '名称', children: pt.name },
    { key: 'region', label: '区域', children: pt.region },
    { key: 'status', label: '状态', children: pt.status },
    {
      key: 'xy',
      label: '坐标',
      children: `${pt.lng.toFixed(6)}，${pt.lat.toFixed(6)}`,
      span: 2,
    },
  ];
  const metricItems: NonNullable<DescriptionsProps['items']> | null =
    demo && demo.metrics.length > 0
      ? demo.metrics.map((row, i) => ({
          key: `m${i}`,
          label: row.name,
          children: (
            <>
              <strong className={`zht-map-poi-hint__metric-num ${zhtMonitorMetricNumClass(row.tone)}`}>
                {row.value}
              </strong>
              {row.unit ? (
                <span style={{ marginLeft: 6, color: 'rgba(0, 0, 0, 0.45)', fontWeight: 400 }}>{row.unit}</span>
              ) : null}
            </>
          ),
        }))
      : null;
  return (
    <>
      <div className="detail-section">
        <div className="detail-section-title">基本信息</div>
        <div className="detail-section-content">
          <Descriptions bordered column={2} size="small" items={basicItems} />
        </div>
      </div>
      {metricItems ? (
        <div className="detail-section">
          <div className="detail-section-title">演示监测数据</div>
          <div className="detail-section-content">
            <Descriptions bordered column={2} size="small" items={metricItems} />
          </div>
        </div>
      ) : null}
    </>
  );
}

export type FacilityMapKind = 'pump' | 'outlet' | 'plant';

function findFacilityRecord(kind: FacilityMapKind, id: string): Record<string, unknown> | null {
  if (kind === 'pump') return pumpStationData.find(r => r.id === id) ?? null;
  if (kind === 'outlet') return outletData.find(r => r.id === id) ?? null;
  return plantData.find(r => r.id === id) ?? null;
}

/** 设施提示板最多数量（避免全量台账同时挂 HTML Marker 影响性能） */
const ZHT_POI_FACILITY_HINT_CAP = 28;

/**
 * 多个 POI Marker 重叠时叠放顺序：由经纬度决定「谁在上」。
 * 正北朝上时，纬度越低（地图偏南、通常更靠近画面下方）z-index 越大，提示板越靠前；
 * 经度略作区分，减轻同纬度多点 z 值完全相同的情况。
 * 必须在「本帧全部点位」的 min/max 范围内归一化，保证 z-index 为正；若用 (minLat - lat)*系数，
 * 偏北点会得到负 z，Marker 会沉到地图画布下方而不可见。
 */
function zhtPoiMarkerZIndexFromPosition(
  lat: number,
  lng: number,
  minLat: number,
  maxLat: number,
  minLng: number,
  maxLng: number,
): number {
  const latSpan = Math.max(1e-6, maxLat - minLat);
  const lngSpan = Math.max(1e-6, maxLng - minLng);
  const southNorm = (maxLat - lat) / latSpan; // 南端（lat 小）更接近 1，叠放更靠前
  const eastNorm = (lng - minLng) / lngSpan;
  return Math.round(100 + southNorm * 720 + eastNorm * 80);
}

/** 非台账设施类水环境 POI（生态整治 / 应急 / 系统管理等统一点位） */
const ZHT_WATER_ENV_UNIFIED_ONLY: ReadonlySet<ZhtWaterEnvCategoryId> = new Set([
  'eco_project',
  'eco_affair',
  'emg_supply',
  'emg_event',
  'sys_zhaba',
  'sys_diba',
  'sys_shuiku',
  'sys_shuizha',
  'sys_weiqu',
  'sys_yandi',
  'sys_shantang',
]);

function facilityKindToWaterEnvCategory(kind: FacilityMapKind): ZhtWaterEnvCategoryId {
  if (kind === 'pump') return 'pump';
  if (kind === 'outlet') return 'outlet';
  return 'plant';
}

/** 水环境 POI 圆点：外圈四态色 + 中心分类图标 */
function createWaterEnvCategoryDot(cat: ZhtWaterEnvCategoryId, viz: ZhtPoiDisplayState): HTMLDivElement {
  const el = document.createElement('div');
  el.className = `zht-map-point-dot zht-map-point-dot--water-env zht-map-point-dot--viz-${viz} zht-map-point-dot--cat-${cat}`;
  el.setAttribute('aria-hidden', 'true');
  appendWaterEnvPoiDotIcon(el, cat);
  return el;
}

function appendFacilityPoiHint(
  root: HTMLElement,
  facilityName: string,
  titleFontPx: number,
  /** 地图搜索命中时：列表序号 + 空格，置于标题前 */
  titlePrefix?: string,
): void {
  const card = document.createElement('div');
  card.className = 'zht-map-poi-hint zht-map-poi-hint--facility';
  const titleEl = document.createElement('div');
  titleEl.className = 'zht-map-poi-hint__title';
  titleEl.textContent = titlePrefix ? `${titlePrefix}${facilityName}` : facilityName;
  titleEl.style.fontSize = `${titleFontPx}px`;
  card.appendChild(titleEl);
  root.appendChild(card);
}

/** 监测点提示板：由 POI提示配置 控制标题 / 数值区块；两者皆关则不挂载卡片 */
function appendMonitorPoiHint(
  root: HTMLElement,
  mon: ZhtMonitoringPoiDemo,
  showTitle: boolean,
  showValues: boolean,
  titleFontPx: number,
  valuesFontPx: number,
  /** 地图搜索命中时：列表序号 + 空格，置于标题前 */
  titlePrefix?: string,
): void {
  const card = document.createElement('div');
  card.className = 'zht-map-poi-hint zht-map-poi-hint--monitor';
  if (showTitle) {
    const titleEl = document.createElement('div');
    titleEl.className = 'zht-map-poi-hint__title';
    titleEl.textContent = titlePrefix ? `${titlePrefix}${mon.title}` : mon.title;
    titleEl.style.fontSize = `${titleFontPx}px`;
    card.appendChild(titleEl);
  }
  if (showValues) {
    const metrics = document.createElement('div');
    metrics.className = 'zht-map-poi-hint__metrics';
    metrics.style.fontSize = `${valuesFontPx}px`;
    for (const row of mon.metrics) {
      const line = document.createElement('div');
      line.className = 'zht-map-poi-hint__metric-row';
      const nameSpan = document.createElement('span');
      nameSpan.className = 'zht-map-poi-hint__metric-name';
      nameSpan.textContent = `${row.name} `;
      const numSpan = document.createElement('span');
      numSpan.className = `zht-map-poi-hint__metric-num ${zhtMonitorMetricNumClass(row.tone)}`;
      numSpan.textContent = row.value;
      line.append(nameSpan, numSpan);
      if (row.unit) {
        const unitSpan = document.createElement('span');
        unitSpan.className = 'zht-map-poi-hint__metric-unit';
        unitSpan.textContent = row.unit;
        line.appendChild(unitSpan);
      }
      metrics.appendChild(line);
    }
    card.appendChild(metrics);
  }
  root.appendChild(card);
}

/** 行政区划名称 + 可选零直排指标（提示板样式与设施类一致扩展） */
function appendAdminDivisionCard(
  root: HTMLElement,
  d: ZhtAdminDivisionHintDemo,
  showMetrics: boolean,
  titleFontPx: number,
): void {
  const card = document.createElement('div');
  card.className = 'zht-map-poi-hint zht-map-poi-hint--admin';
  const titleEl = document.createElement('div');
  titleEl.className = 'zht-map-poi-hint__title';
  titleEl.style.fontSize = `${titleFontPx}px`;
  titleEl.textContent = d.name;
  card.appendChild(titleEl);
  if (showMetrics) {
    const box = document.createElement('div');
    box.className = 'zht-map-admin-metric-block';
    const l1 = document.createElement('div');
    l1.className = 'zht-map-admin-metric-line';
    l1.append(document.createTextNode('雨污分流：'), mkAdminOkBadSpan(d.rainSewageDiversionOk));
    const l2 = document.createElement('div');
    l2.className = 'zht-map-admin-metric-line';
    l2.append(document.createTextNode('污水零直排：'), mkAdminOkBadSpan(d.zeroDirectSewageOk));
    box.append(l1, l2);
    card.appendChild(box);
  }
  root.appendChild(card);
  const pin = document.createElement('div');
  pin.className = 'zht-map-admin-pin';
  pin.setAttribute('aria-hidden', 'true');
  root.appendChild(pin);
}

function mkAdminOkBadSpan(ok: boolean): HTMLSpanElement {
  const s = document.createElement('span');
  s.className = ok ? 'zht-map-admin-ok' : 'zht-map-admin-bad';
  s.textContent = ok ? '达标' : '不达标';
  return s;
}

/** 地图搜索专用：单层 DOM 序号点（无台账提示板时），锚点居中便于点击出详情 */
function createMapSearchResultMarkerRoot(idx: number, selected: boolean): HTMLElement {
  const root = document.createElement('div');
  root.className = `zht-map-search-result-hit${selected ? ' zht-map-search-result-hit--selected' : ''}`;
  const dot = document.createElement('div');
  dot.className = 'zht-map-search-result-hit__dot';
  const badge = document.createElement('span');
  badge.className = 'zht-map-search-result-hit__idx';
  badge.textContent = String(idx);
  badge.setAttribute('aria-label', `查询结果序号 ${idx}`);
  root.append(dot, badge);
  return root;
}

export interface ZhtMaplibreBoardProps {
  /** 行政区划名称提示面板 */
  showAdminDivisionHints?: boolean;
  /** 行政区划提示板内：雨污分流 / 污水零直排达标文案显隐 */
  showZeroDirectIndicators?: boolean;
  /** 图层控制完整状态（工具条 Popover；含水环境 POI 各分类与四态） */
  layerControl: ZhtLayerControlState;
  onLayerControlChange: (patch: Partial<ZhtLayerControlState>) => void;
  /** 地图 load 后写入，供右侧「地图搜索」结果卡片触发 flyTo */
  mapSearchFlyToRef?: React.MutableRefObject<((point: ZhtUnifiedSearchPoint) => void) | null>;
  /** 工具条「搜索」：父级切换右侧分析看板 / 地图搜索 */
  onToggleMapSearch?: () => void;
  /** 右侧「地图搜索」面板打开时为 true：地图隐藏默认台账/监测点，仅绘当前查询结果点（可点详情） */
  mapSearchPanelOpen?: boolean;
  /** 空间要素 + 数据原点 + 尚无查询覆盖层：恢复默认台账/监测 DOM，便于对照选下拉原点 */
  mapSearchShowDefaultPoiMarkers?: boolean;
  /** 为 true 时：下一次地图点击作为空间查询原点（十字光标），不打开设施详情 */
  spatialMapPickActive?: boolean;
  /** 地图选点完成（经纬度） */
  onSpatialMapPick?: (lng: number, lat: number) => void;
  /** 条件 / 空间查询结果：带序号点；空间查询另含圆与原点；null 清除 */
  searchMapOverlay?: ZhtSearchMapOverlay | null;
  /** 当前选中的结果点 id：WebGL 序号点或设施 DOM 命中态略放大（列表无高亮） */
  searchMapSelectedPointId?: string | null;
  /** 点击地图上的查询结果序号点（与列表一致） */
  onSearchMapResultClick?: (point: ZhtUnifiedSearchPoint) => void;
  /** 空间要素查询：未提交查询前，在地图上预览查询原点与半径（米） */
  spatialQueryPreview?: ZhtSpatialQueryPreview | null;
}

export const ZhtMaplibreBoard: React.FC<ZhtMaplibreBoardProps> = ({
  showAdminDivisionHints = true,
  showZeroDirectIndicators = true,
  layerControl,
  onLayerControlChange,
  mapSearchFlyToRef,
  onToggleMapSearch,
  mapSearchPanelOpen = false,
  mapSearchShowDefaultPoiMarkers = false,
  spatialMapPickActive,
  onSpatialMapPick,
  searchMapOverlay,
  searchMapSelectedPointId,
  onSearchMapResultClick,
  spatialQueryPreview,
}) => {
  const poiLayerSlice = waterEnvPoiLayerControlSlice(layerControl);
  const stackRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);
  const spatialPickActiveRef = useRef(false);
  const spatialPickConsumedRef = useRef(false);
  const onSpatialMapPickRef = useRef(onSpatialMapPick);
  onSpatialMapPickRef.current = onSpatialMapPick;
  spatialPickActiveRef.current = !!spatialMapPickActive;
  const onSearchMapResultClickRef = useRef(onSearchMapResultClick);
  onSearchMapResultClickRef.current = onSearchMapResultClick;

  const [detailOpen, setDetailOpen] = useState(false);
  const [detailTitle, setDetailTitle] = useState('');
  const [detailBody, setDetailBody] = useState<React.ReactNode>(null);
  const [detailKey, setDetailKey] = useState(0);
  /** 与设施管理列表详情一致：台账三件套加宽，其余 800 */
  const [detailModalWidth, setDetailModalWidth] = useState<number | string>(ZHT_MAP_OTHER_DETAIL_WIDTH);
  /** 地图 style 已 load，空间覆盖层可安全 addSource */
  const [mapIsReady, setMapIsReady] = useState(false);

  /** POI提示配置：仅控制 HTML 提示板；地图点位圆点图层不受此三项开关影响（常亮与数据源/图层控制相关） */
  const [poiFacilityTitle, setPoiFacilityTitle] = useState(ZHT_POI_HINT_UI_DEFAULTS.facilityTitle);
  const [poiMonitorTitle, setPoiMonitorTitle] = useState(ZHT_POI_HINT_UI_DEFAULTS.monitorTitle);
  const [poiMonitorValues, setPoiMonitorValues] = useState(ZHT_POI_HINT_UI_DEFAULTS.monitorValues);
  const [poiFacilityTitleFont, setPoiFacilityTitleFont] = useState<ZhtPoiHintFontPreset>(
    ZHT_POI_HINT_UI_DEFAULTS.facilityTitleFont,
  );
  const [poiMonitorTitleFont, setPoiMonitorTitleFont] = useState<ZhtPoiHintFontPreset>(
    ZHT_POI_HINT_UI_DEFAULTS.monitorTitleFont,
  );
  const [poiMonitorValuesFont, setPoiMonitorValuesFont] = useState<ZhtPoiHintFontPreset>(
    ZHT_POI_HINT_UI_DEFAULTS.monitorValuesFont,
  );

  const resetPoiHintsToDefault = useCallback(() => {
    const d = ZHT_POI_HINT_UI_DEFAULTS;
    setPoiFacilityTitle(d.facilityTitle);
    setPoiMonitorTitle(d.monitorTitle);
    setPoiMonitorValues(d.monitorValues);
    setPoiFacilityTitleFont(d.facilityTitleFont);
    setPoiMonitorTitleFont(d.monitorTitleFont);
    setPoiMonitorValuesFont(d.monitorValuesFont);
  }, []);

  const poiMarkersRef = useRef<maplibregl.Marker[]>([]);
  /** 行政区划名称 Marker（与业务 POI 分轨清理） */
  const adminDivisionMarkersRef = useRef<maplibregl.Marker[]>([]);
  const adminDivisionResizeObserversRef = useRef<ResizeObserver[]>([]);
  /** POI 提示板增删会改变 Marker 根节点高度；MapLibre 不会自动重算锚点，需在尺寸变化时 setLngLat 踢一脚 */
  const poiMarkerResizeObserversRef = useRef<ResizeObserver[]>([]);

  const openFacilityDetail = useCallback((kind: FacilityMapKind, id: string) => {
    const record = findFacilityRecord(kind, id);
    if (!record) return;
    setDetailKey(k => k + 1);
    setDetailModalWidth(ZHT_MAP_FACILITY_DETAIL_WIDTH);
    if (kind === 'pump') {
      setDetailTitle(`泵站详情 - ${record.name}`);
      setDetailBody(<PumpDetailContent record={record} />);
    } else if (kind === 'outlet') {
      setDetailTitle(`排口详情 - ${record.name}`);
      setDetailBody(<OutletDetailContent record={record} />);
    } else {
      setDetailTitle(`污水厂详情 - ${record.name}`);
      setDetailBody(<PlantDetailContent record={record} />);
    }
    setDetailOpen(true);
  }, []);

  const openFacilityDetailRef = useRef(openFacilityDetail);
  openFacilityDetailRef.current = openFacilityDetail;

  /** 统一点位：设施走台账详情 Modal；监测与其它走摘要 Modal */
  const openUnifiedSearchPointDetail = useCallback(
    (pt: ZhtUnifiedSearchPoint) => {
      const fac = parseZhtFacilityUnifiedSearchId(pt.id);
      if (fac) {
        openFacilityDetail(fac.kind, fac.rawId);
        return;
      }
      const mon = parseZhtMonitorUnifiedSearchId(pt.id);
      if (mon) {
        const demo = ZHT_MONITORING_POI_DEMO.find(m => m.id === mon.rawMonId);
        setDetailKey(k => k + 1);
        setDetailModalWidth(ZHT_MAP_OTHER_DETAIL_WIDTH);
        setDetailTitle(demo ? `水质监测 · ${demo.title}` : `水质监测 · ${pt.name}`);
        setDetailBody(<UnifiedSearchPointDetailContent pt={pt} demo={demo ?? null} />);
        setDetailOpen(true);
        return;
      }
      setDetailKey(k => k + 1);
      setDetailModalWidth(ZHT_MAP_OTHER_DETAIL_WIDTH);
      setDetailTitle(`${pt.sourceProject} · ${pt.name}`);
      setDetailBody(<UnifiedSearchPointDetailContent pt={pt} />);
      setDetailOpen(true);
    },
    [openFacilityDetail],
  );

  const openUnifiedSearchPointDetailRef = useRef(openUnifiedSearchPointDetail);
  openUnifiedSearchPointDetailRef.current = openUnifiedSearchPointDetail;

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const map = new maplibregl.Map({
      container: el,
      style: PARK_MAPLIBRE_STYLE_URL,
      center: PARK_MAPLIBRE_DEFAULT_CENTER,
      zoom: PARK_MAPLIBRE_DEFAULT_ZOOM,
      attributionControl: { compact: true },
    });
    mapRef.current = map;

    /** 左下角比例尺（公制） */
    map.addControl(
      new maplibregl.ScaleControl({
        maxWidth: 120,
        unit: 'metric',
      }),
      'bottom-left',
    );

    const kickResize = () => {
      map.resize();
    };
    requestAnimationFrame(kickResize);
    requestAnimationFrame(() => requestAnimationFrame(kickResize));
    const resizeTimer1 = window.setTimeout(kickResize, 80);
    const resizeTimer2 = window.setTimeout(kickResize, 400);

    const ro = new ResizeObserver(() => {
      map.resize();
    });
    ro.observe(el);

    const onMapLoad = () => {
      kickResize();
      setMapIsReady(true);
      if (mapSearchFlyToRef) {
        mapSearchFlyToRef.current = (point: ZhtUnifiedSearchPoint) => {
          if (!map.loaded()) return;
          const z = map.getZoom();
          map.flyTo({
            center: [point.lng, point.lat],
            zoom: Math.min(18, Math.max(z + 0.45, 14.6)),
            essential: true,
          });
        };
      }
    };

    map.once('load', onMapLoad);

    return () => {
      setMapIsReady(false);
      if (mapSearchFlyToRef) {
        mapSearchFlyToRef.current = null;
      }
      ro.disconnect();
      window.clearTimeout(resizeTimer1);
      window.clearTimeout(resizeTimer2);
      map.remove();
      mapRef.current = null;
    };
  }, [mapSearchFlyToRef]);

  /** 行政区划名称提示（演示）；零直排文案受图层「零直排区域标注」控制 */
  useEffect(() => {
    const map = mapRef.current;
    adminDivisionResizeObserversRef.current.forEach(o => o.disconnect());
    adminDivisionResizeObserversRef.current = [];
    adminDivisionMarkersRef.current.forEach(m => m.remove());
    adminDivisionMarkersRef.current = [];
    if (!mapIsReady || !map?.loaded() || !showAdminDivisionHints) return;

    const pts = ZHT_ADMIN_DIVISION_HINTS_DEMO.map(d => ({ lng: d.lng, lat: d.lat }));
    let minLat = 90;
    let maxLat = -90;
    let minLng = 180;
    let maxLng = -180;
    for (const p of pts) {
      if (p.lat < minLat) minLat = p.lat;
      if (p.lat > maxLat) maxLat = p.lat;
      if (p.lng < minLng) minLng = p.lng;
      if (p.lng > maxLng) maxLng = p.lng;
    }

    const titlePx = zhtPoiHintFontPx(poiFacilityTitleFont);
    const next: maplibregl.Marker[] = [];
    for (const d of ZHT_ADMIN_DIVISION_HINTS_DEMO) {
      const root = document.createElement('div');
      appendAdminDivisionCard(root, d, showZeroDirectIndicators, titlePx);
      root.classList.add('zht-map-poi-marker-root', 'zht-map-poi-marker-root--stack');
      const marker = new maplibregl.Marker({ element: root, anchor: 'bottom' })
        .setLngLat([d.lng, d.lat])
        .addTo(map);
      const z = zhtPoiMarkerZIndexFromPosition(d.lat, d.lng, minLat, maxLat, minLng, maxLng);
      marker.getElement().style.zIndex = String(z + 8);
      next.push(marker);
      const ro = new ResizeObserver(() => {
        marker.setLngLat(marker.getLngLat());
      });
      ro.observe(marker.getElement());
      adminDivisionResizeObserversRef.current.push(ro);
    }
    adminDivisionMarkersRef.current = next;
    requestAnimationFrame(() => {
      if (!map.loaded()) return;
      next.forEach(m => m.setLngLat(m.getLngLat()));
      map.triggerRepaint();
    });

    return () => {
      adminDivisionResizeObserversRef.current.forEach(o => o.disconnect());
      adminDivisionResizeObserversRef.current = [];
      adminDivisionMarkersRef.current.forEach(m => m.remove());
      adminDivisionMarkersRef.current = [];
    };
  }, [mapIsReady, showAdminDivisionHints, showZeroDirectIndicators, poiFacilityTitleFont]);

  /** 空间查询：在地图空白处点击取原点（设施 DOM 圆点在选点模式下 pointer-events:none，点击穿透到地图） */
  useEffect(() => {
    if (!spatialMapPickActive) return;
    spatialPickConsumedRef.current = false;
    const map = mapRef.current;
    if (!map?.loaded()) return;

    const handler = (e: maplibregl.MapMouseEvent) => {
      if (!spatialPickActiveRef.current) return;
      if (spatialPickConsumedRef.current) return;
      spatialPickConsumedRef.current = true;
      onSpatialMapPickRef.current?.(e.lngLat.lng, e.lngLat.lat);
    };

    map.on('click', handler);
    map.getCanvas().style.cursor = 'crosshair';

    return () => {
      map.off('click', handler);
      map.getCanvas().style.cursor = '';
    };
  }, [spatialMapPickActive]);

  /** 条件 / 空间查询：序号命中点；空间查询另绘测地圆与原点 */
  useEffect(() => {
    const map = mapRef.current;
    if (!mapIsReady || !map?.loaded()) return;

    removeSearchMapOverlay(map);

    if (!searchMapOverlay) return;

    const { results, spatialRange } = searchMapOverlay;

    if (spatialRange) {
      const { originLng, originLat, radiusM } = spatialRange;
      const circleFeat = buildGeodesicCirclePolygon(originLng, originLat, radiusM);

      map.addSource(SRC_SR_CIRCLE, {
        type: 'geojson',
        data: { type: 'FeatureCollection', features: [circleFeat] },
      });
      map.addLayer({
        id: LYR_SR_FILL,
        type: 'fill',
        source: SRC_SR_CIRCLE,
        paint: {
          'fill-color': '#1677ff',
          'fill-opacity': 0.12,
        },
      });
      map.addLayer({
        id: LYR_SR_LINE,
        type: 'line',
        source: SRC_SR_CIRCLE,
        paint: {
          'line-color': '#1677ff',
          'line-width': 2,
          'line-dasharray': [4, 3],
        },
      });

      map.addSource(SRC_SR_ORIGIN, {
        type: 'geojson',
        data: {
          type: 'FeatureCollection',
          features: [
            {
              type: 'Feature',
              properties: {},
              geometry: { type: 'Point', coordinates: [originLng, originLat] },
            },
          ],
        },
      });
      map.addLayer({
        id: LYR_SR_ORIGIN,
        type: 'circle',
        source: SRC_SR_ORIGIN,
        paint: {
          'circle-radius': 11,
          'circle-color': '#ff4d4f',
          'circle-stroke-width': 3,
          'circle-stroke-color': '#ffffff',
        },
      });
    }

    if (!results.length) {
      return () => {
        removeSearchMapOverlay(map);
      };
    }

    /** 已在水环境图层下以 DOM 绘制的点不再叠 WebGL 序号点 */
    const slice = waterEnvPoiLayerControlSlice(layerControl);
    const geoResultEntries = results
      .map((p, i) => ({ p, i }))
      .filter(({ p }) => !unifiedPointPassesWaterEnvLayer(slice, p));

    /** 地图搜索打开且非「数据选点对照」时：结果点全部由 DOM Marker 承载（可点详情），不再叠 WebGL 避免点不穿 */
    if (mapSearchPanelOpen && !mapSearchShowDefaultPoiMarkers) {
      return () => {
        removeSearchMapOverlay(map);
      };
    }

    if (geoResultEntries.length === 0) {
      return () => {
        removeSearchMapOverlay(map);
      };
    }

    const resFeatures: GeoJSON.Feature<GeoJSON.Point, Record<string, string | number>>[] = geoResultEntries.map(
      ({ p, i }) => ({
        type: 'Feature',
        properties: {
          idx: String(i + 1),
          id: p.id,
          name: p.name,
          code: p.code,
          pointType: p.pointType,
          status: p.status,
          region: p.region,
          lng: p.lng,
          lat: p.lat,
          sourceProject: p.sourceProject,
        },
        geometry: { type: 'Point', coordinates: [p.lng, p.lat] },
      }),
    );

    map.addSource(SRC_SR_RESULTS, {
      type: 'geojson',
      data: { type: 'FeatureCollection', features: resFeatures },
    });
    map.addLayer({
      id: LYR_SR_RES_PT,
      type: 'circle',
      source: SRC_SR_RESULTS,
      paint: {
        'circle-radius': 14,
        'circle-color': '#fa8c16',
        'circle-stroke-width': 2,
        'circle-stroke-color': '#ffffff',
      },
    });
    map.addLayer({
      id: LYR_SR_RES_TX,
      type: 'symbol',
      source: SRC_SR_RESULTS,
      layout: {
        'text-field': ['get', 'idx'],
        'text-font': SPATIAL_RES_TEXT_FONT,
        'text-size': 15,
        'text-offset': [0, 0],
        'text-anchor': 'center',
        'text-allow-overlap': true,
        'text-padding': 4,
      },
      paint: {
        'text-color': '#ffffff',
        'text-halo-color': '#fa8c16',
        'text-halo-width': 2,
        'text-halo-blur': 0.35,
      },
    });

    const onResClick = (e: maplibregl.MapLayerMouseEvent) => {
      if (spatialPickActiveRef.current) return;
      const f = e.features?.[0];
      const pt = spatialHitPropsToUnifiedPoint(f?.properties ?? null);
      if (pt) onSearchMapResultClickRef.current?.(pt);
    };
    const onResEnter = () => {
      if (!spatialPickActiveRef.current) map.getCanvas().style.cursor = 'pointer';
    };
    const onResLeave = () => {
      if (!spatialPickActiveRef.current) map.getCanvas().style.cursor = '';
    };

    map.on('click', LYR_SR_RES_PT, onResClick);
    map.on('click', LYR_SR_RES_TX, onResClick);
    map.on('mouseenter', LYR_SR_RES_PT, onResEnter);
    map.on('mouseleave', LYR_SR_RES_PT, onResLeave);
    map.on('mouseenter', LYR_SR_RES_TX, onResEnter);
    map.on('mouseleave', LYR_SR_RES_TX, onResLeave);

    return () => {
      map.off('click', LYR_SR_RES_PT, onResClick);
      map.off('click', LYR_SR_RES_TX, onResClick);
      map.off('mouseenter', LYR_SR_RES_PT, onResEnter);
      map.off('mouseleave', LYR_SR_RES_PT, onResLeave);
      map.off('mouseenter', LYR_SR_RES_TX, onResEnter);
      map.off('mouseleave', LYR_SR_RES_TX, onResLeave);
      removeSearchMapOverlay(map);
    };
  }, [searchMapOverlay, mapIsReady, layerControl, mapSearchPanelOpen, mapSearchShowDefaultPoiMarkers]);

  /** 空间要素查询表单：实时预览查询原点与测地圆（绿虚线）；提交查询后由 searchMapOverlay.spatialRange 展示正式结果圆 */
  useEffect(() => {
    const map = mapRef.current;
    if (!mapIsReady || !map?.loaded()) return;

    removeSpatialQueryPreview(map);
    if (searchMapOverlay?.spatialRange) return;
    if (!spatialQueryPreview) return;

    const { originLng, originLat, radiusM } = spatialQueryPreview;
    /** 兼容字符串半径；勿用 Number.isFinite(radiusM) 直接判（字符串合法值会为 false） */
    const rNum = Number(radiusM);
    const hasCircle =
      radiusM !== undefined && radiusM !== null && Number.isFinite(rNum) && rNum > 0;

    if (hasCircle) {
      /** 极大半径时测地构环可能数值不稳定；过小在默认缩放下几乎不可见，仍合法绘制 */
      const MAX_PREVIEW_RADIUS_M = 2_000_000;
      const r0 = Number(radiusM);
      const rDraw = Math.min(Math.max(r0, 1), MAX_PREVIEW_RADIUS_M);
      try {
        const circleFeat = buildGeodesicCirclePolygon(originLng, originLat, rDraw);
        map.addSource(SRC_SQ_PREVIEW_CIRCLE, {
          type: 'geojson',
          data: { type: 'FeatureCollection', features: [circleFeat] },
        });
        map.addLayer({
          id: LYR_SQ_PREVIEW_FILL,
          type: 'fill',
          source: SRC_SQ_PREVIEW_CIRCLE,
          paint: {
            'fill-color': '#52c41a',
            'fill-opacity': 0.07,
          },
        });
        map.addLayer({
          id: LYR_SQ_PREVIEW_LINE,
          type: 'line',
          source: SRC_SQ_PREVIEW_CIRCLE,
          paint: {
            'line-color': '#52c41a',
            'line-width': 2,
            'line-dasharray': [6, 4],
          },
        });
      } catch {
        // 构环失败时仅保留原点，避免整段预览失效
      }
    }

    map.addSource(SRC_SQ_PREVIEW_ORIGIN, {
      type: 'geojson',
      data: {
        type: 'FeatureCollection',
        features: [
          {
            type: 'Feature',
            properties: {},
            geometry: { type: 'Point', coordinates: [originLng, originLat] },
          },
        ],
      },
    });
    map.addLayer({
      id: LYR_SQ_PREVIEW_ORIGIN,
      type: 'circle',
      source: SRC_SQ_PREVIEW_ORIGIN,
      paint: {
        'circle-radius': hasCircle ? 10 : 12,
        'circle-color': '#1677ff',
        'circle-stroke-width': 3,
        'circle-stroke-color': '#ffffff',
      },
    });

    return () => removeSpatialQueryPreview(map);
  }, [mapIsReady, spatialQueryPreview, searchMapOverlay]);

  /** 查询结果 GeoJSON 序号点：选中项略放大（设施 DOM 命中态在 Marker effect 中处理） */
  useEffect(() => {
    const map = mapRef.current;
    if (!mapIsReady || !map?.loaded() || !map.getLayer(LYR_SR_RES_PT)) return;

    const sel = searchMapSelectedPointId ?? '';
    if (sel === '') {
      map.setPaintProperty(LYR_SR_RES_PT, 'circle-radius', 14);
      map.setPaintProperty(LYR_SR_RES_PT, 'circle-stroke-width', 2);
      map.setLayoutProperty(LYR_SR_RES_TX, 'text-size', 15);
    } else {
      map.setPaintProperty(LYR_SR_RES_PT, 'circle-radius', ['case', ['==', ['get', 'id'], sel], 20, 14]);
      map.setPaintProperty(LYR_SR_RES_PT, 'circle-stroke-width', ['case', ['==', ['get', 'id'], sel], 3.5, 2]);
      map.setLayoutProperty(LYR_SR_RES_TX, 'text-size', ['case', ['==', ['get', 'id'], sel], 18, 15]);
    }
  }, [
    searchMapSelectedPointId,
    searchMapOverlay,
    mapIsReady,
    mapSearchPanelOpen,
    mapSearchShowDefaultPoiMarkers,
  ]);

  /** 设施 / 监测：DOM 圆点（必显）+ 可选 HTML 提示板（POI提示配置） */
  useEffect(() => {
    const map = mapRef.current;
    const clearMarkers = () => {
      poiMarkersRef.current.forEach(m => m.remove());
      poiMarkersRef.current = [];
    };

    if (!mapIsReady || !map) {
      poiMarkerResizeObserversRef.current.forEach(ro => ro.disconnect());
      poiMarkerResizeObserversRef.current = [];
      clearMarkers();
      return;
    }

    poiMarkerResizeObserversRef.current.forEach(ro => ro.disconnect());
    poiMarkerResizeObserversRef.current = [];

    clearMarkers();
    const next: maplibregl.Marker[] = [];
    const passThrough = !!spatialMapPickActive;

    const bindHitHover = (el: HTMLElement) => {
      el.addEventListener('mouseenter', () => {
        if (!spatialPickActiveRef.current) map.getCanvas().style.cursor = 'pointer';
      });
      el.addEventListener('mouseleave', () => {
        map.getCanvas().style.cursor = '';
      });
    };

    /** 地图搜索面板打开且非数据选点对照：仅绘查询结果；台账设施/监测叠 POI 提示板，其余在开启设施标题时可叠简要提示 */
    if (mapSearchPanelOpen && !mapSearchShowDefaultPoiMarkers) {
      const rows = searchMapOverlay?.results ?? [];
      const posList = rows.map(p => ({ lng: p.lng, lat: p.lat }));
      let minLat = 90;
      let maxLat = -90;
      let minLng = 180;
      let maxLng = -180;
      if (posList.length) {
        for (const p of posList) {
          if (p.lat < minLat) minLat = p.lat;
          if (p.lat > maxLat) maxLat = p.lat;
          if (p.lng < minLng) minLng = p.lng;
          if (p.lng > maxLng) maxLng = p.lng;
        }
      } else {
        minLat = maxLat = PARK_MAPLIBRE_DEFAULT_CENTER[1];
        minLng = maxLng = PARK_MAPLIBRE_DEFAULT_CENTER[0];
      }

      const mountSearchHit = (lng: number, lat: number, root: HTMLElement) => {
        const marker = new maplibregl.Marker({ element: root, anchor: 'center' })
          .setLngLat([lng, lat])
          .addTo(map);
        const z = zhtPoiMarkerZIndexFromPosition(lat, lng, minLat, maxLat, minLng, maxLng);
        marker.getElement().style.zIndex = String(z);
        next.push(marker);
        const ro = new ResizeObserver(() => {
          marker.setLngLat(marker.getLngLat());
        });
        ro.observe(marker.getElement());
        poiMarkerResizeObserversRef.current.push(ro);
      };

      const mountStackMarker = (lng: number, lat: number, root: HTMLElement) => {
        root.classList.add('zht-map-poi-marker-root', 'zht-map-poi-marker-root--stack');
        const marker = new maplibregl.Marker({ element: root, anchor: 'bottom' })
          .setLngLat([lng, lat])
          .addTo(map);
        const z = zhtPoiMarkerZIndexFromPosition(lat, lng, minLat, maxLat, minLng, maxLng);
        marker.getElement().style.zIndex = String(z);
        next.push(marker);
        const ro = new ResizeObserver(() => {
          marker.setLngLat(marker.getLngLat());
        });
        ro.observe(marker.getElement());
        poiMarkerResizeObserversRef.current.push(ro);
      };

      let facilityHintCount = 0;

      for (let i = 0; i < rows.length; i += 1) {
        const pt = rows[i];
        const idxStr = String(i + 1);
        const hit = { idx: idxStr, unifiedId: pt.id, point: pt };

        const facMeta = parseZhtFacilityUnifiedSearchId(pt.id);
        if (facMeta) {
          const rec = findFacilityRecord(facMeta.kind, facMeta.rawId) as {
            x: number;
            y: number;
            name?: string;
          } | null;
          if (
            rec &&
            typeof rec.x === 'number' &&
            typeof rec.y === 'number' &&
            facilityPassesWaterEnvLayer(poiLayerSlice, facMeta.kind, rec as unknown as Record<string, unknown>)
          ) {
            const lng = rec.x;
            const lat = rec.y;
            const facName = rec.name ?? pt.name;
            const canShowFacilityHint =
              Boolean(poiFacilityTitle) && facilityHintCount < ZHT_POI_FACILITY_HINT_CAP;
            const root = document.createElement('div');
            if (canShowFacilityHint) {
              appendFacilityPoiHint(root, facName, zhtPoiHintFontPx(poiFacilityTitleFont), `${idxStr} `);
              facilityHintCount += 1;
            }
            const cat = facilityKindToWaterEnvCategory(facMeta.kind);
            const st = deriveFacilityDisplayState(facMeta.kind, rec as unknown as Record<string, unknown>);
            const dot = createWaterEnvCategoryDot(cat, st);
            dot.classList.add('zht-map-point-dot--search-hit');
            if (searchMapSelectedPointId === pt.id) {
              dot.classList.add('zht-map-point-dot--search-hit--selected');
            }
            const showIdxBadge = !canShowFacilityHint;
            const wrap = document.createElement('div');
            wrap.className = 'zht-map-poi-search-hit-wrap';
            if (passThrough) wrap.classList.add('zht-map-poi-search-hit-wrap--pass-through');
            wrap.appendChild(dot);
            if (showIdxBadge) {
              const badge = document.createElement('span');
              badge.className = 'zht-map-search-hit-badge';
              badge.textContent = idxStr;
              badge.setAttribute('aria-label', `查询结果序号 ${idxStr}`);
              wrap.appendChild(badge);
            }
            wrap.addEventListener('click', e => {
              e.stopPropagation();
              if (spatialPickActiveRef.current) return;
              onSearchMapResultClickRef.current?.(hit.point);
              openUnifiedSearchPointDetailRef.current?.(hit.point);
            });
            bindHitHover(wrap);
            root.appendChild(wrap);
            mountStackMarker(lng, lat, root);
            continue;
          }
        }

        const monMeta = parseZhtMonitorUnifiedSearchId(pt.id);
        if (monMeta) {
          const mon = ZHT_MONITORING_POI_DEMO.find(m => m.id === monMeta.rawMonId);
          if (mon && monitorDemoPassesWaterEnvLayer(poiLayerSlice, mon)) {
            const root = document.createElement('div');
            const showHintCard = Boolean(poiMonitorTitle || poiMonitorValues);
            if (showHintCard) {
              appendMonitorPoiHint(
                root,
                mon,
                Boolean(poiMonitorTitle),
                Boolean(poiMonitorValues),
                zhtPoiHintFontPx(poiMonitorTitleFont),
                zhtPoiHintFontPx(poiMonitorValuesFont),
                poiMonitorTitle ? `${idxStr} ` : undefined,
              );
            }
            const dot = createWaterEnvCategoryDot('monitor', monitorPointStateToDisplay(mon.pointState));
            dot.classList.add('zht-map-point-dot--search-hit');
            if (searchMapSelectedPointId === pt.id) {
              dot.classList.add('zht-map-point-dot--search-hit--selected');
            }
            const showIdxBadge = !showHintCard || !poiMonitorTitle;
            const wrap = document.createElement('div');
            wrap.className = 'zht-map-poi-search-hit-wrap';
            if (passThrough) wrap.classList.add('zht-map-poi-search-hit-wrap--pass-through');
            wrap.appendChild(dot);
            if (showIdxBadge) {
              const badge = document.createElement('span');
              badge.className = 'zht-map-search-hit-badge';
              badge.textContent = idxStr;
              badge.setAttribute('aria-label', `查询结果序号 ${idxStr}`);
              wrap.appendChild(badge);
            }
            wrap.addEventListener('click', e => {
              e.stopPropagation();
              if (spatialPickActiveRef.current) return;
              onSearchMapResultClickRef.current?.(hit.point);
              openUnifiedSearchPointDetailRef.current?.(hit.point);
            });
            bindHitHover(wrap);
            root.appendChild(wrap);
            mountStackMarker(mon.lng, mon.lat, root);
            continue;
          }
        }

        const onlyCat = getWaterEnvCategoryForUnifiedPoint(pt);
        if (
          onlyCat &&
          ZHT_WATER_ENV_UNIFIED_ONLY.has(onlyCat) &&
          unifiedPointPassesWaterEnvLayer(poiLayerSlice, pt)
        ) {
          const lng = pt.lng;
          const lat = pt.lat;
          const canShowHint = Boolean(poiFacilityTitle) && facilityHintCount < ZHT_POI_FACILITY_HINT_CAP;
          const root = document.createElement('div');
          if (canShowHint) {
            appendFacilityPoiHint(
              root,
              `${pt.pointType} · ${pt.name}`,
              zhtPoiHintFontPx(poiFacilityTitleFont),
              `${idxStr} `,
            );
            facilityHintCount += 1;
          }
          const st = deriveDisplayStateForUnifiedPoint(pt);
          const dot = createWaterEnvCategoryDot(onlyCat, st);
          dot.classList.add('zht-map-point-dot--search-hit');
          if (searchMapSelectedPointId === pt.id) {
            dot.classList.add('zht-map-point-dot--search-hit--selected');
          }
          const showIdxBadge = !canShowHint;
          const wrap = document.createElement('div');
          wrap.className = 'zht-map-poi-search-hit-wrap';
          if (passThrough) wrap.classList.add('zht-map-poi-search-hit-wrap--pass-through');
          wrap.appendChild(dot);
          if (showIdxBadge) {
            const badge = document.createElement('span');
            badge.className = 'zht-map-search-hit-badge';
            badge.textContent = idxStr;
            badge.setAttribute('aria-label', `查询结果序号 ${idxStr}`);
            wrap.appendChild(badge);
          }
          wrap.addEventListener('click', e => {
            e.stopPropagation();
            if (spatialPickActiveRef.current) return;
            onSearchMapResultClickRef.current?.(hit.point);
            openUnifiedSearchPointDetailRef.current?.(hit.point);
          });
          bindHitHover(wrap);
          root.appendChild(wrap);
          mountStackMarker(lng, lat, root);
          continue;
        }

        const canGenHint = Boolean(poiFacilityTitle) && facilityHintCount < ZHT_POI_FACILITY_HINT_CAP;
        if (canGenHint) {
          const root = document.createElement('div');
          appendFacilityPoiHint(
            root,
            `${pt.pointType} · ${pt.name}`,
            zhtPoiHintFontPx(poiFacilityTitleFont),
            `${idxStr} `,
          );
          facilityHintCount += 1;
          const wrap = document.createElement('div');
          wrap.className = 'zht-map-poi-search-hit-wrap';
          if (passThrough) wrap.classList.add('zht-map-poi-search-hit-wrap--pass-through');
          const innerHit = document.createElement('div');
          innerHit.className = `zht-map-search-result-hit${
            searchMapSelectedPointId === pt.id ? ' zht-map-search-result-hit--selected' : ''
          }`;
          const dotOnly = document.createElement('div');
          dotOnly.className = 'zht-map-search-result-hit__dot';
          innerHit.appendChild(dotOnly);
          wrap.appendChild(innerHit);
          wrap.addEventListener('click', e => {
            e.stopPropagation();
            if (spatialPickActiveRef.current) return;
            onSearchMapResultClickRef.current?.(pt);
            openUnifiedSearchPointDetailRef.current?.(pt);
          });
          bindHitHover(wrap);
          root.appendChild(wrap);
          mountStackMarker(pt.lng, pt.lat, root);
          continue;
        }

        const root = createMapSearchResultMarkerRoot(i + 1, searchMapSelectedPointId === pt.id);
        if (passThrough) root.classList.add('zht-map-search-result-hit--pass-through');
        root.addEventListener('click', e => {
          e.stopPropagation();
          if (spatialPickActiveRef.current) return;
          onSearchMapResultClickRef.current?.(pt);
          openUnifiedSearchPointDetailRef.current?.(pt);
        });
        bindHitHover(root);
        mountSearchHit(pt.lng, pt.lat, root);
      }

      poiMarkersRef.current = next;
      requestAnimationFrame(() => {
        if (!map.loaded()) return;
        for (const m of next) {
          m.setLngLat(m.getLngLat());
        }
        map.triggerRepaint();
      });

      return () => {
        poiMarkerResizeObserversRef.current.forEach(ro => ro.disconnect());
        poiMarkerResizeObserversRef.current = [];
        clearMarkers();
      };
    }

    /** 本帧将要绘制的全部点位（用于同屏 z-index 基准） */
    const allPositions: { lng: number; lat: number }[] = [];
    for (const r of pumpStationData) {
      if (facilityPassesWaterEnvLayer(poiLayerSlice, 'pump', r as unknown as Record<string, unknown>)) {
        allPositions.push({ lng: r.x, lat: r.y });
      }
    }
    for (const r of outletData) {
      if (facilityPassesWaterEnvLayer(poiLayerSlice, 'outlet', r as unknown as Record<string, unknown>)) {
        allPositions.push({ lng: r.x, lat: r.y });
      }
    }
    for (const r of plantData) {
      if (facilityPassesWaterEnvLayer(poiLayerSlice, 'plant', r as unknown as Record<string, unknown>)) {
        allPositions.push({ lng: r.x, lat: r.y });
      }
    }
    for (const mon of ZHT_MONITORING_POI_DEMO) {
      if (monitorDemoPassesWaterEnvLayer(poiLayerSlice, mon)) {
        allPositions.push({ lng: mon.lng, lat: mon.lat });
      }
    }
    for (const pt of getZhtUnifiedSearchPointsCached()) {
      const c = getWaterEnvCategoryForUnifiedPoint(pt);
      if (!c || !ZHT_WATER_ENV_UNIFIED_ONLY.has(c)) continue;
      if (unifiedPointPassesWaterEnvLayer(poiLayerSlice, pt)) {
        allPositions.push({ lng: pt.lng, lat: pt.lat });
      }
    }
    if (allPositions.length === 0) {
      allPositions.push({ lng: PARK_MAPLIBRE_DEFAULT_CENTER[0], lat: PARK_MAPLIBRE_DEFAULT_CENTER[1] });
    }
    let minLat = 90;
    let maxLat = -90;
    let minLng = 180;
    let maxLng = -180;
    for (const p of allPositions) {
      if (p.lat < minLat) minLat = p.lat;
      if (p.lat > maxLat) maxLat = p.lat;
      if (p.lng < minLng) minLng = p.lng;
      if (p.lng > maxLng) maxLng = p.lng;
    }

    /** 圆点在下、提示在上，锚点落在圆点底部中心（与经纬度对齐） */
    const mountMarker = (lng: number, lat: number, root: HTMLElement) => {
      root.classList.add('zht-map-poi-marker-root', 'zht-map-poi-marker-root--stack');
      const marker = new maplibregl.Marker({ element: root, anchor: 'bottom' })
        .setLngLat([lng, lat])
        .addTo(map);
      const z = zhtPoiMarkerZIndexFromPosition(lat, lng, minLat, maxLat, minLng, maxLng);
      marker.getElement().style.zIndex = String(z);
      next.push(marker);
      // 提示板显隐会改变根节点高度；须触发 MapLibre 重算 bottom 锚点，否则查询命中后改 POI 配置会出现点位与圆错位、点击偏移
      const ro = new ResizeObserver(() => {
        marker.setLngLat(marker.getLngLat());
      });
      ro.observe(marker.getElement());
      poiMarkerResizeObserversRef.current.push(ro);
    };

    let facilityHintCount = 0;

    /** 查询结果序号：按统一点位 id 索引（与右栏列表顺序一致） */
    const overlayHitByUnifiedId = new Map<string, { idx: string; unifiedId: string; point: ZhtUnifiedSearchPoint }>();
    if (searchMapOverlay?.results?.length) {
      for (let ri = 0; ri < searchMapOverlay.results.length; ri += 1) {
        const p0 = searchMapOverlay.results[ri];
        overlayHitByUnifiedId.set(p0.id, { idx: String(ri + 1), unifiedId: p0.id, point: p0 });
      }
    }

    /** 当前查询结果里、且对应地图上设施 DOM 的命中（序号与右栏列表一致） */
    const facilitySearchHitByKindId = new Map<
      string,
      { idx: string; unifiedId: string; point: ZhtUnifiedSearchPoint }
    >();
    if (searchMapOverlay?.results?.length) {
      for (let ri = 0; ri < searchMapOverlay.results.length; ri += 1) {
        const pt = searchMapOverlay.results[ri];
        const m = parseZhtFacilityUnifiedSearchId(pt.id);
        if (!m) continue;
        const recHit = findFacilityRecord(m.kind, m.rawId);
        if (!recHit || !facilityPassesWaterEnvLayer(poiLayerSlice, m.kind, recHit as Record<string, unknown>)) continue;
        facilitySearchHitByKindId.set(`${m.kind}:${m.rawId}`, {
          idx: String(ri + 1),
          unifiedId: pt.id,
          point: pt,
        });
      }
    }

    const monitorSearchHitByMonId = new Map<
      string,
      { idx: string; unifiedId: string; point: ZhtUnifiedSearchPoint }
    >();
    if (searchMapOverlay?.results?.length) {
      for (let ri = 0; ri < searchMapOverlay.results.length; ri += 1) {
        const pt = searchMapOverlay.results[ri];
        const mm = parseZhtMonitorUnifiedSearchId(pt.id);
        if (!mm) continue;
        const monHit = ZHT_MONITORING_POI_DEMO.find(x => x.id === mm.rawMonId);
        if (!monHit || !monitorDemoPassesWaterEnvLayer(poiLayerSlice, monHit)) continue;
        monitorSearchHitByMonId.set(mm.rawMonId, {
          idx: String(ri + 1),
          unifiedId: pt.id,
          point: pt,
        });
      }
    }

    const pushFacility = (lng: number, lat: number, kind: FacilityMapKind, id: string, name: string) => {
      const recObj = findFacilityRecord(kind, id);
      if (!recObj) return;
      if (!facilityPassesWaterEnvLayer(poiLayerSlice, kind, recObj as Record<string, unknown>)) return;
      const cat = facilityKindToWaterEnvCategory(kind);
      const st = deriveFacilityDisplayState(kind, recObj as Record<string, unknown>);
      const hit = facilitySearchHitByKindId.get(`${kind}:${id}`);
      const canShowFacilityHint = poiFacilityTitle && facilityHintCount < ZHT_POI_FACILITY_HINT_CAP;

      const root = document.createElement('div');
      if (canShowFacilityHint) {
        appendFacilityPoiHint(
          root,
          name,
          zhtPoiHintFontPx(poiFacilityTitleFont),
          hit ? `${hit.idx} ` : undefined,
        );
        facilityHintCount += 1;
      }
      const dot = createWaterEnvCategoryDot(cat, st);

      if (hit) {
        dot.classList.add('zht-map-point-dot--search-hit');
        if (searchMapSelectedPointId === hit.unifiedId) {
          dot.classList.add('zht-map-point-dot--search-hit--selected');
        }
        const showIdxBadge = !canShowFacilityHint;
        const wrap = document.createElement('div');
        wrap.className = 'zht-map-poi-search-hit-wrap';
        if (passThrough) {
          wrap.classList.add('zht-map-poi-search-hit-wrap--pass-through');
        }
        wrap.appendChild(dot);
        if (showIdxBadge) {
          const badge = document.createElement('span');
          badge.className = 'zht-map-search-hit-badge';
          badge.textContent = hit.idx;
          badge.setAttribute('aria-label', `查询结果序号 ${hit.idx}`);
          wrap.appendChild(badge);
        }
        wrap.addEventListener('click', e => {
          e.stopPropagation();
          if (spatialPickActiveRef.current) return;
          onSearchMapResultClickRef.current?.(hit.point);
        });
        bindHitHover(wrap);
        root.appendChild(wrap);
      } else {
        if (passThrough) {
          dot.classList.add('zht-map-point-dot--pass-through');
        }
        dot.addEventListener('click', e => {
          e.stopPropagation();
          if (spatialPickActiveRef.current) return;
          openFacilityDetailRef.current(kind, id);
        });
        bindHitHover(dot);
        root.appendChild(dot);
      }
      mountMarker(lng, lat, root);
    };

    for (const r of pumpStationData) {
      pushFacility(r.x, r.y, 'pump', r.id, r.name);
    }
    for (const r of outletData) {
      pushFacility(r.x, r.y, 'outlet', r.id, r.name);
    }
    for (const r of plantData) {
      pushFacility(r.x, r.y, 'plant', r.id, r.name);
    }

    for (const mon of ZHT_MONITORING_POI_DEMO) {
      if (!monitorDemoPassesWaterEnvLayer(poiLayerSlice, mon)) continue;
      const mHit = monitorSearchHitByMonId.get(mon.id);
      const root = document.createElement('div');
      const showHintCard = poiMonitorTitle || poiMonitorValues;
      if (showHintCard) {
        appendMonitorPoiHint(
          root,
          mon,
          poiMonitorTitle,
          poiMonitorValues,
          zhtPoiHintFontPx(poiMonitorTitleFont),
          zhtPoiHintFontPx(poiMonitorValuesFont),
          mHit && poiMonitorTitle ? `${mHit.idx} ` : undefined,
        );
      }
      const dot = createWaterEnvCategoryDot('monitor', monitorPointStateToDisplay(mon.pointState));
      if (mHit) {
        dot.classList.add('zht-map-point-dot--search-hit');
        if (searchMapSelectedPointId === mHit.unifiedId) {
          dot.classList.add('zht-map-point-dot--search-hit--selected');
        }
        const showIdxBadge = !showHintCard || !poiMonitorTitle;
        const wrap = document.createElement('div');
        wrap.className = 'zht-map-poi-search-hit-wrap';
        if (passThrough) {
          wrap.classList.add('zht-map-poi-search-hit-wrap--pass-through');
        }
        wrap.appendChild(dot);
        if (showIdxBadge) {
          const badge = document.createElement('span');
          badge.className = 'zht-map-search-hit-badge';
          badge.textContent = mHit.idx;
          badge.setAttribute('aria-label', `查询结果序号 ${mHit.idx}`);
          wrap.appendChild(badge);
        }
        wrap.addEventListener('click', e => {
          e.stopPropagation();
          if (spatialPickActiveRef.current) return;
          onSearchMapResultClickRef.current?.(mHit.point);
        });
        bindHitHover(wrap);
        root.appendChild(wrap);
      } else {
        root.appendChild(dot);
      }
      mountMarker(mon.lng, mon.lat, root);
    }

    const pushUnifiedOtherWaterEnv = (pt: ZhtUnifiedSearchPoint) => {
      const c = getWaterEnvCategoryForUnifiedPoint(pt);
      if (!c || !ZHT_WATER_ENV_UNIFIED_ONLY.has(c)) return;
      if (!unifiedPointPassesWaterEnvLayer(poiLayerSlice, pt)) return;
      const hit = overlayHitByUnifiedId.get(pt.id);
      const canShowFacilityHint = poiFacilityTitle && facilityHintCount < ZHT_POI_FACILITY_HINT_CAP;
      const root = document.createElement('div');
      if (canShowFacilityHint) {
        appendFacilityPoiHint(
          root,
          `${pt.pointType} · ${pt.name}`,
          zhtPoiHintFontPx(poiFacilityTitleFont),
          hit ? `${hit.idx} ` : undefined,
        );
        facilityHintCount += 1;
      }
      const st = deriveDisplayStateForUnifiedPoint(pt);
      const dot = createWaterEnvCategoryDot(c, st);
      if (hit) {
        dot.classList.add('zht-map-point-dot--search-hit');
        if (searchMapSelectedPointId === hit.unifiedId) {
          dot.classList.add('zht-map-point-dot--search-hit--selected');
        }
        const showIdxBadge = !canShowFacilityHint;
        const wrap = document.createElement('div');
        wrap.className = 'zht-map-poi-search-hit-wrap';
        if (passThrough) {
          wrap.classList.add('zht-map-poi-search-hit-wrap--pass-through');
        }
        wrap.appendChild(dot);
        if (showIdxBadge) {
          const badge = document.createElement('span');
          badge.className = 'zht-map-search-hit-badge';
          badge.textContent = hit.idx;
          badge.setAttribute('aria-label', `查询结果序号 ${hit.idx}`);
          wrap.appendChild(badge);
        }
        wrap.addEventListener('click', e => {
          e.stopPropagation();
          if (spatialPickActiveRef.current) return;
          onSearchMapResultClickRef.current?.(hit.point);
        });
        bindHitHover(wrap);
        root.appendChild(wrap);
      } else {
        if (passThrough) {
          dot.classList.add('zht-map-point-dot--pass-through');
        }
        dot.addEventListener('click', e => {
          e.stopPropagation();
          if (spatialPickActiveRef.current) return;
          openUnifiedSearchPointDetailRef.current?.(pt);
        });
        bindHitHover(dot);
        root.appendChild(dot);
      }
      mountMarker(pt.lng, pt.lat, root);
    };

    for (const pt of getZhtUnifiedSearchPointsCached()) {
      pushUnifiedOtherWaterEnv(pt);
    }

    poiMarkersRef.current = next;
    requestAnimationFrame(() => {
      if (!map.loaded()) return;
      for (const m of next) {
        m.setLngLat(m.getLngLat());
      }
      map.triggerRepaint();
    });

    return () => {
      poiMarkerResizeObserversRef.current.forEach(ro => ro.disconnect());
      poiMarkerResizeObserversRef.current = [];
      clearMarkers();
    };
  }, [
    mapIsReady,
    mapSearchPanelOpen,
    mapSearchShowDefaultPoiMarkers,
    spatialMapPickActive,
    searchMapOverlay,
    searchMapSelectedPointId,
    poiFacilityTitle,
    poiFacilityTitleFont,
    poiMonitorTitle,
    poiMonitorValues,
    poiMonitorTitleFont,
    poiMonitorValuesFont,
    layerControl,
  ]);

  return (
    <>
      <div ref={stackRef} className="zht-maplibre-stack">
            <ZhtMapVerticalToolbar
          mapRef={mapRef}
          fullscreenTargetRef={stackRef}
          onSearchClick={() => onToggleMapSearch?.()}
          layerControl={layerControl}
          onLayerControlChange={onLayerControlChange}
          poiFacilityTitle={poiFacilityTitle}
          onPoiFacilityTitleChange={setPoiFacilityTitle}
          poiMonitorTitle={poiMonitorTitle}
          poiMonitorValues={poiMonitorValues}
          onPoiMonitorTitleChange={setPoiMonitorTitle}
          onPoiMonitorValuesChange={setPoiMonitorValues}
          poiFacilityTitleFont={poiFacilityTitleFont}
          onPoiFacilityTitleFontChange={setPoiFacilityTitleFont}
          poiMonitorTitleFont={poiMonitorTitleFont}
          onPoiMonitorTitleFontChange={setPoiMonitorTitleFont}
          poiMonitorValuesFont={poiMonitorValuesFont}
          onPoiMonitorValuesFontChange={setPoiMonitorValuesFont}
          onPoiHintsReset={resetPoiHintsToDefault}
          defaultCenter={PARK_MAPLIBRE_DEFAULT_CENTER}
          defaultZoom={PARK_MAPLIBRE_DEFAULT_ZOOM}
        />
        <div
          className="zht-maplibre-host"
          ref={containerRef}
          role="application"
          aria-label="MapLibre 地图"
        />
      </div>
      <Modal
        styles={detailModalStyles}
        title={detailTitle}
        open={detailOpen}
        onCancel={() => {
          setDetailOpen(false);
          setDetailModalWidth(ZHT_MAP_OTHER_DETAIL_WIDTH);
        }}
        footer={null}
        width={detailModalWidth}
        destroyOnClose
      >
        <div key={detailKey}>{detailBody}</div>
      </Modal>
    </>
  );
};
