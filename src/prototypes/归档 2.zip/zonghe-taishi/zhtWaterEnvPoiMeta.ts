/**
 * 综合态势 · 水环境 POI 图层元数据（分类、数量、四态业务说明、与统一点位/地图台账的关联）
 */
import type { ZhtMonitorPointState } from './zhtPoiMonitoringDemo';
import { ZHT_MONITORING_POI_DEMO } from './zhtPoiMonitoringDemo';
import {
  pumpStationData,
  outletData,
  plantData,
} from '../韶山水环境设施管理系统/facility-points-data';
import type { ZhtFacilityMapKind, ZhtUnifiedSearchPoint } from './zhtSearchUnifiedData';
import {
  getZhtUnifiedSearchPointsCached,
  parseZhtFacilityUnifiedSearchId,
  parseZhtMonitorUnifiedSearchId,
} from './zhtSearchUnifiedData';

/** 与产品一致的四态（地图颜色：报警红、离线灰、在线绿、信息点蓝） */
export type ZhtPoiDisplayState = 'alarm' | 'offline' | 'online' | 'info';

export type ZhtPoiStateToggles = Record<ZhtPoiDisplayState, boolean>;

/** 系统管理 · 水利设施七类（各自独立图层与计数） */
export type ZhtSysHydroCategoryId =
  | 'sys_zhaba'
  | 'sys_diba'
  | 'sys_shuiku'
  | 'sys_shuizha'
  | 'sys_weiqu'
  | 'sys_yandi'
  | 'sys_shantang';

/** 水环境 POI 类型（不含「自定义标注」） */
export type ZhtWaterEnvCategoryId =
  | 'pump'
  | 'outlet'
  | 'plant'
  | 'monitor'
  | 'eco_project'
  | 'eco_affair'
  | 'emg_supply'
  | 'emg_event'
  | ZhtSysHydroCategoryId;

/** 系统管理水利子类顺序（图层 Popover 内分组展示） */
export const ZHT_SYS_HYDRO_CATEGORY_ORDER: ZhtSysHydroCategoryId[] = [
  'sys_zhaba',
  'sys_diba',
  'sys_shuiku',
  'sys_shuizha',
  'sys_weiqu',
  'sys_yandi',
  'sys_shantang',
];

export const ZHT_WATER_ENV_CATEGORY_ORDER: ZhtWaterEnvCategoryId[] = [
  'pump',
  'outlet',
  'plant',
  'monitor',
  'eco_project',
  'eco_affair',
  'emg_supply',
  'emg_event',
  ...ZHT_SYS_HYDRO_CATEGORY_ORDER,
];

export type ZhtWaterEnvCategoryMeta = {
  id: ZhtWaterEnvCategoryId;
  /** 列表主标题（不含数据来源前缀；数量由运行时拼接） */
  label: string;
  /** 图层说明问号：含数据来源与业务说明 */
  help: string;
  /** 与 `zhtWaterEnvPoiDotIcons` / 地图圆点中心 icon 对应 */
  iconKey: ZhtWaterEnvCategoryId;
};

export const ZHT_WATER_ENV_CATEGORY_META: ZhtWaterEnvCategoryMeta[] = [
  {
    id: 'pump',
    label: '泵站',
    iconKey: 'pump',
    help: '数据来源：设施管理台账（泵站）。单点仅展示一种状态，优先级：报警＞离线＞在线＞信息点。信息点（蓝）为默认；在线（绿）表示已关联物联设备；离线（灰）表示监测参数无有效数据；报警（红）表示监测参数存在 I～IV 级报警（演示由台账状态推导）。',
  },
  {
    id: 'outlet',
    label: '排口',
    iconKey: 'outlet',
    help: '数据来源：设施管理台账（排放口）。状态规则同泵站。',
  },
  {
    id: 'plant',
    label: '污水厂',
    iconKey: 'plant',
    help: '数据来源：设施管理台账（污水处理厂）。状态规则同泵站。',
  },
  {
    id: 'monitor',
    label: '水质监测站',
    iconKey: 'monitor',
    help: '数据来源：设施管理侧水质监测类 POI（演示点与 `ZHT_MONITORING_POI_DEMO` 同源）。四态与图层勾选联动。',
  },
  {
    id: 'eco_project',
    label: '项目',
    iconKey: 'eco_project',
    help: '数据来源：生态整治（责任河段等项目类点位，河段中点坐标）。演示四态由数据哈希分布。',
  },
  {
    id: 'eco_affair',
    label: '事务',
    iconKey: 'eco_affair',
    help: '数据来源：生态整治（事务类演示点位）。',
  },
  {
    id: 'emg_supply',
    label: '社会物资',
    iconKey: 'emg_supply',
    help: '数据来源：应急协同（社会物资类演示点位）。',
  },
  {
    id: 'emg_event',
    label: '应急事件',
    iconKey: 'emg_event',
    help: '数据来源：应急协同（应急事件类点位，与应急原型演示数据一致）。',
  },
  {
    id: 'sys_zhaba',
    label: '闸坝',
    iconKey: 'sys_zhaba',
    help: '数据来源：系统管理 · 水利设施台账（闸坝类演示点）。四态规则与其它水环境 POI 一致。',
  },
  {
    id: 'sys_diba',
    label: '堤坝',
    iconKey: 'sys_diba',
    help: '数据来源：系统管理 · 水利设施台账（堤坝类演示点）。',
  },
  {
    id: 'sys_shuiku',
    label: '水库',
    iconKey: 'sys_shuiku',
    help: '数据来源：系统管理 · 水利设施台账（水库类；含园区默认视野等演示锚点）。',
  },
  {
    id: 'sys_shuizha',
    label: '水闸',
    iconKey: 'sys_shuizha',
    help: '数据来源：系统管理 · 水利设施台账（水闸类演示点）。',
  },
  {
    id: 'sys_weiqu',
    label: '圩区',
    iconKey: 'sys_weiqu',
    help: '数据来源：系统管理 · 水利设施台账（圩区类演示点）。',
  },
  {
    id: 'sys_yandi',
    label: '堰堤',
    iconKey: 'sys_yandi',
    help: '数据来源：系统管理 · 水利设施台账（堰堤类演示点）。',
  },
  {
    id: 'sys_shantang',
    label: '山塘',
    iconKey: 'sys_shantang',
    help: '数据来源：系统管理 · 水利设施台账（山塘类演示点）。',
  },
];

/** 主列表（不含系统管理水利分组；Popover 中水利七类单独折叠展示） */
export const ZHT_WATER_ENV_MAIN_CATEGORY_ORDER: ZhtWaterEnvCategoryId[] = [
  'pump',
  'outlet',
  'plant',
  'monitor',
  'eco_project',
  'eco_affair',
  'emg_supply',
  'emg_event',
];

export const ZHT_POI_STATE_HELP: Record<ZhtPoiDisplayState, string> = {
  alarm: '超限报警（红）：监测参数存在 I～IV 级报警时展示（演示数据见监测指标 tone）。',
  offline: '离线（灰）：监测参数均无有效数据时展示。',
  online: '在线（绿）：点位已关联物联设备且数据有效时展示。',
  info: '信息点（蓝）：默认展示态。',
};

export const ALL_POI_STATES_ON: ZhtPoiStateToggles = {
  alarm: true,
  offline: true,
  online: true,
  info: true,
};

/** 统一点位 `pointType` → 系统管理水利子图层（须与演示数据一致） */
const SYS_HYDRO_POINT_TYPE_TO_CAT: Record<string, ZhtSysHydroCategoryId> = {
  闸坝: 'sys_zhaba',
  堤坝: 'sys_diba',
  水库: 'sys_shuiku',
  水闸: 'sys_shuizha',
  圩区: 'sys_weiqu',
  堰堤: 'sys_yandi',
  山塘: 'sys_shantang',
};

/** 监测演示态 → 四态展示（与图层勾选文案一致） */
export function monitorPointStateToDisplay(st: ZhtMonitorPointState): ZhtPoiDisplayState {
  if (st === 'alarm') return 'alarm';
  if (st === 'offline') return 'offline';
  if (st === 'normal') return 'online';
  return 'info'; // general → 信息点（蓝）
}

function hash32(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i += 1) h = (Math.imul(31, h) + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}

/** 设施台账：演示推导四态（优先语义关键字，否则哈希分布） */
export function deriveFacilityDisplayState(
  kind: ZhtFacilityMapKind,
  record: Record<string, unknown>,
): ZhtPoiDisplayState {
  const status = String(record.status ?? '');
  if (/报警|超标|超限|IV级|III级|II级|I级/i.test(status)) return 'alarm';
  if (/离线|无数据|停运|维护|停机|--/i.test(status)) return 'offline';
  if (/运行|在线|正常|良好/i.test(status)) return 'online';
  const id = String(record.id ?? record.name ?? kind);
  const r = hash32(`${kind}:${id}`) % 4;
  return (['info', 'online', 'offline', 'alarm'] as const)[r];
}

/** 统一点位：监测走演示表；设施走台账；其它走哈希四态（演示） */
export function deriveDisplayStateForUnifiedPoint(p: ZhtUnifiedSearchPoint): ZhtPoiDisplayState {
  const monId = parseZhtMonitorUnifiedSearchId(p.id);
  if (monId) {
    const mon = ZHT_MONITORING_POI_DEMO.find(m => m.id === monId.rawMonId);
    if (mon) return monitorPointStateToDisplay(mon.pointState);
  }
  const fac = parseZhtFacilityUnifiedSearchId(p.id);
  if (fac) {
    if (fac.kind === 'pump') {
      const r = pumpStationData.find(x => x.id === fac.rawId);
      if (r) return deriveFacilityDisplayState('pump', r as unknown as Record<string, unknown>);
    }
    if (fac.kind === 'outlet') {
      const r = outletData.find(x => x.id === fac.rawId);
      if (r) return deriveFacilityDisplayState('outlet', r as unknown as Record<string, unknown>);
    }
    if (fac.kind === 'plant') {
      const r = plantData.find(x => x.id === fac.rawId);
      if (r) return deriveFacilityDisplayState('plant', r as unknown as Record<string, unknown>);
    }
  }
  const r = hash32(p.id) % 4;
  return (['info', 'online', 'offline', 'alarm'] as const)[r];
}

/** 统一点位所属水环境图层分类；无法识别则 null */
export function getWaterEnvCategoryForUnifiedPoint(p: ZhtUnifiedSearchPoint): ZhtWaterEnvCategoryId | null {
  if (parseZhtMonitorUnifiedSearchId(p.id)) return 'monitor';
  const fac = parseZhtFacilityUnifiedSearchId(p.id);
  if (fac?.kind === 'pump') return 'pump';
  if (fac?.kind === 'outlet') return 'outlet';
  if (fac?.kind === 'plant') return 'plant';
  if (p.id.startsWith('zht-river-sec-')) return 'eco_project';
  if (p.sourceProject === '生态整治') return 'eco_affair';
  if (p.pointType === '社会物资' || p.id.startsWith('zht-emg-supply')) return 'emg_supply';
  if (p.sourceProject === '应急协同') return 'emg_event';
  if (p.sourceProject === '系统管理') {
    const sub = SYS_HYDRO_POINT_TYPE_TO_CAT[p.pointType];
    return sub ?? null;
  }
  return null;
}

export function countUnifiedPointsByCategory(): Record<ZhtWaterEnvCategoryId, number> {
  const pts = getZhtUnifiedSearchPointsCached();
  const out = {} as Record<ZhtWaterEnvCategoryId, number>;
  for (const id of ZHT_WATER_ENV_CATEGORY_ORDER) {
    out[id] = 0;
  }
  for (const p of pts) {
    const c = getWaterEnvCategoryForUnifiedPoint(p);
    if (c) out[c] += 1;
  }
  return out;
}

export type ZhtWaterEnvCategoryLayer = {
  enabled: boolean;
  states: ZhtPoiStateToggles;
};

export type ZhtWaterEnvPoiLayers = Record<ZhtWaterEnvCategoryId, ZhtWaterEnvCategoryLayer>;

export const DEFAULT_WATER_ENV_POI_LAYERS: ZhtWaterEnvPoiLayers = (() => {
  const layer = (enabled: boolean): ZhtWaterEnvCategoryLayer => ({
    enabled,
    states: { ...ALL_POI_STATES_ON },
  });
  return Object.fromEntries(ZHT_WATER_ENV_CATEGORY_ORDER.map(id => [id, layer(true)])) as ZhtWaterEnvPoiLayers;
})();

/** 图层切片（避免与 `zhtLayerControlState` 循环依赖） */
export type ZhtWaterEnvPoiLayerControlSlice = {
  waterEnvPoiEnabled: boolean;
  waterEnvPoiLayers: ZhtWaterEnvPoiLayers;
};

/** 某统一点位是否应绘制在地图（水环境总开关 + 分类开关 + 四态开关） */
export function unifiedPointPassesWaterEnvLayer(slice: ZhtWaterEnvPoiLayerControlSlice, p: ZhtUnifiedSearchPoint): boolean {
  if (!slice.waterEnvPoiEnabled) return false;
  const cat = getWaterEnvCategoryForUnifiedPoint(p);
  if (!cat) return false;
  const L = slice.waterEnvPoiLayers[cat];
  if (!L?.enabled) return false;
  const st = deriveDisplayStateForUnifiedPoint(p);
  return L.states[st] === true;
}

/** 设施台账记录在图层下是否显示 */
export function facilityPassesWaterEnvLayer(
  slice: ZhtWaterEnvPoiLayerControlSlice,
  kind: ZhtFacilityMapKind,
  record: Record<string, unknown>,
): boolean {
  if (!slice.waterEnvPoiEnabled) return false;
  const cat: ZhtWaterEnvCategoryId = kind === 'pump' ? 'pump' : kind === 'outlet' ? 'outlet' : 'plant';
  const L = slice.waterEnvPoiLayers[cat];
  if (!L?.enabled) return false;
  const st = deriveFacilityDisplayState(kind, record);
  return L.states[st] === true;
}

/** 监测演示点在图层下是否显示 */
export function monitorDemoPassesWaterEnvLayer(
  slice: ZhtWaterEnvPoiLayerControlSlice,
  mon: (typeof ZHT_MONITORING_POI_DEMO)[0],
): boolean {
  if (!slice.waterEnvPoiEnabled) return false;
  const L = slice.waterEnvPoiLayers.monitor;
  if (!L?.enabled) return false;
  const st = monitorPointStateToDisplay(mon.pointState);
  return L.states[st] === true;
}
