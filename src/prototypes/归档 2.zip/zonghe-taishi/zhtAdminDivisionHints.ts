/**
 * 综合态势 · 行政区划名称提示（演示点位与零直排指标，非真实行政区划面数据）
 */

/** 行政区划提示板一条演示数据 */
export type ZhtAdminDivisionHintDemo = {
  id: string;
  /** 提示标题（如乡镇/片区名） */
  name: string;
  lng: number;
  lat: number;
  /** 雨污分流是否达标（演示） */
  rainSewageDiversionOk: boolean;
  /** 污水零直排是否达标（演示） */
  zeroDirectSewageOk: boolean;
};

/** 与底图园区附近坐标量级一致，便于一眼看到多块提示板 */
export const ZHT_ADMIN_DIVISION_HINTS_DEMO: ZhtAdminDivisionHintDemo[] = [
  {
    id: 'adm-1',
    name: '高新区',
    lng: 112.531,
    lat: 27.921,
    rainSewageDiversionOk: true,
    zeroDirectSewageOk: false,
  },
  {
    id: 'adm-2',
    name: '韶山乡',
    lng: 112.518,
    lat: 27.915,
    rainSewageDiversionOk: true,
    zeroDirectSewageOk: true,
  },
  {
    id: 'adm-3',
    name: '银田镇',
    lng: 112.545,
    lat: 27.908,
    rainSewageDiversionOk: false,
    zeroDirectSewageOk: false,
  },
];
