# 综合态势

## 业务与功能

### 1.1 核心目标

「综合态势」为韶山高新区水环境综合整治一张图的**大屏总览入口**，在一屏内整合管网与水利设施指标、动态感知摘要、应急资源概况、地理底图上的**设施管理同源台账点位**（泵站、排口、污水厂）与**右侧水质与报警分析看板**（示例数据）。目标用户为指挥中心值班与管理决策人员，需快速把握全局态势并在地图上打开与 **韶山水环境设施管理系统** 列表 **详情** 一致的弹窗内容。

### 1.2 功能清单

- **顶栏**：已按产品要求移除，不再展示系统标题、主导航与用户信息。
- **左右侧栏背景（P0）**：**`.zht-left`**（左侧指标区）与 **`.zht-right-rail`**（右侧分析看板 / 地图搜索）栏体背景为 **纯白**（`style.css` 中 **`--panel-bg: #ffffff`**）。
- **左侧指标区（P0）**：四段标题——「管网概况」「动态感知」「水利设施」「应急协同」；**管网概况**（雨水/污水管网 km、检查井）、**动态感知**（管网监测、水源地、排放口、污水厂、泵站、水质监测点、河道站、入河排口、闸门、河流断面等）、**水利设施**（河流、湖泊、山塘、闸站、闸坝、堤防）、**应急协同**（风险源企业、污染源、排水户、应急预案、物资点、应急物资、队伍、专家、应急事件等），数值与条目对齐**当前产品设计稿**（三列网格）。**管网概况 / 水利设施**卡片为**浅绿底深绿字**，**动态感知 / 应急协同**为**浅蓝底深蓝字**；部分项右上角**黄色数字徽章**（示例：水源地 36、泵站 37、应急预案 40、应急物资 39、应急事件 38）。卡片信息结构为**主数值在上、标签在下**。
- **地图区（P0）**：MapLibre；底图与 **工业园区** `park-boundary-maplibre.tsx` **严格同源**：仅 **`PARK_MAPLIBRE_STYLE_URL`**（OpenFreeMap Liberty），**不**使用 Esri、OSM、Carto 等其它底图来源。默认中心与缩放与园区导出常量一致；台账坐标来自 **`../韶山水环境设施管理系统/facility-points-data.ts`**（与设施管理列表同源；**地图**上水环境 POI **可见圆点**为 **`maplibregl.Marker` 内 DOM**（`style.css` **`.zht-map-point-dot--water-env`** 等）：圆点 **中心为分类图标**（与 **`zhtWaterEnvPoiDotIcons.ts`**、图层控制图例一致），外圈底色为 **四态**——**报警 `#ff4d4f`、离线 `#8c8c8c`、在线 `#52c41a`、信息点 `#1677ff`**（监测由 **`zhtPoiMonitoringDemo.ts`** 的 **`pointState`** 经 **`monitorPointStateToDisplay`** 映射；设施由 **`deriveFacilityDisplayState`**；其它统一点位由 **`deriveDisplayStateForUnifiedPoint`** 演示）；**搜索命中**时整圆改为 **橙** `#fa8c16`**；**点击设施圆点**打开 **Ant Design Modal**（宽 `min(1200px, 96vw)`、内容区滚动规则与设施管理 `detailModalStyles` 一致），内嵌 **`PumpDetailContent` / `OutletDetailContent` / `PlantDetailContent`**（与列表「详情」同一套 Tab：基本信息 / 实时监测 / 视频监控等）。**不再**使用底栏「地图 / 概览图 / 遥感」与底栏图层勾选。
- **地图左上角纵向工具条（P0，`zhtMapVerticalToolbar.tsx`）**：叠在地图画布**左上角**（`zht-maplibre-stack` 内 `position:absolute`，`left/top: 12px`），白底半透明条 + 圆角阴影。自上而下 **13** 项（与设计稿序号一致）：①**搜索**（**非弹窗**：工具条点击后 **`index.tsx`** 将右侧 **`ZhtRightDashboard`** 切换为 **`ZhtMapSearchPanel`**（`aside.zht-right-rail--map-search`），再点搜索或面板内 **「返回分析看板」** 切回；地图板在 **`load`** 后向 **`mapSearchFlyToRef`** 注册 **`flyTo`**，供结果卡片联动）。面板内 **`Tabs`**「**条件查询** / **空间要素查询**」（**切换 Tab** 时 **`resetQueryState({ silent: true })`**；**空间要素**内切换 **数据点位 / 地图标记** **Radio** 时 **`resetQueryState({ silent: true, spatialOriginKind })`**：均与底部 **重置** 同逻辑，**不**弹成功 **`message`**）；**条件查询**为纵向若干 **Select / Input**（**无表单项标题**，语义在 **placeholder** 与 **`aria-label`**：选择区域、设施类型、选择状态、名称/编码模糊匹配），底部 **查询 / 导出 / 重置**；**空间要素查询**须指定 **查询原点 + 半径（米）**：原点为 **数据点位**（下拉必选一条台账）或 **地图标记**（「在地图上选点」后 **`spatialMapPickActive`** 十字光标，**`zhtMaplibreBoard`** 在空白或设施圆点上取 **`lngLat`** 回调 **`onSpatialMapPick`** 写入 **`spatialOriginFromMap`**，可「清除原点」）；**数据点位**原点时可再选 **区域（可选）**、**查询类型**、**半径米数**；**地图标记**原点时 **不展示「区域」**，仅 **查询类型**、**半径米数**；同样 **查询 / 导出 / 重置**；共用 **「查询结果 N 条」** 与 **卡片列表**（**卡片标题旁序号**与地图上条件/空间查询结果点 **序号 1…N 一一对应**），**点击卡片** → **`mapSearchFlyToRef`** 定位地图（**左侧指标栏不因搜索联动**）；**导出** UTF-8 BOM **`.csv`**（首列为序号）。四项目数据仍聚合于 **`zhtSearchUnifiedData.ts`**。**地图 DOM 圆点与 HTML 提示板分工**：**水环境 POI DOM 圆点**由 **③ 图层控制** 显隐，**不受** **② POI提示配置** 开关隐藏；**`maplibregl.Marker` HTML 提示板**显隐由 **② POI提示配置**（`Popover`：**设施类**「标题显示」、**监测类**「标题显示 / 数值显示」）控制；设施圆点 **`pointer-events: auto`** 可点详情；提示板 **`pointer-events: none`**；设施仅站名、监测含标题与多指标；**`zhtPoiMonitoringDemo.ts`**、**`tone`** 五色数值 + 灰色单位；设施提示条数上限约 **28**；**水环境 POI** DOM 点与提示板随 **③ 图层控制** 中 **各业务分类 + 四态子项**（**`zhtWaterEnvPoiMeta.ts`** / **`waterEnvPoiLayers`**）与地图 Marker 列表同步。②**POI提示配置**（`MessageSquare`；Popover 打开时 `zht-map-tool-btn--on`）③**图层控制**（`Popover` 内 **水环境 POI**：主类为业务简称（数据来源在「?」），**四态筛选**为行前 **下拉箭头** 展开；系统管理水利为 **`Collapse`** 分组，内含 **闸坝 / 堤坝 / 水库 / 水闸 / 圩区 / 堰堤 / 山塘** 七类独立图层，各含四态与 **`countUnifiedPointsByCategory`** 计数；**自定义标注** 仍为单层占位、无四态）④**视频点位** ⑤**地图样式** ⑥**地图标注** ⑦**地图视角** ⑧**地图视图导出** ⑨**量尺工具** —— 除 **搜索** 与 **POI提示配置 / 图层控制** 外，其余按钮当前多为 **`message.info` 占位**；⑩**全屏**（浏览器 Fullscreen API，目标为地图栈容器）；⑪**恢复默认中心/缩放/俯仰/旋转**（`flyTo` 园区常量）；⑫**放大、缩小**（`zoomIn` / `zoomOut`）；⑬**指北**（`resetNorth`）。**图标**：现阶段统一使用 **`lucide-react` 线框图标**占位，便于后续逐项替换为设计稿 **SVG**。已移除 MapLibre 默认 **`NavigationControl`**（缩放改由工具条）。
- **地名注记**：由 **OpenFreeMap Liberty** 矢量样式注记层呈现（与工业园区同源）。**不再**单独叠 HTML 乡镇字，避免与真实地理错位。
- **右侧栏（P0）**：与中间地图列并列，同宽 **`zht-right-rail`**。**默认**渲染 **`ZhtRightDashboard`**（分析看板）：**断面达标**、**汛期污染** 两卡 **`flex: 1 1 0`** 均分右栏余下高度，卡片内 **`overflow` 可滚动** 适配；**排口报警日历** 为 **「年月」在左、图例在右同一行**（`zht-cal-meta-row`），**月历格不竖向滚动**；日历卡片 **不参与三等分拉伸**（`flex: 0 0 auto`），日期下方不留空，多出的垂直空间由 **断面达标 / 汛期污染** 两卡分担。**汛期污染强度**表为 **CSS Grid**：**断面名称**列最宽，**污染强度**与 **时间**列 **`column-gap`** 留白，**时间**列展示偏窄（完整时间 **`Tooltip`**）。**地图搜索**时同一位置切换为 **`ZhtMapSearchPanel`**（`zht-right-rail--map-search`），含 **返回分析看板** 链接触发切回；右栏与地图列**同高**，表单与 Tab 固定高度，**「查询结果」列表区域 `flex:1` 占满余下空间**，仅在 **`.zht-search-results__list`** 内纵向滚动，避免结果卡片下方大块留白。

### 1.3 交互要点

- **图层控制**（**`zhtLayerControlPopover`** + **`zhtLayerControlState`**，**`index.tsx`** 单例状态经 **`ZhtMaplibreBoard`** 下 **`ZhtMapVerticalToolbar`**）：**行政区划** 勾选后地图挂载行政名称提示（**`zhtAdminDivisionHints.ts`** 演示点 + **`appendAdminDivisionCard`**）；**零直排区域标注** 控制上述提示板内 **雨污分流 / 污水零直排** 达标文案显隐，**达标** 绿色、**不达标** 红色。**水环境POI点位** 总开关关则各业务图层（泵站、排口、污水厂、水质监测站、生态整治项目/事务、应急物资/事件，及系统管理水利下闸坝、堤坝、水库、水闸、圩区、堰堤、山塘等）及对应四态 **均不绘点**；主类为业务简称 + 括号数量，数据来源见各类旁「?」；**紧凑树形**：行首 **小三角在复选框左侧**，展开/收合后仅四态子勾选（**信息点 / 在线 / 离线 / 超限报警**）；系统管理水利 **七类与主类同列平铺**（无「系统管理·水利设施」再下钻分组）；**不**再单独列出「水库（占位）」「山塘」占位项；**排水户、排水企业、污染源、自定义标注** 为演示占位，标签前带 **Lucide 图例 icon**（与主类图例风格一致）；**自定义标注** 无四态。**图层优先于 POI 提示配置**：某类或某态关闭时 **圆点与提示板均不展示**；图层开时提示板仍受 **POI提示配置** 勾选与字号控制。**排水管网、排水网格、排水单元、管线流向、遥感、疑似问题图斑、河流流向可视化、生态红线、河流动态模拟、水位与淹没分析** 等为 **演示占位**（各分组标题后 **?** 图标 **`Tooltip`** 内为说明文案；未接服务项为占位说明）。**遥感监测** 占位下可选 **叶绿素 / 悬浮物** 单选（不接瓦片）。
- 在工具条 **「POI提示配置」** 中切换 **设施类「标题显示」**、**监测类「标题显示 / 数值显示」** → **仅**影响 **已因图层显示在地图上** 的 **`maplibregl.Marker` HTML 提示板**挂载与内容；**不**替代图层隐藏圆点。
- 点击 **设施 DOM 圆点** → 打开设施详情 Modal（右上角关闭 / 遮罩 / ESC）；每次打开递增 `key` 避免 Tab 状态串单。**右侧「地图搜索」面板打开时**（`index.tsx` **`mapSearchPanelOpen`** → **`zhtMaplibreBoard`**）：除 **「空间要素查询」Tab + 原点为数据点位 + 尚无查询覆盖层**（**`searchMapOverlay == null`**，即未点「查询」）外，地图 **隐藏** 默认台账/监测 DOM 点，**仅**绘 **`searchMapOverlay.results`**：**设施 / 监测** 与看板一致为 **POI 提示板 + 台账圆点（搜索命中橙态，`anchor: bottom`）**；其它统一点位在 **POI提示配置** 开启 **设施类标题** 时为 **简要标题提示 + 橙点**，否则为 **居中橙色序号 Marker**（`style.css` **`.zht-map-search-result-hit*`**）。上述过渡态由 **`mapSearchShowDefaultPoiMarkers`**（**`ZhtMapSearchPanel`** 经 **`onMapSearchContextChange`** 同步 Tab / 原点模式后 **`index.tsx`** 计算）驱动：**恢复** 默认台账/监测 DOM 与 POI 逻辑，便于在下拉里对照地图选数据原点；**提交查询** 得到 **`searchMapOverlay`** 后仍 **仅** 展示结果集点位。点击结果 Marker → **`flyTo` + 选中**（`onSearchMapResultClick`）并 **打开详情**：设施走 **`PumpDetailContent` / `OutletDetailContent` / `PlantDetailContent`**（弹窗 **`detailModalStyles`** 与宽度 **`min(1200px, 96vw)`** 与设施管理列表「详情」一致）；监测与其它统一点位走 **`UnifiedSearchPointDetailContent`**（**`detail-section` + `Descriptions bordered`**，与管点类只读详情同源视觉，宽度 **800px**）。关闭搜索回到分析看板后恢复默认全量点位与 POI 提示逻辑。
- 右侧为 **地图搜索** 时，执行查询后点击 **结果卡片** → 中间地图 **`flyTo`** 该点位（由 `mapSearchFlyToRef` 触发）；**不**联动左侧指标栏高亮。
- **地图搜索 · 重置**：**条件查询**与 **空间要素查询** Tab 底部均有 **重置**（`ZhtMapSearchPanel` **`resetQueryState`**）：**`conditionForm.resetFields`**；空间表单恢复挂载初值（区域/原点/类型清空，半径 **3000**，类型 **全部**）；**`setResults([])`**、清空结果时间戳；**`onSearchMapOverlayChange(null)`**、**`onSpatialQueryPreviewChange(null)`**；手动 **重置** 后空间原点模式固定回 **数据点位**，**`onSpatialOriginFromMapChange(null)`**、**`onCancelSpatialMapPick()`**；**`setLoading(false)`**；查询请求进行中时重置按钮 **禁用**。**切换**「条件查询」「空间要素查询」**Tab** 时 **`resetQueryState({ silent: true })`**（不弹成功提示）。**空间要素**内切换 **数据点位 / 地图标记** 时 **`resetQueryState({ silent: true, spatialOriginKind })`**，清空后停留在所选原点模式。
- **空间要素查询（未点「查询」）**：在 **「空间要素查询」** Tab 内选定 **数据原点** 或 **地图原点** 并填写 **半径（米）** 后，**`index.tsx`** 经 **`spatialQueryPreview`**（**`ZhtSpatialQueryPreview`**）驱动 **`zhtMaplibreBoard`** 在地图上绘制 **绿虚线测地圆 + 蓝点查询原点**（独立图层 id，与查询结果覆盖层分离）；半径未填或非正时 **仅绘原点**。**`ZhtMapSearchPanel`** 用 **`Form.onValuesChange` + 计数刷新** 与 **`getFieldValue`** 同步预览（避免仅依赖 **`Form.useWatch`** 时 **InputNumber** 输入过程中不刷新）；**`parseRadiusMeters`** 统一解析半径（含字符串、千分位逗号；**`2600-2800` / `2600～2800`** 等取 **左侧** 米数作半径演示）；半径表单项使用 **`InputNumber` `stringMode`**，**`step={100}`**（上下箭头每次 ±100 米；手输仍支持任意正整数米），避免中间态被清空后预览不刷新；**`onValuesChange`** 内 **`flushSpatialPreview(allValues)`** 与 **`getFieldsValue` 合并** 时，若补丁显式含 **`radiusM: undefined`**（Form/InputNumber 同步中间帧）则 **保留** 已有半径，避免预览圆间歇消失；半径 **`InputNumber`** 另设 **`onChange` / `onBlur`** 调用 **`flushSpatialPreview`**（`onChange` 带当前 **`radiusM`**），保证 **每次键入与失焦** 预览圆都跟得上。地图预览 **`hasCircle`** 用 **`Number(radiusM)`** 判断，避免字符串半径误判为非有限数。地图预览构环对半径做 **上限夹紧**（防极大值数值异常）及 **try/catch**，失败时仍显示原点。提交空间查询成功、切换右栏、切回 **条件查询** Tab、或面板挂载重置时清除预览；已有 **`searchMapOverlay.spatialRange`**（查询结果同源圆）时 **不叠** 预览以免双线。
- **条件查询**与 **空间要素查询** 成功后：经 **`searchMapOverlay`**（**`ZhtSearchMapOverlay`**）。**右栏为分析看板（未打开地图搜索）时**：沿用原 **设施 / 监测 DOM 命中橙圈 + 角标/提示序号**、**非台账点 GeoJSON 橙点** 的叠绘逻辑（与 **图层控制 / POI 提示** 联动）。**右栏为地图搜索且面板打开**、且 **未** 处于 **`mapSearchShowDefaultPoiMarkers`**（数据选点对照）时：**不**再叠 WebGL 结果点图层（避免点不穿、与 DOM 双轨）；结果以 **DOM Marker** 表达：**设施 / 监测** 为 **提示板 + 台账圆点命中态**（与 **`zhtMaplibreBoard`** 全量模式同源 **`appendFacilityPoiHint` / `appendMonitorPoiHint`**）；其它点可用 **设施样式简要提示** 或 **`.zht-map-search-result-hit*`** 居中序号点。仅 **空间要素查询** 另绘 **测地圆**、**查询原点**（红圈）。右栏 **查询结果列表** 左侧圆形序号与地图一致为 **橙底** `#fa8c16`。右栏切换离开地图搜索、或搜索面板挂载重置时传 **`null`** 清除。**`searchMapSelectedPointId`** 在分析看板模式下仍驱动 GeoJSON 选中样式；在地图搜索模式下驱动 **`.zht-map-search-result-hit--selected`**。
- 右侧看板整体可纵向滚动；**断面水质达标评价** 的 **`Segmented` 年/月/日**：**年** 为环形图+中心达标率；**月** 为 **最近12个月** 堆叠柱（I-II～劣V 图例，柱顶为当月合计演示值）；**日** 为各 **断面** 全年（演示 **2025 年**）**优III类 / IV / V / 劣V 天数** 与 **达标率** 表（`zht-compliance-day-table`）；ECharts 随栏宽 `ResizeObserver` 触发 `resize`。汛期污染表、报警日历为固定演示数据，不接后端。
---

## 内容规划

### 2.1 信息架构

```
综合态势（单页大屏）
├── 左侧栏
│   ├── 管网概况（绿调卡片：雨水/污水管网 km、检查井）
│   ├── 动态感知（蓝调卡片 + 部分黄标）
│   ├── 水利设施（绿调卡片）
│   └── 应急协同（蓝调卡片 + 部分黄标）
├── 地图主区（flex 中间列）
│   ├── 地图栈（`zht-maplibre-stack`）：**左上角**纵向工具条 + MapLibre 画布
│   ├── MapLibre 底图（OpenFreeMap Liberty，与工业园区同源）+ 设施 / 监测 **DOM 圆点 Marker** + 可选 HTML 提示板；监测演示 **`zhtPoiMonitoringDemo.ts`**（坐标、**`pointState`**、提示板指标）
│   └── 底图注记（矢量样式）
└── 右侧栏（`zht-right-rail`：分析看板 **或** 地图搜索面板二选一）
    ├── 默认：`ZhtRightDashboard`（断面达标 / 汛期污染 / 报警日历）
    └── 搜索：`ZhtMapSearchPanel`（条件与空间要素查询 + 卡片结果）
```

### 2.2 数据来源

- **数据类型**：指标卡片、地图设施台账坐标（DOM 点位渲染）、右侧看板示例（断面类别占比、汛期污染行、日历格状态）。
- **数据源**：指标卡片根据 Axure 导出整理；**地图三类设施点**与 **`韶山水环境设施管理系统`** 的 **`facility-points-data.ts`** 完全一致（坐标 `x/y` 与台账 `id` 对齐），不接后端。**监测类 POI** 当前使用 **`zhtPoiMonitoringDemo.ts`** 内固定演示点（坐标、**`pointState`** 驱动地图圆 **绿/红/蓝/灰** 四态，指标名/值/单位及 **`tone`** 驱动提示板数值色），后续可换为真实台账/接口。**地图搜索统一点位**见 **`zhtSearchUnifiedData.ts`**：设施三类同 `facility-points-data`；生态整治为 **`生态整治/riverChiefDb4401.ts`** 中 `initialRiverSectionData` 责任段中点；应急协同为与 **`应急协同/index.tsx`** 中 `initialEmergencyEvents` 前两条一致的内联演示；系统管理为 **`park-boundary-maplibre.tsx`** 导出默认视野锚点及邻近示意点。
- **构建说明**：MapLibre GL JS v5 产物含 `BigInt` 字面量，单入口 IIFE 构建需 `esbuild`/`build.target` 至少 **es2020**。仓库根目录 `vite.config.ts` 已将单入口构建目标从 `es2015` 调整为 `es2020`，避免含 MapLibre 的原型构建失败（影响所有单入口打包，与浏览器兼容性策略一致）。
- **关键字段（地图业务点位）**：
  - **设施**：台账 **`facility-points-data.ts`** 中 `kind`（`pump` | `outlet` | `plant`）决定 DOM 圆点颜色；`id` 用于打开详情 Modal。
  - **监测**：**`zhtPoiMonitoringDemo.ts`** 中 **`pointState`**：`normal` | `alarm` | `general` | `offline`（DOM 圆点绿/红/蓝/灰，地图点位无橙）；`buildMonitoringPointsFeatureCollection` 仍可供后续若改回 GeoJSON 图层时复用。
- **详情样式**：`facility-detail-panel.css` 由设施管理 `style.css` 抽取（详情分组、Descriptions、实时监测/视频 Tab 间距），保证综合态势弹窗内视觉与设施管理一致；`:root` 补充 `--border-color` / `--text-primary` / `--text-secondary`。

### 2.3 内容示例

- 弹窗示例：与设施管理一致，如「泵站详情 - 高新区雨水泵站」多 Tab 内容。
- 右栏示例：断面达标环形图、汛期污染强度三行、报警日历 2026 年 3 月。

---

## 布局与结构

### 3.1 整体布局

- **布局模式**：整页大屏无顶栏；`zht-root` 占满视口高度，主体为 **左侧指标栏 + 中间地图列 + 右侧分析看板** 三列 flex（`zht-body`）。
- **高度链（地图可见性）**：`index.html` 内为 `html, body, #root` 设置 `height: 100%`，与 `.zht-root { height: 100%; min-height: 100dvh; }` 衔接，避免去掉顶栏后 `#root` 仅 `min-height` 导致子级 `flex:1` 地图区高度为 0、画布空白；`.zht-map-shell` 另设 `min-height: min(480px, 50dvh)` 作为兜底。
- **容器宽度**：左侧栏约 **392px**（原型量级），中间地图列 `flex:1` `min-width:0`，右侧栏约 **400px**（`min(400px,100vw)`，≤1100px 时约 **320px**），右侧栏整体纵向滚动。
- **关键尺寸**：
  - 指标卡片：三列网格（窄屏降为两列），卡片最小高度约 **71px**（对齐稿中卡片比例）。
  - 右侧环形图容器高度约 **200px**（ECharts `resize` 随栏宽变化）；看板整体纵向滚动。

### 3.2 响应式适配

- **宽屏**：完整三列指标与右侧看板同原型量级。
- **中窄屏（≤1100px）**：左侧栏缩至 **280px**，指标两列；右侧看板宽度收窄为 `min(320px,100vw)` 避免溢出。

---

## 视觉规范

### 4.1 设计规范来源

**设计规范来源**：与 `src/prototypes/生态整治/style.css` **同源 CSS 变量**（湘潭蓝主色 `#1e5bb5`、强调青 `#02A7F0`、指标正常绿 `#08CC91` 等）+ Axure 导出页 `files/综合态势/styles.css` 中的模块标题样式（`|` 号 + 主标题色）。

**地图实现规范来源**（与代码 `zhtMaplibreBoard.tsx` 一致）：

- **上游仓库**：[maplibre/maplibre-agent-skills](https://github.com/maplibre/maplibre-agent-skills)（官方整理的 Agent Skills；本仓库通过 `skills-lock.json` 同步到 `.agents/skills/maplibre-*`）。
- **与韶山水环境系统管理 · 工业园区**：`zhtMaplibreBoard` 使用与 `park-boundary-maplibre.tsx` 相同的 **`PARK_MAPLIBRE_STYLE_URL`**、**`PARK_MAPLIBRE_DEFAULT_CENTER`**、**`PARK_MAPLIBRE_DEFAULT_ZOOM`**，无其它底图来源、无样式降级切换。业务台账点位以 **`maplibregl.Marker` + DOM 圆点**呈现（不依赖 WebGL `circle` 图层），在 **`mapIsReady`**（由 **`map.once('load')`** 置为 true）后由 React effect 挂载。**不挂载** MapLibre **`NavigationControl`**，缩放与指北由左侧 **`ZhtMapVerticalToolbar`** 提供；**左下角**挂载 **`ScaleControl`**（公制比例尺，`maxWidth: 120`）；地图容器 **圆角 8px + 浅灰描边 + 轻阴影**；**紧凑署名**。
- **POI HTML 提示板（Marker）**：与 **DOM 圆点**共用同一 Marker 根节点（纵向叠放：提示在上、圆点在下）；显隐仅由 **`ZhtMapVerticalToolbar`** 的 **POI提示配置** 与 **`zhtMaplibreBoard`** 状态联动（关标题则对应提示板不挂载；**不**隐藏 DOM 圆点）；在 **`mapIsReady`** 之后按配置挂载；**不得**仅以首次 `load` 当帧的 `map.loaded()` 作为唯一前置条件——可与「查询结果」等后续 **`addSource` / `addLayer`** 并存，以 **`mapIsReady`** 作为业务 Marker 的安全挂载信号。提示板显隐会改变 Marker 根节点高度，**`zhtMaplibreBoard`** 对每个业务 Marker 使用 **`ResizeObserver`**，在尺寸变化时 **`setLngLat` 同坐标重设** 以触发 MapLibre 重算 **`anchor: bottom`**，避免「空间/条件查询完成后改 POI 配置」出现圆点与地图错位、点击偏移；首帧另 **`requestAnimationFrame` + `triggerRepaint`** 再踢一脚。`.zht-map-poi-hint` 设 **`pointer-events: none`**，避免提示板挡住下方查询命中圆点的点击。同屏多个 Marker 重叠时，**`maplibregl.Marker` 外层 `z-index`** 由 **`zhtPoiMarkerZIndexFromPosition`** 按经纬度计算：**纬度越低（正北朝上时偏南）越靠前**，经度作细粒度区分；数值在本帧全部 POI 的经纬度 min/max 内归一化，**保持为正**，避免偏北点因负 `z-index` 被压在地图画布下而不可见。
- `.agents/skills/maplibre-tile-sources/SKILL.md`：在矢量底图上叠加 **GeoJSON** 业务点位可参考「首个 `symbol` 图层 id」作 `beforeId`。**综合态势**台账点位采用 **DOM 圆点 Marker**，叠在矢量底图之上、不依赖样式 `circle` 图层；**条件 / 空间查询**覆盖层仍在后续 effect 中 **`addSource` / `addLayer`**（含 `circle` / `symbol`），叠在业务点位之上。容器使用 **flex 占满** + **`ResizeObserver` + 延时 `resize()`**，与工业园区地图一致，避免 flex 首帧画布高度异常。
- `.agents/skills/maplibre-mapbox-migration/SKILL.md`：使用 `maplibre-gl` 与 `maplibre-gl.css`，**不使用** `mapbox://` 样式与 Mapbox access token。
- **PMTiles**：本原型未使用离线 `.pmtiles`；若后续改为静态托管切片，再按 `.agents/skills/maplibre-pmtiles-patterns/SKILL.md` 注册 `pmtiles` 协议即可。
- **布局**：`zht-map-shell` 浅色占位底、纵向 flex；内层 **`zht-maplibre-stack`** `flex:1` 承载 **`ZhtMapVerticalToolbar`**（绝对定位）与 **`zht-maplibre-host`**（地图 `flex:1`）全高撑满。分析看板已移出地图列，地图署名区仅需常规边距（`style.css` 中 `margin-right` 已收紧）。

### 4.2 自定义设计要点

- **左侧指标卡片**：绿段 `#e8f5e9` 底 / `#1b5e20` 主数值；蓝段 `#e3f2fd` 底 / `#0d47a1` 主数值；黄标 `#ffeb3b` 底、`#5c4a00` 字，绝对定位于卡片右上。
- **地图点位**：水环境 POI 统一为 **`.zht-map-point-dot--water-env`**：**中心分类图标** + **四态底色**（报警红 / 离线灰 / 在线绿 / 信息点蓝；**搜索命中**整圆改 **橙** `#fa8c16`）；**图层控制** 与 **`waterEnvPoiLayers`** 同步驱动 **`zhtMaplibreBoard`** 重挂载 Marker。**地图搜索**：命中项在原 DOM 上 **橙色**；序号在 **提示标题前**（有标题时）或 **角标**（无标题时）；未以 DOM 承载且仍参与结果集的点位为 GeoJSON **橙点 + 白字序号**（与 **`unifiedPointPassesWaterEnvLayer`** 一致：已绘 DOM 的不叠 WebGL）。
### 4.3 组件状态

- **地图工具条按钮**：悬停浅蓝底 + 主色字；**「POI提示配置」「图层控制」** 的 Popover 打开时对应按钮保持选中态（`zht-map-tool-btn--on`）。
- **图层 Popover 内复选框**：Ant Design 默认态；水环境 POI 取消某类或某态即隐藏对应 **DOM 圆点**（及该类提示板）；占位项（排水户等）带 **图例 icon**；**自定义标注** 仅占位状态。
- **POI提示配置 Popover 内复选框**：只控制 HTML 提示板显隐，**不**隐藏 **DOM 圆点**；每项后 **`Select`** 调节字号档位：**超大 / 大 / 标准 / 小 / 超小**（下拉文案不含像素；实际像素见 **`ZHT_POI_HINT_FONT_PX`**）；标题栏右侧 **「恢复默认」** 将三项勾选与三档字号恢复为 **`ZHT_POI_HINT_UI_DEFAULTS`**（与初次进入页面一致：设施/监测标题勾选开、监测数值勾选开；设施标题与监测标题 **标准**、监测数值 **小**）。
- **POI 提示板样式**：`style.css` 中 `.zht-map-poi-hint--facility`（设施仅标题）、`.zht-map-poi-hint--monitor`（监测五色数字 + 灰色单位）；**`.zht-map-poi-hint`** 显式 **`pointer-events: none`**；**`.zht-map-point-dot*`** 为地图圆点；**`.zht-map-poi-popover*`** 为 POI提示配置 浮层布局。

---
