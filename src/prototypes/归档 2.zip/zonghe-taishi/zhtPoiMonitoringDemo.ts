/**
 * 综合态势 · 监测类 POI 演示数据（与设施台账无关，仅用于地图提示板样式演示）
 */

/** 监测数值语义色：绿=正常、红=超标、蓝=预警/信息（地图链路不使用橙色）、灰=无数据 */
export type ZhtMonitorMetricTone = 'normal' | 'danger' | 'warn' | 'info' | 'nodata';

export type ZhtMonitorMetricRow = {
  name: string;
  value: string;
  unit: string;
  tone: ZhtMonitorMetricTone;
};

/** 监测站在地图上的圆点状态：绿=正常、红=报警、蓝=普通、灰=离线（地图点位无橙色） */
export type ZhtMonitorPointState = 'normal' | 'alarm' | 'general' | 'offline';

export type ZhtMonitoringPoiDemo = {
  id: string;
  lng: number;
  lat: number;
  title: string;
  /** 地图圆点颜色：与提示板内指标报警可分别配置（演示数据手工指定） */
  pointState: ZhtMonitorPointState;
  metrics: ZhtMonitorMetricRow[];
};

/** 与 DOM class `zht-map-poi-hint__metric-num--*` 对应 */
export function zhtMonitorMetricNumClass(tone: ZhtMonitorMetricTone): string {
  switch (tone) {
    case 'normal':
      return 'zht-map-poi-hint__metric-num--green';
    case 'danger':
      return 'zht-map-poi-hint__metric-num--red';
    case 'warn':
      return 'zht-map-poi-hint__metric-num--warn';
    case 'info':
      return 'zht-map-poi-hint__metric-num--blue';
    case 'nodata':
      return 'zht-map-poi-hint__metric-num--gray';
  }
}

export const ZHT_MONITORING_POI_DEMO: ZhtMonitoringPoiDemo[] = [
  {
    id: 'mon-1',
    lng: 112.534,
    lat: 27.919,
    title: '高新园区水质自动站',
    pointState: 'normal',
    metrics: [
      { name: 'COD', value: '18.2', unit: 'mg/L', tone: 'normal' },
      { name: '氨氮', value: '0.42', unit: 'mg/L', tone: 'warn' },
      { name: 'pH', value: '7.6', unit: '', tone: 'info' },
      { name: '总磷', value: '0.08', unit: 'mg/L', tone: 'danger' },
      { name: '总氮', value: '1.05', unit: 'mg/L', tone: 'normal' },
    ],
  },
  {
    id: 'mon-2',
    lng: 112.518,
    lat: 27.912,
    title: '韶河入库断面监测点',
    pointState: 'alarm',
    metrics: [
      { name: 'COD', value: '21.0', unit: 'mg/L', tone: 'danger' },
      { name: '氨氮', value: '0.55', unit: 'mg/L', tone: 'warn' },
      { name: 'pH', value: '7.4', unit: '', tone: 'info' },
      { name: '总磷', value: '0.11', unit: 'mg/L', tone: 'warn' },
      { name: '总氮', value: '--', unit: 'mg/L', tone: 'nodata' },
    ],
  },
  {
    id: 'mon-4',
    lng: 112.529,
    lat: 27.913,
    title: '河道巡测参考点',
    pointState: 'general',
    metrics: [
      { name: '水温', value: '18.1', unit: '℃', tone: 'info' },
      { name: '浊度', value: '2.1', unit: 'NTU', tone: 'normal' },
    ],
  },
  {
    id: 'mon-3',
    lng: 112.542,
    lat: 27.908,
    title: '饮用水源取水口监测点',
    pointState: 'offline',
    metrics: [
      { name: 'COD', value: '12.6', unit: 'mg/L', tone: 'normal' },
      { name: '氨氮', value: '0.18', unit: 'mg/L', tone: 'normal' },
      { name: 'pH', value: '7.8', unit: '', tone: 'info' },
      { name: '总磷', value: '0.05', unit: 'mg/L', tone: 'normal' },
      { name: '总氮', value: '0.72', unit: 'mg/L', tone: 'normal' },
    ],
  },
];

/** 监测站 GeoJSON（地图圆点图层用） */
export function buildMonitoringPointsFeatureCollection(): GeoJSON.FeatureCollection<
  GeoJSON.Point,
  { id: string; state: ZhtMonitorPointState }
> {
  return {
    type: 'FeatureCollection',
    features: ZHT_MONITORING_POI_DEMO.map(m => ({
      type: 'Feature' as const,
      properties: { id: m.id, state: m.pointState },
      geometry: { type: 'Point' as const, coordinates: [m.lng, m.lat] },
    })),
  };
}
