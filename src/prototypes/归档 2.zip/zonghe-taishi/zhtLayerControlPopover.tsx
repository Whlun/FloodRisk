/**
 * 综合态势 · 图层控制 Popover 内容（树形折叠；说明文案在标题后问号 Tooltip 内）
 */
import React, { useMemo, useState } from 'react';
import { QuestionCircleOutlined } from '@ant-design/icons';
import { Button, Checkbox, Collapse, Radio, Space, Tooltip, message } from 'antd';
import {
  Activity,
  Building2,
  ChevronRight,
  CircleDot,
  ClipboardList,
  Dam,
  Droplets,
  Factory,
  Fence,
  FlaskConical,
  LayoutGrid,
  Leaf,
  MapPinned,
  Mountain,
  Package,
  PanelTop,
  SeparatorHorizontal,
  Settings,
  TriangleAlert,
  Users,
  Waves,
} from 'lucide-react';
import type { ZhtLayerControlState } from './zhtLayerControlState';
import {
  ZHT_POI_STATE_HELP,
  ZHT_SYS_HYDRO_CATEGORY_ORDER,
  ZHT_WATER_ENV_CATEGORY_META,
  ZHT_WATER_ENV_MAIN_CATEGORY_ORDER,
  countUnifiedPointsByCategory,
  type ZhtPoiDisplayState,
  type ZhtWaterEnvCategoryId,
  type ZhtWaterEnvCategoryMeta,
} from './zhtWaterEnvPoiMeta';

const PLACEHOLDER_TIP = '演示占位：未接入地图服务，仅保留勾选状态';

/** 各分组说明（展示在标题后「?」的 Tooltip 中） */
const HELP = {
  admin: '勾选后地图展示行政名称提示面板；与「零直排区域标注」联动行政区划提示板内的指标行。',
  drainNet:
    '接入管网地图服务后，可在此分组控制雨水管网、污水管网、检查井等子图层显隐。（当前为演示占位）',
  waterPoi:
    '图层控制优先于「POI提示配置」。水环境 POI：紧凑树形——行首小箭头在复选框左侧，展开后为四态子勾选（信息点 / 在线 / 离线 / 超限报警）；数据来源见主类旁「?」。系统管理水利七类（闸坝、堤坝、水库、水闸、圩区、堰堤、山塘）与主类同列平铺，无再下钻分组。关闭某类或某态后，地图圆点与对应提示均不展示。',
  remote: '接入遥感服务后可叠加遥感栅格图层；当前为演示占位，仅保留指标单选（不接瓦片）。',
  pipeFlow: '基于排水管线流向数据控制管线流向符号显隐。（当前为演示占位）',
  zero: '控制行政区划提示板内「雨污分流」「污水零直排」两行是否展示；达标为绿色，不达标为红色。',
} as const;

/** 标题后问号：悬停查看说明 */
function HelpTip({ text }: { text: string }) {
  return (
    <Tooltip title={text} placement="topLeft" overlayStyle={{ maxWidth: 320 }}>
      <span
        className="zht-layer-control__help-icon"
        role="button"
        tabIndex={0}
        aria-label={`说明：${text}`}
        onClick={e => e.stopPropagation()}
        onKeyDown={e => {
          if (e.key === 'Enter' || e.key === ' ') e.stopPropagation();
        }}
      >
        <QuestionCircleOutlined />
      </span>
    </Tooltip>
  );
}

/** 占位图层：勾选 + 问号（说明为未接服务占位）；可选 `legend` 为标签前小图标，与水环境主类图例一致 */
function PhCheckbox({
  checked,
  onChange,
  helpText = PLACEHOLDER_TIP,
  legend,
  children,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  helpText?: string;
  /** 图例 icon（建议 12px Lucide） */
  legend?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <span className="zht-layer-control__label-row" onClick={e => e.stopPropagation()}>
      <Checkbox checked={checked} onChange={e => onChange(e.target.checked)} onClick={e => e.stopPropagation()}>
        {legend ? (
          <span className="zht-layer-control__checkbox-legend">
            <span className="zht-layer-water-poi-cat__icon" aria-hidden>
              {legend}
            </span>
            {children}
          </span>
        ) : (
          children
        )}
      </Checkbox>
      <HelpTip text={helpText} />
    </span>
  );
}

/** 四态在面板中的展示顺序（与设计稿一致：信息点 → 在线 → 离线 → 超限报警） */
const POI_STATE_DISPLAY_ORDER: ZhtPoiDisplayState[] = ['info', 'online', 'offline', 'alarm'];

const POI_STATE_LABEL: Record<ZhtPoiDisplayState, string> = {
  alarm: '超限报警',
  offline: '离线',
  online: '在线',
  info: '信息点',
};

const POI_STATE_SWATCH: Record<ZhtPoiDisplayState, string> = {
  alarm: '#ff4d4f',
  offline: '#8c8c8c',
  online: '#52c41a',
  info: '#1677ff',
};

const ZHT_WATER_ENV_META_BY_ID = Object.fromEntries(
  ZHT_WATER_ENV_CATEGORY_META.map(m => [m.id, m]),
) as Record<ZhtWaterEnvCategoryId, ZhtWaterEnvCategoryMeta>;

const CAT_LUCIDE: Record<ZhtWaterEnvCategoryId, React.ReactNode> = {
  pump: <Droplets size={12} strokeWidth={2} aria-hidden />,
  outlet: <CircleDot size={12} strokeWidth={2} aria-hidden />,
  plant: <Factory size={12} strokeWidth={2} aria-hidden />,
  monitor: <Activity size={12} strokeWidth={2} aria-hidden />,
  eco_project: <Leaf size={12} strokeWidth={2} aria-hidden />,
  eco_affair: <ClipboardList size={12} strokeWidth={2} aria-hidden />,
  emg_supply: <Package size={12} strokeWidth={2} aria-hidden />,
  emg_event: <TriangleAlert size={12} strokeWidth={2} aria-hidden />,
  sys_zhaba: <Dam size={12} strokeWidth={2} aria-hidden />,
  sys_diba: <Fence size={12} strokeWidth={2} aria-hidden />,
  sys_shuiku: <Waves size={12} strokeWidth={2} aria-hidden />,
  sys_shuizha: <PanelTop size={12} strokeWidth={2} aria-hidden />,
  sys_weiqu: <LayoutGrid size={12} strokeWidth={2} aria-hidden />,
  sys_yandi: <SeparatorHorizontal size={12} strokeWidth={2} aria-hidden />,
  sys_shantang: <Mountain size={12} strokeWidth={2} aria-hidden />,
};

/** 单类水环境 POI：行首箭头 + 复选框 + 名称（数量）同一行；展开后仅四态子项（无额外标题行） */
function WaterEnvCategoryControls({
  catId,
  v,
  onChange,
  count,
  poiChildDisabled,
}: {
  catId: ZhtWaterEnvCategoryId;
  v: ZhtLayerControlState;
  onChange: (patch: Partial<ZhtLayerControlState>) => void;
  count: number;
  poiChildDisabled: boolean;
}) {
  const [statesOpen, setStatesOpen] = useState(false);
  const meta = ZHT_WATER_ENV_META_BY_ID[catId];
  const layer = v.waterEnvPoiLayers[catId];
  return (
    <div className="zht-layer-water-poi-cat">
      <div className="zht-layer-water-poi-cat__row" onClick={e => e.stopPropagation()}>
        <button
          type="button"
          className="zht-layer-water-poi-chevron"
          aria-expanded={statesOpen}
          aria-controls={`zht-poi-states-${catId}`}
          aria-label={statesOpen ? '收起四态' : '展开四态'}
          onClick={e => {
            e.stopPropagation();
            setStatesOpen(o => !o);
          }}
        >
          <ChevronRight
            size={12}
            strokeWidth={2}
            className={statesOpen ? 'zht-layer-water-poi-chevron__svg zht-layer-water-poi-chevron__svg--open' : 'zht-layer-water-poi-chevron__svg'}
            aria-hidden
          />
        </button>
        <Checkbox
          disabled={poiChildDisabled}
          checked={layer.enabled}
          onChange={e =>
            onChange({
              waterEnvPoiLayers: {
                ...v.waterEnvPoiLayers,
                [catId]: { ...layer, enabled: e.target.checked },
              },
            })
          }
          onClick={e => e.stopPropagation()}
        >
          <span className="zht-layer-water-poi-cat__title">
            <span className="zht-layer-water-poi-cat__icon" aria-hidden>
              {CAT_LUCIDE[catId]}
            </span>
            {meta.label}（{count}）
          </span>
        </Checkbox>
        <HelpTip text={meta.help} />
      </div>
      {statesOpen ? (
        <div className="zht-layer-water-poi-cat__states" id={`zht-poi-states-${catId}`} role="group">
          {POI_STATE_DISPLAY_ORDER.map(st => (
            <div key={st} className="zht-layer-water-poi-state-row">
              <Checkbox
                disabled={poiChildDisabled || !layer.enabled}
                checked={layer.states[st]}
                onChange={e =>
                  onChange({
                    waterEnvPoiLayers: {
                      ...v.waterEnvPoiLayers,
                      [catId]: {
                        ...layer,
                        states: { ...layer.states, [st]: e.target.checked },
                      },
                    },
                  })
                }
                onClick={e => e.stopPropagation()}
              >
                <span className="zht-layer-water-poi-state-row__label">
                  <span
                    className="zht-layer-water-poi-swatch"
                    style={{ backgroundColor: POI_STATE_SWATCH[st] }}
                    aria-hidden
                  />
                  {POI_STATE_LABEL[st]}
                </span>
              </Checkbox>
              <HelpTip text={ZHT_POI_STATE_HELP[st]} />
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
}

export interface ZhtLayerControlPopoverProps {
  value: ZhtLayerControlState;
  onChange: (patch: Partial<ZhtLayerControlState>) => void;
}

export const ZhtLayerControlPopover: React.FC<ZhtLayerControlPopoverProps> = ({ value: v, onChange }) => {
  const poiChildDisabled = !v.waterEnvPoiEnabled;

  const poiCounts = useMemo(() => countUnifiedPointsByCategory(), []);

  return (
    <div className="zht-layer-control-popover" onClick={e => e.stopPropagation()}>
      <div className="zht-layer-control-popover__head">
        <span className="zht-layer-control-popover__title">图层控制</span>
        <Button
          type="text"
          size="small"
          className="zht-layer-control-popover__gear"
          aria-label="图层设置"
          icon={<Settings size={16} strokeWidth={1.75} />}
          onClick={() => message.info('图层设置：演示占位')}
        />
      </div>

      <Collapse
        bordered={false}
        size="small"
        className="zht-layer-control-collapse"
        defaultActiveKey={['admin', 'poi']}
        items={[
          {
            key: 'admin',
            showArrow: false,
            label: (
              <span className="zht-layer-control__label-row" onClick={e => e.stopPropagation()}>
                <Checkbox
                  checked={v.showAdminDivisionHints}
                  onChange={e => onChange({ showAdminDivisionHints: e.target.checked })}
                  onClick={e => e.stopPropagation()}
                >
                  行政区划
                </Checkbox>
                <HelpTip text={HELP.admin} />
              </span>
            ),
          },
          {
            key: 'drain1',
            showArrow: false,
            label: (
              <PhCheckbox
                checked={v.drainagePipeNetwork}
                onChange={x => onChange({ drainagePipeNetwork: x })}
                helpText={HELP.drainNet}
              >
                排水管网
              </PhCheckbox>
            ),
          },
          {
            key: 'grid',
            showArrow: false,
            label: (
              <PhCheckbox checked={v.drainageGrid} onChange={x => onChange({ drainageGrid: x })}>
                排水网格
              </PhCheckbox>
            ),
          },
          {
            key: 'unit',
            showArrow: false,
            label: (
              <PhCheckbox checked={v.drainageUnit} onChange={x => onChange({ drainageUnit: x })}>
                排水单元
              </PhCheckbox>
            ),
          },
          {
            key: 'flow',
            showArrow: false,
            label: (
              <PhCheckbox
                checked={v.pipelineFlowMarks}
                onChange={x => onChange({ pipelineFlowMarks: x })}
                helpText={HELP.pipeFlow}
              >
                管线流向标识
              </PhCheckbox>
            ),
          },
          {
            key: 'poi',
            label: (
              <span className="zht-layer-control__label-row" onClick={e => e.stopPropagation()}>
                <Checkbox
                  checked={v.waterEnvPoiEnabled}
                  onChange={e => onChange({ waterEnvPoiEnabled: e.target.checked })}
                  onClick={e => e.stopPropagation()}
                >
                  水环境POI点位
                </Checkbox>
                <HelpTip text={HELP.waterPoi} />
              </span>
            ),
            children: (
              <Space direction="vertical" size={4} style={{ width: '100%' }}>
                {ZHT_WATER_ENV_MAIN_CATEGORY_ORDER.map(catId => (
                  <WaterEnvCategoryControls
                    key={catId}
                    catId={catId}
                    v={v}
                    onChange={onChange}
                    count={poiCounts[catId]}
                    poiChildDisabled={poiChildDisabled}
                  />
                ))}
                {ZHT_SYS_HYDRO_CATEGORY_ORDER.map(catId => (
                  <WaterEnvCategoryControls
                    key={catId}
                    catId={catId}
                    v={v}
                    onChange={onChange}
                    count={poiCounts[catId]}
                    poiChildDisabled={poiChildDisabled}
                  />
                ))}
                <PhCheckbox
                  checked={v.poiPlaceholderDrainageUser}
                  onChange={x => onChange({ poiPlaceholderDrainageUser: x })}
                  legend={<Users size={12} strokeWidth={2} />}
                >
                  排水户
                </PhCheckbox>
                <PhCheckbox
                  checked={v.poiPlaceholderDrainageEnterprise}
                  onChange={x => onChange({ poiPlaceholderDrainageEnterprise: x })}
                  legend={<Building2 size={12} strokeWidth={2} />}
                >
                  排水企业
                </PhCheckbox>
                <PhCheckbox
                  checked={v.poiPlaceholderPollutionSource}
                  onChange={x => onChange({ poiPlaceholderPollutionSource: x })}
                  legend={<FlaskConical size={12} strokeWidth={2} />}
                >
                  污染源
                </PhCheckbox>
                <PhCheckbox
                  checked={v.poiPlaceholderCustomAnnotation}
                  onChange={x => onChange({ poiPlaceholderCustomAnnotation: x })}
                  legend={<MapPinned size={12} strokeWidth={2} />}
                >
                  自定义标注
                </PhCheckbox>
              </Space>
            ),
          },
          {
            key: 'rs',
            label: (
              <PhCheckbox checked={v.remoteSensing} onChange={x => onChange({ remoteSensing: x })} helpText={HELP.remote}>
                遥感监测
              </PhCheckbox>
            ),
            children: (
              <Radio.Group
                value={v.remoteSensingMetric}
                onChange={e => onChange({ remoteSensingMetric: e.target.value })}
                disabled={!v.remoteSensing}
              >
                <Space direction="vertical" size={4}>
                  <Radio value="chlorophyll">叶绿素（µg/L）</Radio>
                  <Radio value="suspended">悬浮物（µg/L）</Radio>
                </Space>
              </Radio.Group>
            ),
          },
          {
            key: 'sus',
            showArrow: false,
            label: (
              <PhCheckbox checked={v.suspectProblemPatches} onChange={x => onChange({ suspectProblemPatches: x })}>
                疑似问题图斑
              </PhCheckbox>
            ),
          },
          {
            key: 'rv',
            showArrow: false,
            label: (
              <PhCheckbox checked={v.riverFlowVisualization} onChange={x => onChange({ riverFlowVisualization: x })}>
                河流流向可视化
              </PhCheckbox>
            ),
          },
          {
            key: 'eco',
            showArrow: false,
            label: (
              <PhCheckbox checked={v.ecoRedline} onChange={x => onChange({ ecoRedline: x })}>
                生态红线标识
              </PhCheckbox>
            ),
          },
          {
            key: 'zero',
            showArrow: false,
            label: (
              <span className="zht-layer-control__label-row" onClick={e => e.stopPropagation()}>
                <Checkbox
                  checked={v.zeroDirectDischargeLabels}
                  onChange={e => onChange({ zeroDirectDischargeLabels: e.target.checked })}
                  onClick={e => e.stopPropagation()}
                >
                  零直排区域标注
                </Checkbox>
                <HelpTip text={HELP.zero} />
              </span>
            ),
          },
          {
            key: 'sim',
            showArrow: false,
            label: (
              <PhCheckbox checked={v.riverDynamicSimulation} onChange={x => onChange({ riverDynamicSimulation: x })}>
                河流动态模拟
              </PhCheckbox>
            ),
          },
          {
            key: 'flood',
            showArrow: false,
            label: (
              <PhCheckbox checked={v.waterLevelInundation} onChange={x => onChange({ waterLevelInundation: x })}>
                水位与淹没分析
              </PhCheckbox>
            ),
          },
        ]}
      />
    </div>
  );
};
