/**
 * @name 综合态势
 *
 * 根据 Axure HTML 导出「综合态势」页还原的大屏一张图：左侧四区指标、MapLibre 底图与点位、**地图左上角纵向工具条**、**右侧栏**（默认 **分析看板**：断面达标、汛期污染强度、排口报警日历；工具条「搜索」时切换为 **地图搜索面板** `ZhtMapSearchPanel`）（无顶栏）。
 *
 * 参考资料：
 * - Axure：`/Users/whlun/Documents/综合态势原型HTML导出/综合态势.html`
 * - 视觉：`src/prototypes/生态整治/style.css`（同源色板）
 * - 地图实现：`zhtMaplibreBoard.tsx`（底图与工业园区 OpenFreeMap Liberty 一致；点位与 **韶山水环境设施管理系统** 泵站/排口/污水厂台账同源，详情弹窗与列表一致）
 */

import './style.css';
/** 设施详情 Tab + 实时监测/视频样式（从设施管理 style 抽取，与列表详情一致） */
import './facility-detail-panel.css';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { ConfigProvider, message } from 'antd';
import zhCN from 'antd/locale/zh_CN';
import { ZhtMaplibreBoard } from './zhtMaplibreBoard';
import { ZhtMapSearchPanel } from './ZhtMapSearchPanel';
import { ZhtRightDashboard } from './zhtRightDashboard';
import type { ZhtUnifiedSearchPoint } from './zhtSearchUnifiedData';
import type { ZhtSearchMapOverlay, ZhtSpatialQueryPreview } from './zhtSpatialSearchGeo';
import { DEFAULT_ZHT_LAYER_CONTROL, type ZhtLayerControlState } from './zhtLayerControlState';

/** 与设计稿一致：绿段为管网/水利静态设施，蓝段为动态感知与应急 */
type StatTone = 'green' | 'blue';
type StatItem = { label: string; value: string | number; badge?: string | number };
type StatSection = { title: string; tone: StatTone; items: StatItem[] };

const SECTIONS: StatSection[] = [
  {
    title: '管网概况',
    tone: 'green',
    items: [
      { label: '雨水管网(km)', value: 1231 },
      { label: '污水管网(km)', value: 1231 },
      { label: '检查井', value: 1231 },
    ],
  },
  {
    title: '动态感知',
    tone: 'blue',
    items: [
      { label: '管网监测', value: 61 },
      { label: '水源地', value: 61, badge: 36 },
      { label: '排放口', value: 61 },
      { label: '污水处理厂', value: 61 },
      { label: '泵站', value: 61, badge: 37 },
      { label: '水质监测点', value: 61 },
      { label: '河道站', value: 61 },
      { label: '入河排口', value: 61 },
      { label: '闸门', value: 61 },
      { label: '河流断面', value: 61 },
    ],
  },
  {
    title: '水利设施',
    tone: 'green',
    items: [
      { label: '河流', value: 61 },
      { label: '湖泊', value: 61 },
      { label: '山塘', value: 61 },
      { label: '闸站', value: 61 },
      { label: '闸坝', value: 61 },
      { label: '堤防', value: 61 },
    ],
  },
  {
    title: '应急协同',
    tone: 'blue',
    items: [
      { label: '风险源企业', value: 61 },
      { label: '污染源', value: 61 },
      { label: '排水户', value: 61 },
      { label: '应急预案', value: 1, badge: 40 },
      { label: '物资点', value: 61 },
      { label: '应急物资', value: 130, badge: 39 },
      { label: '应急队伍', value: 61 },
      { label: '应急专家', value: 61 },
      { label: '应急事件', value: 61, badge: 38 },
    ],
  },
];

const ZhtDashboard: React.FC = () => {
  const [layerControl, setLayerControl] = useState<ZhtLayerControlState>(DEFAULT_ZHT_LAYER_CONTROL);
  const patchLayerControl = useCallback((patch: Partial<ZhtLayerControlState>) => {
    setLayerControl(prev => ({ ...prev, ...patch }));
  }, []);
  /** 右侧：分析看板 ↔ 地图搜索（非弹窗） */
  const [rightRailView, setRightRailView] = useState<'analysis' | 'map-search'>('analysis');
  const mapSearchFlyToRef = useRef<((point: ZhtUnifiedSearchPoint) => void) | null>(null);
  /** 空间查询：地图点击得到的原点（与「数据选点」二选一） */
  const [spatialOriginFromMap, setSpatialOriginFromMap] = useState<{ lng: number; lat: number } | null>(
    null,
  );
  const [spatialMapPickActive, setSpatialMapPickActive] = useState(false);
  /** 地图搜索查询结果覆盖（条件：序号点；空间：圆+原点+序号点） */
  const [searchMapOverlay, setSearchMapOverlay] = useState<ZhtSearchMapOverlay | null>(null);
  /** 当前选中的查询结果 id：GeoJSON 序号点或设施 DOM 搜索命中态略放大 */
  const [searchMapSelectedPointId, setSearchMapSelectedPointId] = useState<string | null>(null);
  /** 空间要素查询：未点「查询」前在地图上预览原点与范围（与查询结果覆盖层分离） */
  const [spatialQueryPreview, setSpatialQueryPreview] = useState<ZhtSpatialQueryPreview | null>(null);
  /** 地图搜索面板内 Tab / 空间原点模式（用于「数据点位」选点阶段恢复默认地图点） */
  const [mapSearchPanelContext, setMapSearchPanelContext] = useState<{
    activeTab: 'condition' | 'spatial';
    spatialOriginKind: 'data' | 'map';
  }>({ activeTab: 'condition', spatialOriginKind: 'data' });

  const onSpatialQueryPreviewChange = useCallback((v: ZhtSpatialQueryPreview | null) => {
    setSpatialQueryPreview(v);
  }, []);

  /** 覆盖层变化时清空选中（避免指向旧结果集） */
  useEffect(() => {
    setSearchMapSelectedPointId(null);
  }, [searchMapOverlay]);

  /** 切换右栏时结束选点、清空地图覆盖层与空间预览；进入地图搜索时清空地图原点与搜索上下文（与子面板初始 Tab 一致） */
  useEffect(() => {
    setSpatialMapPickActive(false);
    setSearchMapOverlay(null);
    setSearchMapSelectedPointId(null);
    setSpatialQueryPreview(null);
    setMapSearchPanelContext({ activeTab: 'condition', spatialOriginKind: 'data' });
    if (rightRailView === 'map-search') {
      setSpatialOriginFromMap(null);
    }
  }, [rightRailView]);

  const onToggleMapSearch = useCallback(() => {
    setRightRailView(v => (v === 'analysis' ? 'map-search' : 'analysis'));
  }, []);

  const onSearchResultFromPanel = useCallback((p: ZhtUnifiedSearchPoint) => {
    setSearchMapSelectedPointId(p.id);
    mapSearchFlyToRef.current?.(p);
  }, []);

  const onSpatialMapPick = useCallback((lng: number, lat: number) => {
    setSpatialOriginFromMap({ lng, lat });
    setSpatialMapPickActive(false);
    message.success('已设置空间查询原点（地图标记）');
  }, []);

  /** 空间 + 数据原点 + 尚未提交查询覆盖层：地图展示默认台账/监测便于对照选点 */
  const mapSearchShowDefaultPoiMarkers =
    rightRailView === 'map-search' &&
    mapSearchPanelContext.activeTab === 'spatial' &&
    mapSearchPanelContext.spatialOriginKind === 'data' &&
    searchMapOverlay == null;

  return (
    <ConfigProvider locale={zhCN}>
      <div className="zht-root">
        <div className="zht-body">
          <aside className="zht-left">
            {SECTIONS.map(sec => (
              <section key={sec.title} className="zht-left-section">
                <h2 className="zht-section-title">
                  <span className="pipe">|</span>
                  {sec.title}
                </h2>
                <div className="zht-stat-grid">
                  {sec.items.map(it => (
                    <div key={`${sec.title}-${it.label}`} className={`zht-stat-card zht-stat-card--${sec.tone}`}>
                      {it.badge != null && it.badge !== '' && (
                        <span className="zht-stat-badge" aria-label={`附加指标 ${it.badge}`}>
                          {it.badge}
                        </span>
                      )}
                      <div className="zht-stat-value">{it.value}</div>
                      <div className="zht-stat-label">{it.label}</div>
                    </div>
                  ))}
                </div>
              </section>
            ))}
          </aside>

          <div className="zht-map-shell">
            <ZhtMaplibreBoard
              showAdminDivisionHints={layerControl.showAdminDivisionHints}
              showZeroDirectIndicators={layerControl.zeroDirectDischargeLabels}
              layerControl={layerControl}
              onLayerControlChange={patchLayerControl}
              mapSearchFlyToRef={mapSearchFlyToRef}
              onToggleMapSearch={onToggleMapSearch}
              mapSearchPanelOpen={rightRailView === 'map-search'}
              mapSearchShowDefaultPoiMarkers={mapSearchShowDefaultPoiMarkers}
              spatialMapPickActive={spatialMapPickActive}
              onSpatialMapPick={onSpatialMapPick}
              searchMapOverlay={searchMapOverlay}
              searchMapSelectedPointId={searchMapSelectedPointId}
              onSearchMapResultClick={onSearchResultFromPanel}
              spatialQueryPreview={spatialQueryPreview}
            />
          </div>

          {rightRailView === 'analysis' ? (
            <ZhtRightDashboard />
          ) : (
            <ZhtMapSearchPanel
              onClose={() => setRightRailView('analysis')}
              onResultActivate={onSearchResultFromPanel}
              spatialOriginFromMap={spatialOriginFromMap}
              onSpatialOriginFromMapChange={setSpatialOriginFromMap}
              spatialMapPickActive={spatialMapPickActive}
              onRequestSpatialMapPick={() => setSpatialMapPickActive(true)}
              onCancelSpatialMapPick={() => setSpatialMapPickActive(false)}
              onSearchMapOverlayChange={setSearchMapOverlay}
              onSpatialQueryPreviewChange={onSpatialQueryPreviewChange}
              onMapSearchContextChange={setMapSearchPanelContext}
            />
          )}
        </div>
      </div>
    </ConfigProvider>
  );
};

export default ZhtDashboard;

const container = document.getElementById('root');
if (container) {
  const root = createRoot(container);
  root.render(<ZhtDashboard />);
}
