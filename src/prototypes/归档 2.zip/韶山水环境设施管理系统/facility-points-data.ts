/**
 * 设施管理 · 地图点位台账（泵站 / 排口 / 污水厂）
 * 与 `index.tsx` 列表同源，供地图与列表共用，避免坐标漂移。
 */

export type PumpStationRecord = {
  id: string;
  name: string;
  category: string;
  num: number;
  stormCapa?: number;
  wwCapa?: number;
  addr: string;
  status: string;
  ownership: string;
  x: number;
  y: number;
};

export type OutletRecord = {
  id: string;
  name: string;
  category: string;
  type: string;
  flap: string;
  status: string;
  cod: number;
  ammonia: number;
  ownership: string;
  x: number;
  y: number;
};

export type PlantRecord = {
  id: string;
  name: string;
  buildYear: string;
  area: number;
  designCapa: number;
  servicePop: number;
  process: string;
  inQuality: string;
  outQuality: string;
  status: string;
  x: number;
  y: number;
};

export const pumpStationData: PumpStationRecord[] = [
  { id: 'PS2025040700001', name: '高新区雨水泵站', category: '雨水', num: 3, stormCapa: 5.2, addr: '韶山路与高新大道交叉口', status: '1', ownership: '高新区管委会', x: 112.532, y: 27.915 },
  { id: 'PS2025040700002', name: '工业园污水泵站', category: '污水', num: 2, wwCapa: 1.8, addr: '工业大道北段', status: '1', ownership: '市政养护中心', x: 112.548, y: 27.923 },
  { id: 'PS2025040700003', name: '综合提升泵站', category: '合流', num: 4, stormCapa: 3.5, addr: '高新大道中段', status: '2', ownership: '高新区管委会', x: 112.525, y: 27.91 },
  { id: 'PS2025040700004', name: '南部雨水泵站', category: '雨水', num: 2, stormCapa: 2.8, addr: '南环路东段', status: '1', ownership: '高新区管委会', x: 112.558, y: 27.935 },
];

export const outletData: OutletRecord[] = [
  { id: 'OF2025040700001', name: '韶河1号排口', category: '雨水', type: '管道', flap: '1', status: '正常', cod: 15, ammonia: 0.5, ownership: '高新区管委会', x: 112.545, y: 27.92 },
  { id: 'OF2025040700002', name: '工业园A区排污口', category: '污水', type: '涵洞', flap: '0', status: '超标', cod: 48, ammonia: 3.2, ownership: '工业园区', x: 112.555, y: 27.928 },
  { id: 'OF2025040700003', name: '生活区合流排口', category: '合流', type: '明渠', flap: '1', status: '正常', cod: 22, ammonia: 0.8, ownership: '市政养护中心', x: 112.535, y: 27.918 },
  { id: 'OF2025040700004', name: '污水处理厂出水口', category: '设施', type: '管道', flap: '1', status: '达标', cod: 8, ammonia: 0.2, ownership: '污水厂运营方', x: 112.530, y: 27.912 },
];

export const plantData: PlantRecord[] = [
  { id: 'WWTP202504070001', name: '高新区污水处理厂', buildYear: '2018', area: 12.5, designCapa: 3.5, servicePop: 15.2, process: 'A2O+深度处理', inQuality: '纳管标准', outQuality: '一级A', status: '1', x: 112.528, y: 27.908 },
];
