/**
 * @name 设施管理
 * @description 从「韶山水环境一张图」拆分的设施管理独立原型：排水管网（管点/管线）、泵站、排口、污水处理厂；无顶部一级菜单，仅左侧导航与主内容区。
 * @mode axure
 *
 * 参考资料：
 * - /rules/development-standards.md
 * - /skills/axure-export-workflow/SKILL.md
 */

import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';

import {
  Layout,
  Card,
  Row,
  Col,
  Badge,
  Table,
  Button,
  Select,
  Input,
  Tag,
  Alert,
  Space,
  Typography,
  Divider,
  Descriptions,
  Empty,
  Spin,
  Dropdown,
  Modal,
  message,
  Form,
  Checkbox,
  Tooltip,
  Upload
} from 'antd';
import type { DescriptionsProps } from 'antd';
import {
  BuildOutlined,
  SearchOutlined,
  DownloadOutlined,
  DownOutlined,
  UpOutlined,
  ArrowRightOutlined,
  DeleteOutlined,
  EnvironmentTwoTone,
  GlobalOutlined,
  PlusOutlined,
  ColumnHeightOutlined,
  EyeOutlined,
  EditOutlined,
  EyeInvisibleOutlined,
  LeftOutlined,
  RightOutlined,
  ClockCircleOutlined,
  FireOutlined,
  PlayCircleOutlined,
  PauseCircleOutlined,
  StepBackwardOutlined,
  StepForwardOutlined,
  DatabaseOutlined,
  GatewayOutlined,
  ExperimentOutlined,
  NodeExpandOutlined,
  LineChartOutlined,
  DotChartOutlined,
  ShoppingOutlined,
  ShoppingCartOutlined,
  HomeOutlined,
  ToolOutlined,
  AlertOutlined,
  WarningOutlined,
  FileTextOutlined,
  TeamOutlined,
  BorderOutlined,
  LineOutlined,
  ExportOutlined,
  ApartmentOutlined,
  UploadOutlined
} from '@ant-design/icons';
import './style.css';
import { DetailTabsIfMultiple } from '../shared/detailTabsIfMultiple';
import {
  PumpDetailContent,
  OutletDetailContent,
  PlantDetailContent,
} from './facility-pump-outlet-plant-details';
import { pumpStationData, outletData, plantData } from './facility-points-data';

// ==================== 通用组件：表格列字段管理（支持显示/隐藏 + 排序） ====================

/**
 * 字段管理下拉里「显示/隐藏」模式下的列顺序：与表格一致——先按当前 visibleColumns（与排序模式相同），再按定义顺序补未勾选列，最后操作列。
 */
function getFieldManagementColumnKeys(columns: ColumnConfig[], visibleColumns: string[]): string[] {
  const op = 'operation';
  const definitionDataKeys = columns.map(c => c.key).filter(k => k !== op);
  const visibleDataKeys = visibleColumns.filter(k => k !== op);
  const hiddenKeys = definitionDataKeys.filter(k => !visibleDataKeys.includes(k));
  return [...visibleDataKeys, ...hiddenKeys, op];
}

interface ColumnManagerProps {
  columns: ColumnConfig[];
  visibleColumns: string[];
  onChange: (visibleColumns: string[]) => void;
  onSort?: (newOrder: string[]) => void; // 新增排序回调
}

const ColumnManager: React.FC<ColumnManagerProps> = ({ columns, visibleColumns, onChange, onSort }) => {
  const [open, setOpen] = useState(false);
  const [isSortMode, setIsSortMode] = useState(false);

  const handleToggleColumn = (key: string, checked: boolean) => {
    if (checked) {
      onChange([...visibleColumns, key]);
    } else {
      // 只有操作列（最后一个）是固定的，不可隐藏
      if (key === 'operation') {
        message.warning('操作列不可隐藏');
        return;
      }
      onChange(visibleColumns.filter(k => k !== key));
    }
  };

  const handleReset = () => {
    // 与列表初始 visibleColumns 一致：除操作列外，仅 defaultVisible!==false 的列默认勾选（标识码类为 false）
    const defaultKeys = columns
      .filter(c => c.key !== 'operation' && c.defaultVisible !== false)
      .map(c => c.key);
    onChange(defaultKeys);
    message.success('已重置为默认显示');
  };

  // 处理排序 - 上移
  const handleMoveUp = (index: number) => {
    if (index <= 0) return;
    const newOrder = [...visibleColumns];
    [newOrder[index], newOrder[index - 1]] = [newOrder[index - 1], newOrder[index]];
    onChange(newOrder);
    onSort?.(newOrder);
  };

  // 处理排序 - 下移
  const handleMoveDown = (index: number) => {
    if (index >= visibleColumns.length - 1) return;
    const newOrder = [...visibleColumns];
    [newOrder[index], newOrder[index + 1]] = [newOrder[index + 1], newOrder[index]];
    onChange(newOrder);
    onSort?.(newOrder);
  };

  // 获取可排序的列（排除操作列）
  const sortableColumns = visibleColumns.filter(key => key !== 'operation');

  const dropdownContent = (
    <Card 
      title={
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span>字段管理</span>
          <Button 
            type="link" 
            size="small" 
            onClick={() => setIsSortMode(!isSortMode)}
          >
            {isSortMode ? '完成排序' : '排序'}
          </Button>
        </div>
      } 
      style={{ width: isSortMode ? 360 : 320 }} 
      size="small"
    >
      <div style={{ maxHeight: 400, overflow: 'auto' }}>
        {isSortMode ? (
          // 排序模式
          <>
            <div style={{ marginBottom: 12, fontSize: 12, color: '#999' }}>
              拖拽排序（点击上下箭头调整顺序）
            </div>
            {sortableColumns.map((key, index) => {
              const col = columns.find(c => c.key === key);
              return (
                <div key={key} style={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  padding: '8px 0',
                  borderBottom: '1px solid #f0f0f0'
                }}>
                  <span style={{ flex: 1 }}>{col?.title}</span>
                  <Space>
                    <Button 
                      type="text" 
                      size="small" 
                      disabled={index === 0}
                      onClick={() => handleMoveUp(index)}
                    >
                      ↑
                    </Button>
                    <Button 
                      type="text" 
                      size="small" 
                      disabled={index === sortableColumns.length - 1}
                      onClick={() => handleMoveDown(index)}
                    >
                      ↓
                    </Button>
                  </Space>
                </div>
              );
            })}
            <div style={{ marginTop: 8, padding: '8px', background: '#f5f5f5', borderRadius: 4, fontSize: 12, color: '#666' }}>
              操作列始终固定在末尾
            </div>
          </>
        ) : (
          // 显示/隐藏模式（顺序与排序模式 / 表格列顺序一致）
          getFieldManagementColumnKeys(columns, visibleColumns).map(key => {
            const col = columns.find(c => c.key === key);
            if (!col) return null;
            return (
              <div key={col.key} style={{ marginBottom: 8 }}>
                <Checkbox
                  checked={visibleColumns.includes(col.key)}
                  onChange={(e) => handleToggleColumn(col.key, e.target.checked)}
                  disabled={col.key === 'operation'} // 操作列不可隐藏
                >
                  <Space>
                    {col.title}
                    {col.key === 'operation' && <Tag color="blue" style={{ fontSize: 10 }}>固定</Tag>}
                  </Space>
                </Checkbox>
              </div>
            );
          })
        )}
      </div>
      {!isSortMode && (
        <>
          <Divider style={{ margin: '12px 0' }} />
          <Button type="link" onClick={handleReset} size="small">
            恢复默认
          </Button>
        </>
      )}
    </Card>
  );

  return (
    <Dropdown
      open={open}
      dropdownRender={() => dropdownContent}
      placement="bottomRight"
      onOpenChange={(visible) => {
        setOpen(visible);
        if (!visible) setIsSortMode(false); // 关闭时重置排序模式
      }}
    >
      <Tooltip title="字段管理">
        <Button icon={<ColumnHeightOutlined />}>
          字段
        </Button>
      </Tooltip>
    </Dropdown>
  );
};

// ==================== 类型定义 ====================

// 表格列配置类型
interface ColumnConfig {
  key: string;
  title: string;
  dataIndex?: string;
  width?: number;
  fixed?: 'left' | 'right';
  render?: (value: any, record: any) => React.ReactNode;
  defaultVisible?: boolean;
}

/** 字段管理初始勾选：除操作列与 defaultVisible===false（标识码类字段）外全部勾选，与「恢复默认」一致 */
const getDefaultVisibleColumnKeys = (cols: ColumnConfig[]): string[] =>
  cols.filter(c => c.key !== 'operation' && c.defaultVisible !== false).map(c => c.key);

/** 无 width 的列采用的默认宽度（px） */
const DEFAULT_FACILITY_COL_WIDTH = 120;

/**
 * 按当前可见列的 width 累加作为 Table 的 scroll.x：列数或显隐变化时总宽度随之变化，表体可横向滚动。
 */
function getFacilityTableScrollX(cols: { width?: number }[]): number {
  const total = cols.reduce(
    (sum, c) => sum + (typeof c.width === 'number' ? c.width : DEFAULT_FACILITY_COL_WIDTH),
    0,
  );
  return Math.max(total, 100);
}

type ViewState =
  | 'facilities-pipe-node'
  | 'facilities-pipe-line'
  | 'facilities-pump'
  | 'facilities-outlet'
  | 'facilities-plant';

// Ant Design 组件解构
const { Content } = Layout;
const { Text } = Typography;
const { Search } = Input;

/** 新增/编辑类弹窗：与生态整治项目管理一致，仅内容区上下滚动；横向不溢出（避免 Row gutter 负边距出现横向滚动条） */
const formModalStyles = {
  body: {
    maxHeight: 'calc(100vh - 240px)',
    overflowY: 'auto' as const,
    overflowX: 'hidden' as const,
    minWidth: 0,
  },
};

/** 列表「详情」只读弹窗：与生态整治大型只读详情一致，内容区可滚动区域略增高 */
const detailModalStyles = {
  ...formModalStyles,
  body: { ...formModalStyles.body, maxHeight: 'min(85vh, 900px)', overflowY: 'auto' as const },
};

// ==================== 菜单配置（仅设施管理：左侧纵向，无顶部一级菜单） ====================

interface SidebarMenuItem {
  key: string;
  label: string;
  icon?: React.ReactNode;
  children?: SidebarMenuItem[];
}

/** 设施管理侧边栏（与原一张图「设施管理」子菜单一致） */
const facilitySidebarMenus: SidebarMenuItem[] = [
  {
    key: 'facilities-pipe',
    label: '排水管网',
    icon: <BuildOutlined />,
    children: [
      { key: 'facilities-pipe-node', label: '排水管点' },
      { key: 'facilities-pipe-line', label: '排水管线' }
    ]
  },
  { key: 'facilities-pump', label: '泵站', icon: <BuildOutlined /> },
  { key: 'facilities-outlet', label: '排口', icon: <BuildOutlined /> },
  { key: 'facilities-plant', label: '污水厂', icon: <BuildOutlined /> }
];

// ==================== 模拟数据 ====================


// 排水管点数据（GB51187-2016标准）- 包含检查井、雨水口等
const pipeNodeData = [
  // 检查井
  { nodeId: 'N2025040700001', systemId: 'SYS001', nodeType: '1', x: 112.526, y: 27.912, roadName: '高新大道', surfaceElev: 15.2, status: '1', ownership: '高新区管委会', maintainCompany: '市政养护中心', dataSource: '竣工图', reportUnit: '高新区管委会', reportDate: '2018-05-12',
    // 检查井扩展字段
    manholeCategory: '雨水检查井', manholeType: '1', manholeStyle: '1', depth: 3.5, covMaterial: '2', covShape: '1', covDimen: 'φ700' },
  { nodeId: 'N2025040700002', systemId: 'SYS001', nodeType: '1', x: 112.538, y: 27.918, roadName: '高新大道', surfaceElev: 15.0, status: '1', ownership: '高新区管委会', maintainCompany: '市政养护中心', dataSource: '竣工图', reportUnit: '高新区管委会', reportDate: '2018-05-12',
    manholeCategory: '雨水检查井', manholeType: '1', manholeStyle: '1', depth: 3.2, covMaterial: '2', covShape: '1', covDimen: 'φ700' },
  { nodeId: 'N2025040700003', systemId: 'SYS001', nodeType: '1', x: 112.540, y: 27.920, roadName: '工业大道', surfaceElev: 14.8, status: '1', ownership: '高新区管委会', maintainCompany: '市政养护中心', dataSource: '竣工图', reportUnit: '高新区管委会', reportDate: '2018-06-15',
    manholeCategory: '污水检查井', manholeType: '1', manholeStyle: '2', depth: 4.2, covMaterial: '1', covShape: '1', covDimen: 'φ800' },
  { nodeId: 'N2025040700004', systemId: 'SYS001', nodeType: '1', x: 112.552, y: 27.925, roadName: '工业大道', surfaceElev: 14.5, status: '1', ownership: '高新区管委会', maintainCompany: '市政养护中心', dataSource: '竣工图', reportUnit: '高新区管委会', reportDate: '2018-06-15',
    manholeCategory: '污水检查井', manholeType: '1', manholeStyle: '2', depth: 4.0, covMaterial: '1', covShape: '1', covDimen: 'φ800' },
  // 雨水口
  { nodeId: 'N2025040700005', systemId: 'SYS001', nodeType: '2', x: 112.555, y: 27.928, roadName: '韶山路', surfaceElev: 15.5, status: '1', ownership: '高新区管委会', maintainCompany: '市政养护中心', dataSource: '竣工图', reportUnit: '高新区管委会', reportDate: '2018-07-20',
    // 雨水口扩展字段
    combType: '1', combShape: '1', combDimen: '750×450', graMaterial: '铸铁', graSpacing: 25, maxDepth: 1.8, designSluiCapa: 15.0, antiTrash: '1', antiOdor: '1' },
  { nodeId: 'N2025040700006', systemId: 'SYS001', nodeType: '2', x: 112.560, y: 27.930, roadName: '韶山路', surfaceElev: 15.3, status: '1', ownership: '高新区管委会', maintainCompany: '市政养护中心', dataSource: '竣工图', reportUnit: '高新区管委会', reportDate: '2018-07-20',
    combType: '1', combShape: '1', combDimen: '750×450', graMaterial: '铸铁', graSpacing: 25, maxDepth: 1.6, designSluiCapa: 15.0, antiTrash: '1', antiOdor: '1' }
];

// 排水管线数据（GB51187-2016标准）- 关联起点和终点管点
const pipeLineData = [
  { lineId: 'L2025040700001', systemId: 'SYS001', fromNodeId: 'N2025040700001', toNodeId: 'N2025040700002', lineCategory: '1', lineType: '1', material: 'HDPE', diameter: 800, lineLength: 1250.5, startDepth: 3.5, endDepth: 3.2, startElev: 11.7, endElev: 11.8, section: '1', sectionSize: 'DN800', lineMode: '1', buildDate: '2018-05-12', useLife: 50, status: '1', ownership: '高新区管委会', maintainCompany: '市政养护中心', dataSource: '竣工图', createTime: '2024-01-15', updateTime: '2024-04-07' },
  { lineId: 'L2025040700002', systemId: 'SYS001', fromNodeId: 'N2025040700003', toNodeId: 'N2025040700004', lineCategory: '2', lineType: '1', material: '钢筋混凝土', diameter: 600, lineLength: 890.3, startDepth: 4.2, endDepth: 4.0, startElev: 10.6, endElev: 10.5, section: '1', sectionSize: 'DN600', lineMode: '1', buildDate: '2018-06-15', useLife: 50, status: '1', ownership: '高新区管委会', maintainCompany: '市政养护中心', dataSource: '竣工图', createTime: '2024-01-15', updateTime: '2024-04-07' },
  { lineId: 'L2025040700003', systemId: 'SYS001', fromNodeId: 'N2025040700005', toNodeId: 'N2025040700006', lineCategory: '3', lineType: '2', material: 'HDPE', diameter: 400, lineLength: 450.8, startDepth: 2.8, endDepth: 2.6, startElev: 12.7, endElev: 12.9, section: '1', sectionSize: 'DN400', lineMode: '1', buildDate: '2018-07-20', useLife: 50, status: '2', ownership: '市政养护中心', maintainCompany: '市政养护中心', dataSource: '竣工图', createTime: '2024-01-15', updateTime: '2024-04-07' }
];

// 应急事件数据

// ==================== 地图位置展示组件 ====================

const MapLocationCard = ({ 
  title, 
  x, 
  y, 
  type 
}: { 
  title: string; 
  x: number; 
  y: number; 
  type?: 'point' | 'line' 
}) => {
  return (
    <Card 
      title={<><GlobalOutlined /> 地图位置</>} 
      className="map-location-card"
      style={{ marginTop: 16 }}
    >
      <div className="map-mini-placeholder">
        <div className="map-mini-mock">
          <div className="map-mini-header">
            <EnvironmentTwoTone style={{ fontSize: 24 }} />
            <Text strong style={{ marginLeft: 8 }}>{title}</Text>
          </div>
          <div className="coordinate-info">
            <div className="coord-row">
              <Text type="secondary">经度：</Text>
              <Tag color="blue">{x.toFixed(6)}°E</Tag>
            </div>
            <div className="coord-row">
              <Text type="secondary">纬度：</Text>
              <Tag color="green">{y.toFixed(6)}°N</Tag>
            </div>
          </div>
          <div className="map-mini-body">
            <GlobalOutlined style={{ fontSize: 48, color: '#1677ff', opacity: 0.3 }} />
            <div className="map-mini-text">地图区域（天地图底图）</div>
            <div className="map-marker">
              <div className="marker-dot"></div>
              <div className="marker-pulse"></div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
};

// ==================== 工具函数 ====================

// 生成新的标识码（模拟）
const generateId = (prefix: string) => {
  const date = new Date();
  const timestamp = date.getFullYear().toString() +
    String(date.getMonth() + 1).padStart(2, '0') +
    String(date.getDate()).padStart(2, '0');
  const random = String(Math.floor(Math.random() * 1000000)).padStart(6, '0');
  return `${prefix}${timestamp}${random}`;
};

// 获取当前日期字符串
const getCurrentDate = () => {
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
};

// ==================== 辅助组件 ====================


const StatusTag = ({ status }: { status: string }) => {
  const config: Record<string, { color: string; text: string }> = {
    '1': { color: 'success', text: '正常' },
    '2': { color: 'warning', text: '检修' },
    '3': { color: 'error', text: '故障' },
    '4': { color: 'default', text: '在建' },
    'normal': { color: 'success', text: '正常' },
    'warning': { color: 'warning', text: '预警' },
    'error': { color: 'error', text: '超标' },
    '达标': { color: 'success', text: '达标' },
    '超标': { color: 'error', text: '超标' }
  };
  const cfg = config[status] || { color: 'default', text: status };
  return <Badge status={cfg.color as any} text={cfg.text} />;
};

// 获取管点类型的显示名称
const getNodeTypeName = (type: string) => {
  const typeMap: Record<string, string> = {
    '1': '检查井',
    '2': '雨水口',
    '3': '交汇井',
    '4': '阀门井',
    '5': '溢流井'
  };
  return typeMap[type] || '未知';
};

/** 排水管点台账选项：管线「起点/终点管点」下拉与搜索（与 pipeNodeData 同源） */
const pipeNodeIdSelectOptions = pipeNodeData.map((n) => ({
  value: n.nodeId,
  label: `${n.nodeId}（${getNodeTypeName(n.nodeType)} · ${n.roadName || '—'}）`,
}));

/** 管点标识码 Select：可下拉选或输入关键字筛选台账中的编号 */
const PipeNodeIdSelect: React.FC<{ placeholder?: string }> = ({ placeholder }) => (
  <Select
    showSearch
    allowClear
    placeholder={placeholder ?? '搜索编号或下拉选择'}
    options={pipeNodeIdSelectOptions}
    optionFilterProp="label"
    filterOption={(input, option) => {
      const q = (input || '').trim().toLowerCase();
      if (!q) return true;
      const v = String((option as { value?: string })?.value ?? '').toLowerCase();
      const lab = String((option as { label?: React.ReactNode })?.label ?? '').toLowerCase();
      return v.includes(q) || lab.includes(q);
    }}
    notFoundContent="无匹配管点，请核对编号或先在「排水管点」中维护"
  />
);

// 获取管点类型的标签颜色
const getNodeTypeColor = (type: string) => {
  const colorMap: Record<string, string> = {
    '1': 'blue',
    '2': 'green',
    '3': 'orange',
    '4': 'purple',
    '5': 'red'
  };
  return colorMap[type] || 'default';
};

// ==================== 湘潭风格详情组件 ====================

/** 详情字段项：span 为原 4 列栅格语义；展示时换算为生态整治「项目详情」同款 column=2（1=半行，≥2=整行通栏） */
interface DetailTableItem {
  label: string;
  value: React.ReactNode;
  span?: 1 | 2 | 3 | 4;
}

interface DetailCardProps {
  title: string;
  items: DetailTableItem[];
}

/** 空值与生态整治详情一致：灰色「—」 */
function renderDetailFieldValue(value: React.ReactNode): React.ReactNode {
  if (value == null || value === '') {
    return <span className="detail-value-empty">—</span>;
  }
  if (typeof value === 'string' && (value.trim() === '' || value === '-' || value === '—')) {
    return <span className="detail-value-empty">—</span>;
  }
  return value;
}

function mapDetailItemSpan(span: number | undefined): number {
  const s = span ?? 1;
  return s >= 2 ? 2 : 1;
}

/** 分组 + bordered Descriptions column=2，对齐生态整治「项目详情」基本信息 Tab */
const DetailCard: React.FC<DetailCardProps> = ({ title, items }) => {
  const descItems: NonNullable<DescriptionsProps['items']> = items.map((item, idx) => ({
    key: `${item.label}-${idx}`,
    label: item.label,
    children: renderDetailFieldValue(item.value),
    span: mapDetailItemSpan(item.span)
  }));

  return (
    <div className="detail-section">
      <div className="detail-section-title">{title}</div>
      <div className="detail-section-content">
        <Descriptions bordered column={2} size="small" items={descItems} />
      </div>
    </div>
  );
};

// 湘潭风格详情页组件（带标签页）
interface DetailTab {
  key: string;
  label: string;
  children: React.ReactNode;
}

interface XiangtanDetailViewProps {
  /** 保留参数便于调用方语义对齐，标题由外层 Modal.title 展示（与生态整治「项目详情」弹窗一致） */
  title?: string;
  subtitle?: string;
  tabs: DetailTab[];
  extra?: React.ReactNode;
  /** 多 Tab 时初始选中的标签 key（须存在于 tabs）；不传则默认第一项 */
  defaultActiveKey?: string;
}

/** 与生态整治「河湖长制 · 事务详情」一致：多 Tab 时 small Tabs + facility-detail-tabs；仅一块内容时不展示 Tab 顶栏 */
const XiangtanDetailView: React.FC<XiangtanDetailViewProps> = ({ tabs, defaultActiveKey }) => {
  const resolvedKey =
    defaultActiveKey && tabs.some((t) => t.key === defaultActiveKey) ? defaultActiveKey : tabs[0]?.key;
  return (
    <DetailTabsIfMultiple
      className="facility-detail-tabs facility-mgmt-detail-tabs"
      size="small"
      style={{ marginTop: 8 }}
      defaultActiveKey={resolvedKey}
      items={tabs}
    />
  );
};

// ==================== 排水管点详情组件（湘潭风格） ====================

const PipeNodeDetailContent = ({ record, isEdit }: { record: any; isEdit?: boolean }) => {
  // 基础信息分组
  const basicInfoItems: DetailTableItem[] = [
    { label: '管点标识码', value: record.nodeId },
    { label: '排水系统标识码', value: record.systemId },
    { label: '管点类型', value: getNodeTypeName(record.nodeType) },
    { label: '坐标X', value: record.x?.toFixed(3) },
    { label: '坐标Y', value: record.y?.toFixed(3) },
    { label: '所在道路', value: record.roadName },
    { label: '地面高程', value: record.surfaceElev ? `${record.surfaceElev} m` : undefined },
    { label: '设施状态', value: <StatusTag status={record.status} /> },
    { label: '权属单位', value: record.ownership },
    { label: '养护单位', value: record.maintainCompany },
    { label: '数据来源', value: record.dataSource },
    { label: '填报单位', value: record.reportUnit },
    { label: '填报日期', value: record.reportDate },
  ];

  // 检查井扩展信息
  const manholeItems: DetailTableItem[] = record.nodeType === '1' ? [
    { label: '检查井类别', value: record.manholeCategory },
    { label: '检查井类型', value: record.manholeType === '1' ? '检查井' : record.manholeType === '2' ? '跌水井' : record.manholeType === '3' ? '水封井' : '闸阀井' },
    { label: '检查井形式', value: record.manholeStyle === '1' ? '圆形' : '矩形' },
    { label: '检查井井深', value: record.depth ? `${record.depth} m` : undefined },
    { label: '井盖材质', value: record.covMaterial === '1' ? '铸铁' : '钢纤维混凝土' },
    { label: '井盖形状', value: record.covShape === '1' ? '圆形' : '方形' },
    { label: '井盖尺寸', value: record.covDimen },
  ] : [];

  // 雨水口扩展信息
  const combItems: DetailTableItem[] = record.nodeType === '2' ? [
    { label: '雨水口形式', value: record.combType === '1' ? '平箅' : record.combType === '2' ? '立箅' : '联合' },
    { label: '雨水口形状', value: record.combShape === '1' ? '圆形' : record.combShape === '2' ? '矩形' : '椭圆形' },
    { label: '雨水口尺寸', value: record.combDimen },
    { label: '雨水箅材质', value: record.graMaterial },
    { label: '雨水箅间距', value: record.graSpacing ? `${record.graSpacing} 毫米` : undefined },
    { label: '最大深度', value: record.maxDepth ? `${record.maxDepth} 米` : undefined },
    { label: '设计能力', value: record.designSluiCapa ? `${record.designSluiCapa} 升每秒` : undefined },
    { label: '垃圾拦截装置', value: record.antiTrash === '1' ? '有' : '无' },
    { label: '防臭装置', value: record.antiOdor === '1' ? '有' : '无' },
  ] : [];

  return (
    <div style={{ marginTop: 8 }}>
      <DetailCard title="管点基础信息" items={basicInfoItems} />
      {manholeItems.length > 0 && <DetailCard title="检查井扩展信息" items={manholeItems} />}
      {combItems.length > 0 && <DetailCard title="雨水口扩展信息" items={combItems} />}
    </div>
  );
};

// 排水管点表单组件（新增/编辑共用）
const PipeNodeFormContent = ({ form, initialValues, isEdit }: { form: any; initialValues?: any; isEdit?: boolean }) => {
  const nodeType = Form.useWatch('nodeType', form);
  
  return (
    <Form form={form} layout="vertical" initialValues={initialValues}>
      <Divider titlePlacement="start">基础信息</Divider>
      <Row gutter={16}>
        <Col span={8}>
          <Form.Item label="管点标识码" name="nodeId" rules={[{ required: true }]}>
            <Input disabled={isEdit} placeholder="系统自动生成或手动输入" />
          </Form.Item>
        </Col>
        <Col span={8}>
          <Form.Item label="排水系统标识码" name="systemId" rules={[{ required: true }]}>
            <Input placeholder="如：SYS001" />
          </Form.Item>
        </Col>
        <Col span={8}>
          <Form.Item label="管点类型" name="nodeType" rules={[{ required: true }]}>
            <Select placeholder="选择管点类型">
              <Select.Option value="1">1-检查井</Select.Option>
              <Select.Option value="2">2-雨水口</Select.Option>
              <Select.Option value="3">3-交汇井</Select.Option>
              <Select.Option value="4">4-阀门井</Select.Option>
              <Select.Option value="5">5-溢流井</Select.Option>
            </Select>
          </Form.Item>
        </Col>
      </Row>
      <Row gutter={16}>
        <Col span={8}>
          <Form.Item label="坐标X" name="x" rules={[{ required: true }]}>
            <Input type="number" placeholder="国家2000坐标系X" />
          </Form.Item>
        </Col>
        <Col span={8}>
          <Form.Item label="坐标Y" name="y" rules={[{ required: true }]}>
            <Input type="number" placeholder="国家2000坐标系Y" />
          </Form.Item>
        </Col>
        <Col span={8}>
          <Form.Item label="所在道路名称" name="roadName">
            <Input placeholder="如：高新大道" />
          </Form.Item>
        </Col>
      </Row>
      <Row gutter={16}>
        <Col span={8}>
          <Form.Item label="地面高程(m)" name="surfaceElev">
            <Input type="number" placeholder="单位：米" />
          </Form.Item>
        </Col>
        <Col span={8}>
          <Form.Item label="设施状态" name="status" rules={[{ required: true }]}>
            <Select placeholder="选择状态">
              <Select.Option value="1">1-运行</Select.Option>
              <Select.Option value="0">0-废弃</Select.Option>
              <Select.Option value="2">2-在建</Select.Option>
            </Select>
          </Form.Item>
        </Col>
        <Col span={8}>
          <Form.Item label="权属单位" name="ownership" rules={[{ required: true }]}>
            <Input placeholder="如：高新区管委会" />
          </Form.Item>
        </Col>
      </Row>
      <Row gutter={16}>
        <Col span={8}>
          <Form.Item label="养护单位" name="maintainCompany" rules={[{ required: true }]}>
            <Input placeholder="如：市政养护中心" />
          </Form.Item>
        </Col>
        <Col span={8}>
          <Form.Item label="数据来源" name="dataSource" rules={[{ required: true }]}>
            <Input placeholder="如：竣工图" />
          </Form.Item>
        </Col>
        <Col span={8}>
          <Form.Item label="填报单位" name="reportUnit" rules={[{ required: true }]}>
            <Input placeholder="如：高新区管委会" />
          </Form.Item>
        </Col>
      </Row>
      <Row gutter={16}>
        <Col span={8}>
          <Form.Item label="填报日期" name="reportDate" rules={[{ required: true }]}>
            <Input type="date" />
          </Form.Item>
        </Col>
      </Row>

      {/* 检查井扩展字段 */}
      {nodeType === '1' && (
        <>
          <Divider titlePlacement="start">检查井扩展信息</Divider>
          <Row gutter={16}>
            <Col span={8}>
              <Form.Item label="检查井类别" name="manholeCategory">
                <Input placeholder="分类代码" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="检查井类型" name="manholeType">
                <Select placeholder="选择类型">
                  <Select.Option value="1">1-检查井</Select.Option>
                  <Select.Option value="2">2-跌水井</Select.Option>
                  <Select.Option value="3">3-水封井</Select.Option>
                  <Select.Option value="4">4-闸阀井</Select.Option>
                </Select>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="检查井形式" name="manholeStyle">
                <Select placeholder="选择形式">
                  <Select.Option value="1">1-圆形</Select.Option>
                  <Select.Option value="2">2-矩形</Select.Option>
                  <Select.Option value="3">3-其他</Select.Option>
                </Select>
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={16}>
            <Col span={8}>
              <Form.Item label="检查井井深(m)" name="depth">
                <Input type="number" placeholder="单位：米" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="井盖材质" name="covMaterial">
                <Select placeholder="选择材质">
                  <Select.Option value="1">1-铸铁</Select.Option>
                  <Select.Option value="2">2-钢纤维混凝土</Select.Option>
                  <Select.Option value="3">3-其他</Select.Option>
                </Select>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="井盖形状" name="covShape">
                <Select placeholder="选择形状">
                  <Select.Option value="1">1-圆形</Select.Option>
                  <Select.Option value="2">2-方形</Select.Option>
                </Select>
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={16}>
            <Col span={8}>
              <Form.Item label="井盖尺寸" name="covDimen">
                <Input placeholder="如：φ700" />
              </Form.Item>
            </Col>
          </Row>
        </>
      )}

      {/* 雨水口扩展字段 */}
      {nodeType === '2' && (
        <>
          <Divider titlePlacement="start">雨水口扩展信息</Divider>
          <Row gutter={16}>
            <Col span={8}>
              <Form.Item label="雨水口形式" name="combType">
                <Select placeholder="选择形式">
                  <Select.Option value="1">1-平箅</Select.Option>
                  <Select.Option value="2">2-立箅</Select.Option>
                  <Select.Option value="3">3-平立箅</Select.Option>
                  <Select.Option value="4">4-联合</Select.Option>
                </Select>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="雨水口形状" name="combShape">
                <Select placeholder="选择形状">
                  <Select.Option value="1">1-圆形</Select.Option>
                  <Select.Option value="2">2-矩形</Select.Option>
                  <Select.Option value="3">3-椭圆形</Select.Option>
                </Select>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="雨水口尺寸" name="combDimen">
                <Input placeholder="尺寸说明" />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={16}>
            <Col span={8}>
              <Form.Item label="雨水箅材质" name="graMaterial">
                <Input placeholder="材质说明" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="雨水箅间距(mm)" name="graSpacing">
                <Input type="number" placeholder="单位：毫米" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="最大深度(m)" name="maxDepth">
                <Input type="number" placeholder="单位：米" />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={16}>
            <Col span={8}>
              <Form.Item label="设计能力（升每秒）" name="designSluiCapa">
                <Input type="number" placeholder="单位：升/秒" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="垃圾拦截装置" name="antiTrash">
                <Select placeholder="是否装备">
                  <Select.Option value="0">0-否</Select.Option>
                  <Select.Option value="1">1-是</Select.Option>
                </Select>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="防臭装置" name="antiOdor">
                <Select placeholder="是否装备">
                  <Select.Option value="0">0-否</Select.Option>
                  <Select.Option value="1">1-是</Select.Option>
                </Select>
              </Form.Item>
            </Col>
          </Row>
        </>
      )}
    </Form>
  );
};

// 排水管点管理视图
const PipeNodeView = ({
  onDetail,
}: {
  onDetail: (title: string, content: React.ReactNode, modalWidth?: number | string) => void;
}) => {
  const [data, setData] = useState(pipeNodeData);
  const [editModalVisible, setEditModalVisible] = useState(false);
  const [addModalVisible, setAddModalVisible] = useState(false);
  const [editingRecord, setEditingRecord] = useState<any>(null);
  const [isEditMode, setIsEditMode] = useState(false);
  const [editForm] = Form.useForm();
  const [addForm] = Form.useForm();

  // 所有列配置（操作列右侧固定；标识码类 defaultVisible:false，其余默认展示）
  const allColumns: ColumnConfig[] = [
    { key: 'nodeId', title: '管点标识码', dataIndex: 'nodeId', width: 160, defaultVisible: false }, // 标识码默认不显示，宽度减小
    { key: 'systemId', title: '排水系统标识码', dataIndex: 'systemId', width: 150, defaultVisible: false }, // 标识码默认不显示，宽度减小
    { key: 'nodeType', title: '管点类型', dataIndex: 'nodeType', width: 120, defaultVisible: true, render: (v: string) => <Tag color={getNodeTypeColor(v)}>{getNodeTypeName(v)}</Tag> },
    { key: 'x', title: '坐标X', dataIndex: 'x', width: 110, defaultVisible: true, render: (v: number) => v.toFixed(3) },
    { key: 'y', title: '坐标Y', dataIndex: 'y', width: 110, defaultVisible: true, render: (v: number) => v.toFixed(3) },
    { key: 'roadName', title: '所在道路', dataIndex: 'roadName', width: 140, defaultVisible: true },
    { key: 'surfaceElev', title: '地面高程(m)', dataIndex: 'surfaceElev', width: 110, defaultVisible: true },
    { key: 'status', title: '设施状态', dataIndex: 'status', width: 100, defaultVisible: true, render: (v: string) => <StatusTag status={v} /> },
    { key: 'ownership', title: '权属单位', dataIndex: 'ownership', width: 140, defaultVisible: true },
    { key: 'maintainCompany', title: '养护单位', dataIndex: 'maintainCompany', width: 140, defaultVisible: true },
    { key: 'dataSource', title: '数据来源', dataIndex: 'dataSource', width: 110, defaultVisible: true },
    { key: 'reportUnit', title: '填报单位', dataIndex: 'reportUnit', width: 140, defaultVisible: true },
    { key: 'reportDate', title: '填报日期', dataIndex: 'reportDate', width: 110, defaultVisible: true },
    { key: 'operation', title: '操作', width: 180, defaultVisible: true } // 列尾展示，字段管理不可隐藏（含图标链接，需留足宽）
  ];

  const [visibleColumns, setVisibleColumns] = useState<string[]>(() => getDefaultVisibleColumnKeys(allColumns));

  // 根据可见列生成实际列配置（按visibleColumns顺序排序）
  const columns = allColumns
    .filter(col => visibleColumns.includes(col.key) || col.key === 'operation')
    .sort((a, b) => {
      // 操作列始终在最后
      if (a.key === 'operation') return 1;
      if (b.key === 'operation') return -1;
      // 其他列按visibleColumns顺序
      const indexA = visibleColumns.indexOf(a.key);
      const indexB = visibleColumns.indexOf(b.key);
      return indexA - indexB;
    })
    .map(col => {
      if (col.key === 'operation') {
        return {
          ...col,
          fixed: 'right' as const,
          render: (_: any, record: any) => (
            <Space size="small">
              <Button
                type="link"
                size="small"
                className="action-btn detail"
                icon={<EyeOutlined />}
                onClick={() =>
                  onDetail(`${getNodeTypeName(record.nodeType)}详情 - ${record.nodeId}`, <PipeNodeDetailContent record={record} />)
                }
              >
                详情
              </Button>
              <Button
                type="link"
                size="small"
                className="action-btn edit"
                icon={<EditOutlined />}
                onClick={() => handleEdit(record)}
              >
                编辑
              </Button>
            </Space>
          )
        };
      }
      return col;
    });

  const facilityTableScrollX = getFacilityTableScrollX(
    allColumns.filter(col => visibleColumns.includes(col.key) || col.key === 'operation'),
  );

  const handleDelete = (id: string) => {
    setData(data.filter(item => item.nodeId !== id));
    message.success('删除成功');
    setEditModalVisible(false);
  };

  const handleEdit = (record: any) => {
    setEditingRecord(record);
    setIsEditMode(true);
    // 设置表单初始值
    editForm.setFieldsValue(record);
    setEditModalVisible(true);
  };

  const handleEditSave = () => {
    editForm.validateFields().then(values => {
      setData(data.map(item => item.nodeId === editingRecord.nodeId ? { ...item, ...values } : item));
      message.success('保存成功');
      setEditModalVisible(false);
    });
  };

  const handleAdd = () => {
    addForm.resetFields();
    // 设置默认值
    addForm.setFieldsValue({
      nodeId: generateId('N'),
      systemId: 'SYS001',
      status: '1',
      reportDate: getCurrentDate(),
      dataSource: '竣工图'
    });
    setAddModalVisible(true);
  };

  const handleAddSave = () => {
    addForm.validateFields().then(values => {
      const newRecord = {
        ...values,
        x: parseFloat(values.x),
        y: parseFloat(values.y),
        surfaceElev: values.surfaceElev ? parseFloat(values.surfaceElev) : undefined,
        depth: values.depth ? parseFloat(values.depth) : undefined,
        graSpacing: values.graSpacing ? parseFloat(values.graSpacing) : undefined,
        maxDepth: values.maxDepth ? parseFloat(values.maxDepth) : undefined,
        designSluiCapa: values.designSluiCapa ? parseFloat(values.designSluiCapa) : undefined,
      };
      setData([newRecord, ...data]);
      message.success('新增成功');
      setAddModalVisible(false);
    });
  };

  return (
    <div className="facility-view">
      <Card 
        title="排水管点管理" 
        extra={
          <Space wrap size={[8, 8]} align="center">
            <Button icon={<DownloadOutlined />} className="export-btn">导出</Button>
            <Upload
              beforeUpload={() => {
                message.success('已导入（原型示意）');
                return false;
              }}
              showUploadList={false}
            >
              <Button icon={<UploadOutlined />}>导入</Button>
            </Upload>
            <ColumnManager 
              columns={allColumns} 
              visibleColumns={visibleColumns} 
              onChange={setVisibleColumns} 
            />
            <Button type="primary" icon={<PlusOutlined />} onClick={handleAdd} className="add-btn">新增</Button>
          </Space>
        }
      >
        <Row gutter={16} style={{ marginBottom: 16 }}>
          <Col span={6}><Search placeholder="搜索管点标识码" /></Col>
          <Col span={4}>
            <Select placeholder="管点类型" style={{ width: '100%' }}>
              <Select.Option value="">全部</Select.Option>
              <Select.Option value="1">检查井</Select.Option>
              <Select.Option value="2">雨水口</Select.Option>
            </Select>
          </Col>
          <Col span={4}>
            <Select placeholder="设施状态" style={{ width: '100%' }}>
              <Select.Option value="">全部</Select.Option>
              <Select.Option value="1">运行</Select.Option>
              <Select.Option value="0">废弃</Select.Option>
              <Select.Option value="2">在建</Select.Option>
            </Select>
          </Col>
        </Row>
        <div className="facility-table-wrap">
          <Table
            dataSource={data}
            columns={columns}
            rowKey="nodeId"
            scroll={{ x: facilityTableScrollX }}
            pagination={{ pageSize: 10 }}
          />
        </div>
      </Card>

      {/* 新增弹窗 */}
      <Modal
        styles={formModalStyles}
        title="新增管点"
        open={addModalVisible}
        onOk={handleAddSave}
        onCancel={() => setAddModalVisible(false)}
        width={800}
        footer={
          <Space>
            <Button onClick={() => setAddModalVisible(false)}>取消</Button>
            <Button type="primary" onClick={handleAddSave}>保存</Button>
          </Space>
        }
      >
        <PipeNodeFormContent form={addForm} />
      </Modal>

      {/* 编辑/详情弹窗 */}
      <Modal
        styles={formModalStyles}
        title={isEditMode ? `编辑${editingRecord ? getNodeTypeName(editingRecord.nodeType) : ''} - ${editingRecord?.nodeId}` : `${editingRecord ? getNodeTypeName(editingRecord.nodeType) : ''}详情 - ${editingRecord?.nodeId}`}
        open={editModalVisible}
        onOk={isEditMode ? handleEditSave : () => setEditModalVisible(false)}
        onCancel={() => setEditModalVisible(false)}
        width={800}
        footer={
          isEditMode ? (
            <Space>
              <Button danger onClick={() => handleDelete(editingRecord?.nodeId)}>删除</Button>
              <Button onClick={() => setEditModalVisible(false)}>取消</Button>
              <Button type="primary" onClick={handleEditSave}>保存</Button>
            </Space>
          ) : (
            <Space>
              <Button type="primary" onClick={() => setIsEditMode(true)}>进入编辑</Button>
            </Space>
          )
        }
      >
        {editingRecord && (
          isEditMode ? (
            <PipeNodeFormContent form={editForm} initialValues={editingRecord} isEdit />
          ) : (
            <PipeNodeDetailContent record={editingRecord} />
          )
        )}
      </Modal>
    </div>
  );
};

// 获取管线关联的管点信息
const getNodeById = (nodeId: string) => {
  return pipeNodeData.find(node => node.nodeId === nodeId);
};

// 排水管线详情/编辑内容组件
const PipeLineDetailContent = ({ record }: { record: any }) => {
  // 获取起点和终点管点信息
  const fromNode = getNodeById(record.fromNodeId);
  const toNode = getNodeById(record.toNodeId);

  // 基本信息 Tab 内容（顶距由 .facility-detail-tabs 首块样式与生态整治一致）
  const BasicInfoTab = () => (
    <Descriptions bordered column={2} size="small">
      <Descriptions.Item label="管线标识码">{record.lineId}</Descriptions.Item>
      <Descriptions.Item label="排水系统标识码">{record.systemId}</Descriptions.Item>
      <Descriptions.Item label="管线类别">
        {record.lineCategory === '1' ? '雨水' : record.lineCategory === '2' ? '污水' : record.lineCategory === '3' ? '合流' : '其他'}
      </Descriptions.Item>
      <Descriptions.Item label="管线类型">
        {record.lineType === '1' ? '主管' : record.lineType === '2' ? '支管' : '接户管'}
      </Descriptions.Item>
      <Descriptions.Item label="材质">{record.material}</Descriptions.Item>
      <Descriptions.Item label="管径">{record.diameter} 毫米</Descriptions.Item>
      <Descriptions.Item label="管长">{record.lineLength} m</Descriptions.Item>
      <Descriptions.Item label="起点埋深">{record.startDepth} m</Descriptions.Item>
      <Descriptions.Item label="终点埋深">{record.endDepth} m</Descriptions.Item>
      <Descriptions.Item label="起点高程">{record.startElev} m</Descriptions.Item>
      <Descriptions.Item label="终点高程">{record.endElev} m</Descriptions.Item>
      <Descriptions.Item label="断面形式">
        {record.section === '1' ? '圆形' : record.section === '2' ? '矩形' : '梯形'}
      </Descriptions.Item>
      <Descriptions.Item label="断面尺寸">{record.sectionSize}</Descriptions.Item>
      <Descriptions.Item label="敷设方式">
        {record.lineMode === '1' ? '直埋' : record.lineMode === '2' ? '顶管' : '盾构'}
      </Descriptions.Item>
      <Descriptions.Item label="敷设日期">{record.buildDate}</Descriptions.Item>
      <Descriptions.Item label="使用年限">{record.useLife} 年</Descriptions.Item>
      <Descriptions.Item label="管线状态"><StatusTag status={record.status} /></Descriptions.Item>
      <Descriptions.Item label="权属单位">{record.ownership}</Descriptions.Item>
      <Descriptions.Item label="养护单位">{record.maintainCompany}</Descriptions.Item>
      <Descriptions.Item label="数据来源">{record.dataSource}</Descriptions.Item>
      <Descriptions.Item label="记录建立日期">{record.createTime}</Descriptions.Item>
      <Descriptions.Item label="最后修改日期">{record.updateTime}</Descriptions.Item>
    </Descriptions>
  );

  // 起点信息 Tab 内容
  const FromNodeTab = () => (
    fromNode ? (
      <Descriptions bordered column={2} size="small">
        <Descriptions.Item label="管点标识码">{fromNode.nodeId}</Descriptions.Item>
        <Descriptions.Item label="管点类型">{getNodeTypeName(fromNode.nodeType)}</Descriptions.Item>
        <Descriptions.Item label="坐标X">{fromNode.x.toFixed(3)}</Descriptions.Item>
        <Descriptions.Item label="坐标Y">{fromNode.y.toFixed(3)}</Descriptions.Item>
        <Descriptions.Item label="地面高程">{fromNode.surfaceElev} m</Descriptions.Item>
        <Descriptions.Item label="所在道路">{fromNode.roadName}</Descriptions.Item>
        <Descriptions.Item label="设施状态"><StatusTag status={fromNode.status} /></Descriptions.Item>
        {fromNode.nodeType === '1' && (
          <>
            <Descriptions.Item label="检查井井深">{fromNode.depth} m</Descriptions.Item>
            <Descriptions.Item label="井盖材质">{fromNode.covMaterial === '1' ? '铸铁' : '钢纤维混凝土'}</Descriptions.Item>
            <Descriptions.Item label="井盖尺寸">{fromNode.covDimen}</Descriptions.Item>
          </>
        )}
      </Descriptions>
    ) : (
      <Alert message="起点管点信息未找到" type="warning" />
    )
  );

  // 终点信息 Tab 内容
  const ToNodeTab = () => (
    toNode ? (
      <Descriptions bordered column={2} size="small">
        <Descriptions.Item label="管点标识码">{toNode.nodeId}</Descriptions.Item>
        <Descriptions.Item label="管点类型">{getNodeTypeName(toNode.nodeType)}</Descriptions.Item>
        <Descriptions.Item label="坐标X">{toNode.x.toFixed(3)}</Descriptions.Item>
        <Descriptions.Item label="坐标Y">{toNode.y.toFixed(3)}</Descriptions.Item>
        <Descriptions.Item label="地面高程">{toNode.surfaceElev} m</Descriptions.Item>
        <Descriptions.Item label="所在道路">{toNode.roadName}</Descriptions.Item>
        <Descriptions.Item label="设施状态"><StatusTag status={toNode.status} /></Descriptions.Item>
        {toNode.nodeType === '1' && (
          <>
            <Descriptions.Item label="检查井井深">{toNode.depth} m</Descriptions.Item>
            <Descriptions.Item label="井盖材质">{toNode.covMaterial === '1' ? '铸铁' : '钢纤维混凝土'}</Descriptions.Item>
            <Descriptions.Item label="井盖尺寸">{toNode.covDimen}</Descriptions.Item>
          </>
        )}
      </Descriptions>
    ) : (
      <Alert message="终点管点信息未找到" type="warning" />
    )
  );

  const tabItems = [
    { key: 'basic', label: '基本信息', children: <BasicInfoTab /> },
    { key: 'from', label: `起点信息 (${record.fromNodeId})`, children: <FromNodeTab /> },
    { key: 'to', label: `终点信息 (${record.toNodeId})`, children: <ToNodeTab /> },
  ];

  return (
    <DetailTabsIfMultiple
      className="facility-detail-tabs facility-mgmt-detail-tabs"
      size="small"
      style={{ marginTop: 8 }}
      defaultActiveKey="basic"
      items={tabItems}
    />
  );
};

// 排水管线表单（新增/编辑共用）
const PipeLineFormContent = ({ form, initialValues, isEdit }: { form: any; initialValues?: any; isEdit?: boolean }) => (
  <Form form={form} layout="vertical" initialValues={initialValues}>
    <Divider titlePlacement="start">基础信息</Divider>
    <Row gutter={16}>
      <Col span={8}>
        <Form.Item label="管线标识码" name="lineId" rules={[{ required: true }]}>
          <Input disabled={isEdit} placeholder="系统自动生成" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="排水系统标识码" name="systemId" rules={[{ required: true }]}>
          <Input placeholder="如：SYS001" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="管线类别" name="lineCategory" rules={[{ required: true }]}>
          <Select placeholder="选择类别">
            <Select.Option value="1">雨水</Select.Option>
            <Select.Option value="2">污水</Select.Option>
            <Select.Option value="3">合流</Select.Option>
            <Select.Option value="4">其他</Select.Option>
          </Select>
        </Form.Item>
      </Col>
    </Row>
    <Row gutter={16}>
      <Col span={8}>
        <Form.Item label="管线类型" name="lineType" rules={[{ required: true }]}>
          <Select placeholder="选择类型">
            <Select.Option value="1">主管</Select.Option>
            <Select.Option value="2">支管</Select.Option>
            <Select.Option value="3">接户管</Select.Option>
          </Select>
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item
          label="起点管点标识码"
          name="fromNodeId"
          dependencies={['toNodeId']}
          rules={[
            { required: true, message: '请选择或搜索起点管点' },
            ({ getFieldValue }) => ({
              validator(_: unknown, value: string) {
                const to = getFieldValue('toNodeId');
                if (value && to && value === to) {
                  return Promise.reject(new Error('起点与终点不能为同一管点'));
                }
                return Promise.resolve();
              },
            }),
          ]}
        >
          <PipeNodeIdSelect placeholder="搜索编号或下拉选择起点" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item
          label="终点管点标识码"
          name="toNodeId"
          dependencies={['fromNodeId']}
          rules={[
            { required: true, message: '请选择或搜索终点管点' },
            ({ getFieldValue }) => ({
              validator(_: unknown, value: string) {
                const from = getFieldValue('fromNodeId');
                if (value && from && value === from) {
                  return Promise.reject(new Error('起点与终点不能为同一管点'));
                }
                return Promise.resolve();
              },
            }),
          ]}
        >
          <PipeNodeIdSelect placeholder="搜索编号或下拉选择终点" />
        </Form.Item>
      </Col>
    </Row>
    <Divider titlePlacement="start">管线参数</Divider>
    <Row gutter={16}>
      <Col span={8}>
        <Form.Item label="材质" name="material" rules={[{ required: true }]}>
          <Input placeholder="如：HDPE" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="管径(mm)" name="diameter" rules={[{ required: true }]}>
          <Input type="number" placeholder="单位：毫米" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="管长(m)" name="lineLength" rules={[{ required: true }]}>
          <Input type="number" placeholder="单位：米" />
        </Form.Item>
      </Col>
    </Row>
    <Row gutter={16}>
      <Col span={8}>
        <Form.Item label="起点埋深(m)" name="startDepth">
          <Input type="number" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="终点埋深(m)" name="endDepth">
          <Input type="number" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="断面形式" name="section">
          <Select placeholder="断面形式">
            <Select.Option value="1">圆形</Select.Option>
            <Select.Option value="2">矩形</Select.Option>
            <Select.Option value="3">梯形</Select.Option>
          </Select>
        </Form.Item>
      </Col>
    </Row>
    <Row gutter={16}>
      <Col span={8}>
        <Form.Item label="断面尺寸" name="sectionSize">
          <Input placeholder="如：DN800" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="敷设方式" name="lineMode">
          <Select placeholder="敷设方式">
            <Select.Option value="1">直埋</Select.Option>
            <Select.Option value="2">顶管</Select.Option>
            <Select.Option value="3">盾构</Select.Option>
          </Select>
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="起点高程(m)" name="startElev">
          <Input type="number" />
        </Form.Item>
      </Col>
    </Row>
    <Row gutter={16}>
      <Col span={8}>
        <Form.Item label="终点高程(m)" name="endElev">
          <Input type="number" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="敷设日期" name="buildDate">
          <Input type="date" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="使用年限(年)" name="useLife">
          <Input type="number" />
        </Form.Item>
      </Col>
    </Row>
    <Divider titlePlacement="start">管理信息</Divider>
    <Row gutter={16}>
      <Col span={8}>
        <Form.Item label="管线状态" name="status" rules={[{ required: true }]}>
          <Select placeholder="状态">
            <Select.Option value="1">正常</Select.Option>
            <Select.Option value="2">废弃</Select.Option>
            <Select.Option value="3">检修</Select.Option>
          </Select>
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="权属单位" name="ownership" rules={[{ required: true }]}>
          <Input />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="养护单位" name="maintainCompany">
          <Input />
        </Form.Item>
      </Col>
    </Row>
    <Row gutter={16}>
      <Col span={8}>
        <Form.Item label="数据来源" name="dataSource" rules={[{ required: true }]}>
          <Input placeholder="如：竣工图" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="记录建立日期" name="createTime">
          <Input type="date" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="最后修改日期" name="updateTime">
          <Input type="date" />
        </Form.Item>
      </Col>
    </Row>
  </Form>
);

// 泵站表单（新增/编辑共用）
const PumpFormContent = ({ form, initialValues, isEdit }: { form: any; initialValues?: any; isEdit?: boolean }) => (
  <Form form={form} layout="vertical" initialValues={initialValues}>
    <Divider titlePlacement="start">基础信息</Divider>
    <Row gutter={16}>
      <Col span={8}>
        <Form.Item label="泵站标识码" name="id" rules={[{ required: true }]}>
          <Input disabled={isEdit} />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="排水系统标识码" name="systemId">
          <Input placeholder="如：SYS001" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="泵站名称" name="name" rules={[{ required: true }]}>
          <Input />
        </Form.Item>
      </Col>
    </Row>
    <Row gutter={16}>
      <Col span={8}>
        <Form.Item label="泵站类别" name="category" rules={[{ required: true }]}>
          <Select placeholder="类别">
            <Select.Option value="雨水">雨水</Select.Option>
            <Select.Option value="污水">污水</Select.Option>
            <Select.Option value="合流">合流</Select.Option>
          </Select>
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="泵台数" name="num" rules={[{ required: true }]}>
          <Input type="number" min={0} />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="运行状态" name="status" rules={[{ required: true }]}>
          <Select>
            <Select.Option value="1">运行中</Select.Option>
            <Select.Option value="2">检修</Select.Option>
            <Select.Option value="3">故障</Select.Option>
          </Select>
        </Form.Item>
      </Col>
    </Row>
    <Row gutter={16}>
      <Col span={12}>
        <Form.Item label="泵站地址" name="addr" rules={[{ required: true }]}>
          <Input />
        </Form.Item>
      </Col>
      <Col span={6}>
        <Form.Item label="坐标X" name="x" rules={[{ required: true }]}>
          <Input type="number" step="0.000001" />
        </Form.Item>
      </Col>
      <Col span={6}>
        <Form.Item label="坐标Y" name="y" rules={[{ required: true }]}>
          <Input type="number" step="0.000001" />
        </Form.Item>
      </Col>
    </Row>
    <Row gutter={16}>
      <Col span={8}>
        <Form.Item label="设计雨水排水能力（立方米每秒）" name="stormCapa">
          <Input type="number" step="0.1" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="设计污水排水能力（立方米每秒）" name="wwCapa">
          <Input type="number" step="0.1" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="权属单位" name="ownership" rules={[{ required: true }]}>
          <Input />
        </Form.Item>
      </Col>
    </Row>
    <Row gutter={16}>
      <Col span={8}>
        <Form.Item label="数据来源" name="dataSource">
          <Input placeholder="竣工图" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="填报单位" name="reportUnit">
          <Input />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="记录建立日期" name="createTime">
          <Input type="date" />
        </Form.Item>
      </Col>
    </Row>
    <Divider titlePlacement="start">池体与水位（选填）</Divider>
    <Row gutter={16}>
      <Col span={8}><Form.Item label="前池长(m)" name="forebayLen"><Input type="number" /></Form.Item></Col>
      <Col span={8}><Form.Item label="前池宽(m)" name="forebayWid"><Input type="number" /></Form.Item></Col>
      <Col span={8}><Form.Item label="前池深(m)" name="forebayDep"><Input type="number" /></Form.Item></Col>
    </Row>
    <Row gutter={16}>
      <Col span={8}><Form.Item label="进水池最高水位(m)" name="inPoolMaxLev"><Input type="number" /></Form.Item></Col>
      <Col span={8}><Form.Item label="进水池常水位(m)" name="inPoolNorLev"><Input type="number" /></Form.Item></Col>
      <Col span={8}><Form.Item label="进水池最低水位(m)" name="inPoolMinLev"><Input type="number" /></Form.Item></Col>
    </Row>
    <Row gutter={16}>
      <Col span={8}><Form.Item label="出水池设计水位(m)" name="outPoolDesLev"><Input type="number" /></Form.Item></Col>
      <Col span={8}><Form.Item label="出水池最高水位(m)" name="outPoolMaxLev"><Input type="number" /></Form.Item></Col>
      <Col span={8}><Form.Item label="出水池最低水位(m)" name="outPoolMinLev"><Input type="number" /></Form.Item></Col>
    </Row>
    <Row gutter={16}>
      <Col span={8}>
        <Form.Item label="技术资料编号" name="dataListId">
          <Input placeholder="如：TS2024001" />
        </Form.Item>
      </Col>
    </Row>
  </Form>
);

// 排口表单（新增/编辑共用）
const OutletFormContent = ({ form, initialValues, isEdit }: { form: any; initialValues?: any; isEdit?: boolean }) => (
  <Form form={form} layout="vertical" initialValues={initialValues}>
    <Divider titlePlacement="start">基础信息</Divider>
    <Row gutter={16}>
      <Col span={8}>
        <Form.Item label="排放口标识码" name="id" rules={[{ required: true }]}>
          <Input disabled={isEdit} />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="入河排污口名称" name="name" rules={[{ required: true }]}>
          <Input />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="入河排污口编码" name="pwkCode">
          <Input placeholder="可与标识码关联" />
        </Form.Item>
      </Col>
    </Row>
    <Row gutter={16}>
      <Col span={8}>
        <Form.Item label="类别" name="category" rules={[{ required: true }]}>
          <Select>
            <Select.Option value="雨水">雨水</Select.Option>
            <Select.Option value="污水">污水</Select.Option>
            <Select.Option value="合流">合流</Select.Option>
            <Select.Option value="设施">设施</Select.Option>
          </Select>
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="类型" name="type" rules={[{ required: true }]}>
          <Select>
            <Select.Option value="管道">管道</Select.Option>
            <Select.Option value="涵洞">涵洞</Select.Option>
            <Select.Option value="明渠">明渠</Select.Option>
          </Select>
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="排放状态" name="status" rules={[{ required: true }]}>
          <Select>
            <Select.Option value="正常">正常</Select.Option>
            <Select.Option value="超标">超标</Select.Option>
            <Select.Option value="达标">达标</Select.Option>
          </Select>
        </Form.Item>
      </Col>
    </Row>
    <Row gutter={16}>
      <Col span={8}>
        <Form.Item label="经度" name="x" rules={[{ required: true }]}>
          <Input type="number" step="0.000001" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="纬度" name="y" rules={[{ required: true }]}>
          <Input type="number" step="0.000001" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="是否有拍门" name="flap">
          <Select>
            <Select.Option value="1">有</Select.Option>
            <Select.Option value="0">无</Select.Option>
          </Select>
        </Form.Item>
      </Col>
    </Row>
    <Row gutter={16}>
      <Col span={12}>
        <Form.Item label="排放口地址" name="addr">
          <Input />
        </Form.Item>
      </Col>
      <Col span={6}>
        <Form.Item label="权属单位" name="ownership" rules={[{ required: true }]}>
          <Input />
        </Form.Item>
      </Col>
      <Col span={6}>
        <Form.Item label="底部高程(m)" name="bottomElev">
          <Input type="number" />
        </Form.Item>
      </Col>
    </Row>
    <Divider titlePlacement="start">监测数据</Divider>
    <Row gutter={16}>
      <Col span={8}>
        <Form.Item label="化学需氧量（毫克每升）" name="cod">
          <Input type="number" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="氨氮（毫克每升）" name="ammonia">
          <Input type="number" step="0.01" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="总磷（毫克每升）" name="phosphorus">
          <Input type="number" step="0.01" />
        </Form.Item>
      </Col>
    </Row>
    <Row gutter={16}>
      <Col span={8}>
        <Form.Item label="酸碱度" name="ph">
          <Input type="number" step="0.1" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="总氮（毫克每升）" name="totalNitrogen">
          <Input type="number" step="0.01" />
        </Form.Item>
      </Col>
    </Row>
  </Form>
);

// 污水厂表单（新增/编辑共用）
const PlantFormContent = ({ form, initialValues, isEdit }: { form: any; initialValues?: any; isEdit?: boolean }) => (
  <Form form={form} layout="vertical" initialValues={initialValues}>
    <Divider titlePlacement="start">基础信息</Divider>
    <Row gutter={16}>
      <Col span={8}>
        <Form.Item label="污水处理厂标识码" name="id" rules={[{ required: true }]}>
          <Input disabled={isEdit} />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="排水系统标识码" name="systemId">
          <Input placeholder="SYS001" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="污水厂名称" name="name" rules={[{ required: true }]}>
          <Input />
        </Form.Item>
      </Col>
    </Row>
    <Row gutter={16}>
      <Col span={12}>
        <Form.Item label="污水厂地址" name="addr">
          <Input />
        </Form.Item>
      </Col>
      <Col span={6}>
        <Form.Item label="建设年份" name="buildYear" rules={[{ required: true }]}>
          <Input />
        </Form.Item>
      </Col>
      <Col span={6}>
        <Form.Item label="设施状态" name="status" rules={[{ required: true }]}>
          <Select>
            <Select.Option value="1">运行</Select.Option>
            <Select.Option value="0">停运</Select.Option>
            <Select.Option value="2">在建</Select.Option>
          </Select>
        </Form.Item>
      </Col>
    </Row>
    <Row gutter={16}>
      <Col span={8}>
        <Form.Item label="坐标X(经纬度)" name="x" rules={[{ required: true }]}>
          <Input type="number" step="0.000001" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="坐标Y(经纬度)" name="y" rules={[{ required: true }]}>
          <Input type="number" step="0.000001" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="占地面积(hm²)" name="area">
          <Input type="number" step="0.1" />
        </Form.Item>
      </Col>
    </Row>
    <Row gutter={16}>
      <Col span={8}>
        <Form.Item label="设计处理规模（万立方米每日）" name="designCapa" rules={[{ required: true }]}>
          <Input type="number" step="0.1" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="服务人口(万人)" name="servicePop">
          <Input type="number" step="0.1" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="纳管污染源数量" name="connPollutionNum">
          <Input type="number" min={0} />
        </Form.Item>
      </Col>
    </Row>
    <Row gutter={16}>
      <Col span={12}>
        <Form.Item label="服务范围" name="serviceArea">
          <Input placeholder="如：高新区全域" />
        </Form.Item>
      </Col>
      <Col span={12}>
        <Form.Item label="处理工艺" name="process" rules={[{ required: true }]}>
          <Input placeholder="如：A2O+深度处理" />
        </Form.Item>
      </Col>
    </Row>
    <Row gutter={16}>
      <Col span={12}>
        <Form.Item label="进水水质目标" name="inQuality">
          <Input />
        </Form.Item>
      </Col>
      <Col span={12}>
        <Form.Item label="出水水质目标" name="outQuality">
          <Input />
        </Form.Item>
      </Col>
    </Row>
    <Row gutter={16}>
      <Col span={8}>
        <Form.Item label="权属单位" name="ownership">
          <Input />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="填报单位" name="reportUnit">
          <Input />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="数据来源" name="dataSource">
          <Input placeholder="竣工图" />
        </Form.Item>
      </Col>
    </Row>
    <Row gutter={16}>
      <Col span={8}>
        <Form.Item label="记录建立日期" name="createTime">
          <Input type="date" />
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item label="最后修改日期" name="updateTime">
          <Input type="date" />
        </Form.Item>
      </Col>
    </Row>
  </Form>
);

// 排水管线管理视图
const PipeLineView = ({ onDetail }: { onDetail: (title: string, content: React.ReactNode) => void }) => {
  const [data, setData] = useState(pipeLineData);
  const [editModalVisible, setEditModalVisible] = useState(false);
  const [addModalVisible, setAddModalVisible] = useState(false);
  const [editingRecord, setEditingRecord] = useState<any>(null);
  const [isEditMode, setIsEditMode] = useState(false);
  const [editForm] = Form.useForm();
  const [addForm] = Form.useForm();

  // 管线表格全量字段配置（操作列右侧固定；标识码类 defaultVisible:false，其余默认展示）
  const allColumns: ColumnConfig[] = [
    { key: 'lineId', title: '管线标识码', dataIndex: 'lineId', width: 160, defaultVisible: false }, // 标识码默认不显示，宽度减小
    { key: 'systemId', title: '排水系统标识码', dataIndex: 'systemId', width: 150, defaultVisible: false }, // 标识码默认不显示，宽度减小
    { key: 'fromNodeId', title: '起点管点', dataIndex: 'fromNodeId', width: 140, defaultVisible: false }, // 标识码默认不显示，宽度减小
    { key: 'toNodeId', title: '终点管点', dataIndex: 'toNodeId', width: 140, defaultVisible: false }, // 标识码默认不显示，宽度减小
    { key: 'lineCategory', title: '管线类别', dataIndex: 'lineCategory', width: 100, defaultVisible: true, render: (v: string) => v === '1' ? '雨水' : v === '2' ? '污水' : v === '3' ? '合流' : '其他' },
    { key: 'lineType', title: '管线类型', dataIndex: 'lineType', width: 100, defaultVisible: true, render: (v: string) => v === '1' ? '主管' : v === '2' ? '支管' : '接户管' },
    { key: 'material', title: '材质', dataIndex: 'material', width: 100, defaultVisible: true },
    { key: 'diameter', title: '管径(mm)', dataIndex: 'diameter', width: 90, defaultVisible: true },
    { key: 'lineLength', title: '管长(m)', dataIndex: 'lineLength', width: 90, defaultVisible: true },
    { key: 'startDepth', title: '起点埋深(m)', dataIndex: 'startDepth', width: 100, defaultVisible: true },
    { key: 'endDepth', title: '终点埋深(m)', dataIndex: 'endDepth', width: 100, defaultVisible: true },
    { key: 'startElev', title: '起点高程(m)', dataIndex: 'startElev', width: 100, defaultVisible: true },
    { key: 'endElev', title: '终点高程(m)', dataIndex: 'endElev', width: 100, defaultVisible: true },
    { key: 'section', title: '断面形式', dataIndex: 'section', width: 90, defaultVisible: true, render: (v: string) => v === '1' ? '圆形' : v === '2' ? '矩形' : '梯形' },
    { key: 'lineMode', title: '敷设方式', dataIndex: 'lineMode', width: 90, defaultVisible: true, render: (v: string) => v === '1' ? '直埋' : v === '2' ? '顶管' : '盾构' },
    { key: 'buildDate', title: '敷设日期', dataIndex: 'buildDate', width: 100, defaultVisible: true },
    { key: 'useLife', title: '使用年限', dataIndex: 'useLife', width: 90, defaultVisible: true, render: (v: number) => `${v}年` },
    { key: 'status', title: '管线状态', dataIndex: 'status', width: 90, defaultVisible: true, render: (v: string) => <StatusTag status={v} /> },
    { key: 'ownership', title: '权属单位', dataIndex: 'ownership', width: 130, defaultVisible: true },
    { key: 'maintainCompany', title: '养护单位', dataIndex: 'maintainCompany', width: 130, defaultVisible: true },
    { key: 'dataSource', title: '数据来源', dataIndex: 'dataSource', width: 100, defaultVisible: true },
    { key: 'operation', title: '操作', width: 180, defaultVisible: true }
  ];

  const [visibleColumns, setVisibleColumns] = useState<string[]>(() => getDefaultVisibleColumnKeys(allColumns));

  const handleDelete = (id: string) => {
    setData(data.filter(item => item.lineId !== id));
    message.success('删除成功');
    setEditModalVisible(false);
  };

  const handleEdit = (record: any) => {
    setEditingRecord(record);
    setIsEditMode(true);
    editForm.setFieldsValue(record);
    setEditModalVisible(true);
  };

  const handleEditSave = () => {
    editForm.validateFields().then(values => {
      const num = (v: any) => (v === '' || v === undefined ? undefined : Number(v));
      const merged = {
        ...values,
        diameter: num(values.diameter),
        lineLength: num(values.lineLength),
        startDepth: num(values.startDepth),
        endDepth: num(values.endDepth),
        startElev: num(values.startElev),
        endElev: num(values.endElev),
        useLife: num(values.useLife),
      };
      setData(data.map(item => item.lineId === editingRecord.lineId ? { ...item, ...merged } : item));
      message.success('保存成功');
      setEditModalVisible(false);
    });
  };

  const handleAdd = () => {
    addForm.resetFields();
    addForm.setFieldsValue({
      lineId: generateId('L'),
      systemId: 'SYS001',
      fromNodeId: '',
      toNodeId: '',
      lineCategory: '1',
      lineType: '1',
      section: '1',
      lineMode: '1',
      status: '1',
      useLife: 50,
      buildDate: getCurrentDate(),
      dataSource: '竣工图',
      createTime: getCurrentDate(),
      updateTime: getCurrentDate(),
    });
    setAddModalVisible(true);
  };

  const handleAddSave = () => {
    addForm.validateFields().then(values => {
      const num = (v: any) => (v === '' || v === undefined ? undefined : Number(v));
      const newRecord = {
        ...values,
        diameter: num(values.diameter),
        lineLength: num(values.lineLength),
        startDepth: num(values.startDepth),
        endDepth: num(values.endDepth),
        startElev: num(values.startElev),
        endElev: num(values.endElev),
        useLife: num(values.useLife),
      };
      setData([newRecord, ...data]);
      message.success('新增成功');
      setAddModalVisible(false);
    });
  };

  // 根据可见列生成实际列配置
  const columns = allColumns
    .filter(col => visibleColumns.includes(col.key) || col.key === 'operation')
    .sort((a, b) => {
      if (a.key === 'operation') return 1;
      if (b.key === 'operation') return -1;
      const indexA = visibleColumns.indexOf(a.key);
      const indexB = visibleColumns.indexOf(b.key);
      return indexA - indexB;
    })
    .map(col => {
      if (col.key === 'operation') {
        return {
          ...col,
          fixed: 'right' as const,
          render: (_: any, record: any) => (
            <Space size="small">
              <Button
                type="link"
                size="small"
                className="action-btn detail"
                icon={<EyeOutlined />}
                onClick={() => onDetail(`管线详情 - ${record.lineId}`, <PipeLineDetailContent record={record} />)}
              >
                详情
              </Button>
              <Button type="link" size="small" className="action-btn edit" icon={<EditOutlined />} onClick={() => handleEdit(record)}>
                编辑
              </Button>
            </Space>
          )
        };
      }
      return col;
    });

  const facilityTableScrollX = getFacilityTableScrollX(
    allColumns.filter(col => visibleColumns.includes(col.key) || col.key === 'operation'),
  );

  return (
    <div className="facility-view">
      <Card
        title="排水管线管理"
        extra={
          <Space wrap size={[8, 8]} align="center">
            <Button icon={<DownloadOutlined />} className="export-btn">导出</Button>
            <Upload
              beforeUpload={() => {
                message.success('已导入（原型示意）');
                return false;
              }}
              showUploadList={false}
            >
              <Button icon={<UploadOutlined />}>导入</Button>
            </Upload>
            <ColumnManager columns={allColumns} visibleColumns={visibleColumns} onChange={setVisibleColumns} />
            <Button type="primary" icon={<PlusOutlined />} onClick={handleAdd} className="add-btn">新增</Button>
          </Space>
        }
      >
        <Row gutter={16} style={{ marginBottom: 16 }}>
          <Col span={6}><Search placeholder="搜索管线标识码或管点编号" /></Col>
          <Col span={4}>
            <Select placeholder="管线类别" style={{ width: '100%' }}>
              <Select.Option value="">全部</Select.Option>
              <Select.Option value="1">雨水</Select.Option>
              <Select.Option value="2">污水</Select.Option>
              <Select.Option value="3">合流</Select.Option>
            </Select>
          </Col>
          <Col span={4}>
            <Select placeholder="材质" style={{ width: '100%' }}>
              <Select.Option value="">全部</Select.Option>
              <Select.Option value="HDPE">HDPE</Select.Option>
              <Select.Option value="钢筋混凝土">钢筋混凝土</Select.Option>
              <Select.Option value="PVC">PVC</Select.Option>
            </Select>
          </Col>
          <Col span={4}>
            <Select placeholder="状态" style={{ width: '100%' }}>
              <Select.Option value="">全部</Select.Option>
              <Select.Option value="1">正常</Select.Option>
              <Select.Option value="2">废弃</Select.Option>
              <Select.Option value="3">检修</Select.Option>
            </Select>
          </Col>
        </Row>
        <div className="facility-table-wrap">
          <Table
            dataSource={data}
            columns={columns}
            rowKey="lineId"
            scroll={{ x: facilityTableScrollX }}
            pagination={{ pageSize: 10 }}
          />
        </div>
      </Card>

      {/* 新增弹窗 */}
      <Modal
        styles={formModalStyles}
        title="新增管线"
        open={addModalVisible}
        onOk={handleAddSave}
        onCancel={() => setAddModalVisible(false)}
        width={800}
        footer={
          <Space>
            <Button onClick={() => setAddModalVisible(false)}>取消</Button>
            <Button type="primary" onClick={handleAddSave}>保存</Button>
          </Space>
        }
      >
        <PipeLineFormContent form={addForm} />
      </Modal>

      {/* 编辑/详情弹窗 */}
      <Modal
        styles={formModalStyles}
        title={isEditMode ? `编辑管线 - ${editingRecord?.lineId}` : `管线详情 - ${editingRecord?.lineId}`}
        open={editModalVisible}
        onOk={isEditMode ? handleEditSave : () => setEditModalVisible(false)}
        onCancel={() => setEditModalVisible(false)}
        width={800}
        footer={
          isEditMode ? (
            <Space>
              <Button danger onClick={() => handleDelete(editingRecord?.lineId)}>删除</Button>
              <Button onClick={() => setEditModalVisible(false)}>取消</Button>
              <Button type="primary" onClick={handleEditSave}>保存</Button>
            </Space>
          ) : (
            <Space>
              <Button
                type="primary"
                onClick={() => {
                  if (editingRecord) editForm.setFieldsValue(editingRecord);
                  setIsEditMode(true);
                }}
              >
                进入编辑
              </Button>
            </Space>
          )
        }
      >
        {editingRecord && (
          isEditMode ? (
            <PipeLineFormContent form={editForm} initialValues={editingRecord} isEdit />
          ) : (
            <PipeLineDetailContent record={editingRecord} />
          )
        )}
      </Modal>
    </div>
  );
};

// 泵站管理视图
const PumpStationView = ({
  onDetail,
}: {
  onDetail: (title: string, content: React.ReactNode, modalWidth?: number | string) => void;
}) => {
  const [data, setData] = useState(pumpStationData);
  const [editModalVisible, setEditModalVisible] = useState(false);
  const [addModalVisible, setAddModalVisible] = useState(false);
  const [editingRecord, setEditingRecord] = useState<any>(null);
  const [isEditMode, setIsEditMode] = useState(false);
  const [editForm] = Form.useForm();
  const [addForm] = Form.useForm();

  // 泵站表格列（操作列右侧固定；泵站标识码 defaultVisible:false，其余默认展示）
  const allColumns: ColumnConfig[] = [
    { key: 'id', title: '泵站标识码', dataIndex: 'id', width: 150, defaultVisible: false },
    { key: 'name', title: '泵站名称', dataIndex: 'name', width: 180, defaultVisible: true },
    { key: 'addr', title: '泵站地址', dataIndex: 'addr', width: 200, defaultVisible: true },
    { key: 'category', title: '泵站类别', dataIndex: 'category', width: 100, defaultVisible: true },
    { key: 'num', title: '泵台数', dataIndex: 'num', width: 80, defaultVisible: true },
    { key: 'stormCapa', title: '雨水排水能力', dataIndex: 'stormCapa', width: 110, defaultVisible: true, render: (v: number) => v ? `${v} 立方米每秒` : '-' },
    { key: 'wwCapa', title: '污水排水能力', dataIndex: 'wwCapa', width: 110, defaultVisible: true, render: (v: number) => v ? `${v} 立方米每秒` : '-' },
    { key: 'forebayLen', title: '前池长(m)', dataIndex: 'forebayLen', width: 90, defaultVisible: true },
    { key: 'forebayWid', title: '前池宽(m)', dataIndex: 'forebayWid', width: 90, defaultVisible: true },
    { key: 'forebayDep', title: '前池深(m)', dataIndex: 'forebayDep', width: 90, defaultVisible: true },
    { key: 'inPoolMaxLev', title: '进水池最高水位(m)', dataIndex: 'inPoolMaxLev', width: 130, defaultVisible: true },
    { key: 'inPoolNorLev', title: '进水池常水位(m)', dataIndex: 'inPoolNorLev', width: 120, defaultVisible: true },
    { key: 'inPoolMinLev', title: '进水池最低水位(m)', dataIndex: 'inPoolMinLev', width: 130, defaultVisible: true },
    { key: 'outPoolDesLev', title: '出水池设计水位(m)', dataIndex: 'outPoolDesLev', width: 140, defaultVisible: true },
    { key: 'outPoolMaxLev', title: '出水池最高水位(m)', dataIndex: 'outPoolMaxLev', width: 140, defaultVisible: true },
    { key: 'outPoolMinLev', title: '出水池最低水位(m)', dataIndex: 'outPoolMinLev', width: 140, defaultVisible: true },
    { key: 'dataListId', title: '技术资料', dataIndex: 'dataListId', width: 100, defaultVisible: true },
    { key: 'dataSource', title: '数据来源', dataIndex: 'dataSource', width: 90, defaultVisible: true },
    { key: 'createTime', title: '记录日期', dataIndex: 'createTime', width: 100, defaultVisible: true },
    { key: 'reportUnit', title: '填报单位', dataIndex: 'reportUnit', width: 130, defaultVisible: true },
    { key: 'ownership', title: '权属单位', dataIndex: 'ownership', width: 130, defaultVisible: true },
    { key: 'operation', title: '操作', width: 300, defaultVisible: true }
  ];

  const [visibleColumns, setVisibleColumns] = useState<string[]>(() => getDefaultVisibleColumnKeys(allColumns));

  const parsePumpNums = (values: any) => {
    const n = (v: any) => (v === '' || v === undefined || v === null ? undefined : Number(v));
    return {
      ...values,
      num: n(values.num),
      stormCapa: n(values.stormCapa),
      wwCapa: n(values.wwCapa),
      x: n(values.x),
      y: n(values.y),
      forebayLen: n(values.forebayLen),
      forebayWid: n(values.forebayWid),
      forebayDep: n(values.forebayDep),
      inPoolMaxLev: n(values.inPoolMaxLev),
      inPoolNorLev: n(values.inPoolNorLev),
      inPoolMinLev: n(values.inPoolMinLev),
      outPoolDesLev: n(values.outPoolDesLev),
      outPoolMaxLev: n(values.outPoolMaxLev),
      outPoolMinLev: n(values.outPoolMinLev),
    };
  };

  const handleDelete = (id: string) => {
    setData(data.filter(item => item.id !== id));
    message.success('删除成功');
    setEditModalVisible(false);
  };

  const handleEdit = (record: any) => {
    setEditingRecord(record);
    setIsEditMode(true);
    editForm.setFieldsValue(record);
    setEditModalVisible(true);
  };

  const handleEditSave = () => {
    editForm.validateFields().then(values => {
      const merged = parsePumpNums(values);
      setData(data.map(item => item.id === editingRecord.id ? { ...item, ...merged } : item));
      message.success('保存成功');
      setEditModalVisible(false);
    });
  };

  const handleAdd = () => {
    addForm.resetFields();
    addForm.setFieldsValue({
      id: generateId('PS'),
      systemId: 'SYS001',
      status: '1',
      dataSource: '竣工图',
      createTime: getCurrentDate(),
      category: '雨水',
      num: 1,
    });
    setAddModalVisible(true);
  };

  const handleAddSave = () => {
    addForm.validateFields().then(values => {
      const newRecord = parsePumpNums(values);
      setData([newRecord, ...data]);
      message.success('新增成功');
      setAddModalVisible(false);
    });
  };

  // 根据可见列生成实际列配置
  const columns = allColumns
    .filter(col => visibleColumns.includes(col.key) || col.key === 'operation')
    .sort((a, b) => {
      if (a.key === 'operation') return 1;
      if (b.key === 'operation') return -1;
      const indexA = visibleColumns.indexOf(a.key);
      const indexB = visibleColumns.indexOf(b.key);
      return indexA - indexB;
    })
    .map(col => {
      if (col.key === 'operation') {
        return {
          ...col,
          fixed: 'right' as const,
          render: (_: any, record: any) => (
            <Space size="small">
              <Button
                type="link"
                size="small"
                className="action-btn detail"
                icon={<EyeOutlined />}
                onClick={() =>
                  onDetail(`泵站详情 - ${record.name}`, <PumpDetailContent record={record} />, 'min(1200px, 96vw)')
                }
              >
                详情
              </Button>
              <Tooltip title="打开详情并定位到实时监测">
                <Button
                  type="link"
                  size="small"
                  className="action-btn detail"
                  icon={<LineChartOutlined />}
                  onClick={() =>
                    onDetail(
                      `泵站详情 - ${record.name}`,
                      <PumpDetailContent record={record} initialTabKey="monitor" />,
                      'min(1200px, 96vw)',
                    )
                  }
                >
                  实时监测
                </Button>
              </Tooltip>
              <Button type="link" size="small" className="action-btn edit" icon={<EditOutlined />} onClick={() => handleEdit(record)}>
                编辑
              </Button>
            </Space>
          )
        };
      }
      return col;
    });

  const facilityTableScrollX = getFacilityTableScrollX(
    allColumns.filter(col => visibleColumns.includes(col.key) || col.key === 'operation'),
  );

  return (
    <div className="facility-view">
      <Card
        title="泵站管理"
        extra={
          <Space wrap size={[8, 8]} align="center">
            <Button icon={<DownloadOutlined />} className="export-btn">导出</Button>
            <Upload
              beforeUpload={() => {
                message.success('已导入（原型示意）');
                return false;
              }}
              showUploadList={false}
            >
              <Button icon={<UploadOutlined />}>导入</Button>
            </Upload>
            <ColumnManager columns={allColumns} visibleColumns={visibleColumns} onChange={setVisibleColumns} />
            <Button type="primary" icon={<PlusOutlined />} onClick={handleAdd} className="add-btn">新增</Button>
          </Space>
        }
      >
        <Row gutter={16} style={{ marginBottom: 16 }}>
          <Col span={6}><Search placeholder="搜索泵站名称或编号" /></Col>
          <Col span={4}>
            <Select placeholder="泵站类别" style={{ width: '100%' }}>
              <Select.Option value="">全部</Select.Option>
              <Select.Option value="雨水">雨水</Select.Option>
              <Select.Option value="污水">污水</Select.Option>
              <Select.Option value="合流">合流</Select.Option>
            </Select>
          </Col>
          <Col span={4}>
            <Select placeholder="运行状态" style={{ width: '100%' }}>
              <Select.Option value="">全部</Select.Option>
              <Select.Option value="1">运行中</Select.Option>
              <Select.Option value="2">检修</Select.Option>
              <Select.Option value="3">故障</Select.Option>
            </Select>
          </Col>
        </Row>
        <div className="facility-table-wrap">
          <Table
            dataSource={data}
            columns={columns}
            rowKey="id"
            scroll={{ x: facilityTableScrollX }}
            pagination={{ pageSize: 10 }}
          />
        </div>
      </Card>

      <Modal
        styles={formModalStyles}
        title="新增泵站"
        open={addModalVisible}
        onOk={handleAddSave}
        onCancel={() => setAddModalVisible(false)}
        width={800}
        footer={
          <Space>
            <Button onClick={() => setAddModalVisible(false)}>取消</Button>
            <Button type="primary" onClick={handleAddSave}>保存</Button>
          </Space>
        }
      >
        <PumpFormContent form={addForm} />
      </Modal>

      <Modal
        styles={formModalStyles}
        title={isEditMode ? `编辑泵站 - ${editingRecord?.name}` : `泵站详情 - ${editingRecord?.name}`}
        open={editModalVisible}
        onOk={isEditMode ? handleEditSave : () => setEditModalVisible(false)}
        onCancel={() => setEditModalVisible(false)}
        width={800}
        footer={
          isEditMode ? (
            <Space>
              <Button danger onClick={() => handleDelete(editingRecord?.id)}>删除</Button>
              <Button onClick={() => setEditModalVisible(false)}>取消</Button>
              <Button type="primary" onClick={handleEditSave}>保存</Button>
            </Space>
          ) : (
            <Space>
              <Button
                type="primary"
                onClick={() => {
                  if (editingRecord) editForm.setFieldsValue(editingRecord);
                  setIsEditMode(true);
                }}
              >
                进入编辑
              </Button>
            </Space>
          )
        }
      >
        {editingRecord && (
          isEditMode ? (
            <PumpFormContent form={editForm} initialValues={editingRecord} isEdit />
          ) : (
            <PumpDetailContent record={editingRecord} />
          )
        )}
      </Modal>
    </div>
  );
};

// 排口管理视图
const OutletView = ({
  onDetail,
}: {
  onDetail: (title: string, content: React.ReactNode, modalWidth?: number | string) => void;
}) => {
  const [data, setData] = useState(outletData);
  const [editModalVisible, setEditModalVisible] = useState(false);
  const [addModalVisible, setAddModalVisible] = useState(false);
  const [editingRecord, setEditingRecord] = useState<any>(null);
  const [isEditMode, setIsEditMode] = useState(false);
  const [editForm] = Form.useForm();
  const [addForm] = Form.useForm();

  // 排口表格列（操作列右侧固定；排放口标识码/入河编码 defaultVisible:false，其余默认展示）
  const allColumns: ColumnConfig[] = [
    { key: 'id', title: '排放口标识码', dataIndex: 'id', width: 150, defaultVisible: false },
    { key: 'name', title: '入河排污口名称', dataIndex: 'name', width: 180, defaultVisible: true },
    { key: 'pwkCode', title: '入河排污口编码', dataIndex: 'pwkCode', width: 150, defaultVisible: false, render: (_: any, record: any) => record.id.replace('OF', 'PWK') },
    { key: 'pwkYjfl', title: '一级分类', dataIndex: 'pwkYjfl', width: 90, defaultVisible: true },
    { key: 'pwkEjfl', title: '二级分类', dataIndex: 'pwkEjfl', width: 90, defaultVisible: true },
    { key: 'spdjbaqk', title: '审批备案', dataIndex: 'spdjbaqk', width: 90, defaultVisible: true },
    { key: 'area', title: '行政区域', dataIndex: 'area', width: 120, defaultVisible: true },
    { key: 'x', title: '经度', dataIndex: 'x', width: 110, defaultVisible: true, render: (v: number) => `${v.toFixed(6)}°E` },
    { key: 'y', title: '纬度', dataIndex: 'y', width: 110, defaultVisible: true, render: (v: number) => `${v.toFixed(6)}°N` },
    { key: 'pwxs', title: '排污水系', dataIndex: 'pwxs', width: 90, defaultVisible: true },
    { key: 'snst', title: '受纳水体', dataIndex: 'snst', width: 110, defaultVisible: true },
    { key: 'pffs', title: '排放方式', dataIndex: 'pffs', width: 90, defaultVisible: true },
    { key: 'category', title: '类别', dataIndex: 'category', width: 90, defaultVisible: true },
    { key: 'type', title: '类型', dataIndex: 'type', width: 90, defaultVisible: true },
    { key: 'flap', title: '是否有拍门', dataIndex: 'flap', width: 100, defaultVisible: true, render: (v: string) => v === '1' ? '有' : '无' },
    { key: 'bottomElev', title: '底部高程(m)', dataIndex: 'bottomElev', width: 100, defaultVisible: true },
    { key: 'outfallType', title: '出流形式', dataIndex: 'outfallType', width: 100, defaultVisible: true },
    { key: 'flapMaterial', title: '拍门材质', dataIndex: 'flapMaterial', width: 100, defaultVisible: true },
    { key: 'addr', title: '地址', dataIndex: 'addr', width: 200, defaultVisible: true },
    { key: 'surfaceElev', title: '地表高程(m)', dataIndex: 'surfaceElev', width: 110, defaultVisible: true },
    { key: 'cod', title: '化学需氧量（毫克每升）', dataIndex: 'cod', width: 100, defaultVisible: true },
    { key: 'ammonia', title: '氨氮（毫克每升）', dataIndex: 'ammonia', width: 100, defaultVisible: true },
    { key: 'phosphorus', title: '总磷（毫克每升）', dataIndex: 'phosphorus', width: 100, defaultVisible: true },
    { key: 'ph', title: '酸碱度', dataIndex: 'ph', width: 80, defaultVisible: true },
    { key: 'totalNitrogen', title: '总氮（毫克每升）', dataIndex: 'totalNitrogen', width: 100, defaultVisible: true },
    { key: 'status', title: '状态', dataIndex: 'status', width: 100, defaultVisible: true, render: (v: string) => <StatusTag status={v} /> },
    { key: 'ownership', title: '权属单位', dataIndex: 'ownership', width: 150, defaultVisible: true },
    { key: 'operation', title: '操作', width: 300, defaultVisible: true }
  ];

  const [visibleColumns, setVisibleColumns] = useState<string[]>(() => getDefaultVisibleColumnKeys(allColumns));

  const parseOutletNums = (values: any) => {
    const n = (v: any) => (v === '' || v === undefined || v === null ? undefined : Number(v));
    return {
      ...values,
      x: n(values.x),
      y: n(values.y),
      cod: n(values.cod),
      ammonia: n(values.ammonia),
      phosphorus: n(values.phosphorus),
      ph: n(values.ph),
      totalNitrogen: n(values.totalNitrogen),
      bottomElev: n(values.bottomElev),
      surfaceElev: n(values.surfaceElev),
    };
  };

  const handleDelete = (id: string) => {
    setData(data.filter(item => item.id !== id));
    message.success('删除成功');
    setEditModalVisible(false);
  };

  const handleEdit = (record: any) => {
    setEditingRecord(record);
    setIsEditMode(true);
    editForm.setFieldsValue(record);
    setEditModalVisible(true);
  };

  const handleEditSave = () => {
    editForm.validateFields().then(values => {
      const merged = parseOutletNums(values);
      setData(data.map(item => item.id === editingRecord.id ? { ...item, ...merged } : item));
      message.success('保存成功');
      setEditModalVisible(false);
    });
  };

  const handleAdd = () => {
    addForm.resetFields();
    addForm.setFieldsValue({
      id: generateId('OF'),
      category: '雨水',
      type: '管道',
      status: '正常',
      ownership: '高新区管委会',
      flap: '1',
    });
    setAddModalVisible(true);
  };

  const handleAddSave = () => {
    addForm.validateFields().then(values => {
      const newRecord = parseOutletNums(values);
      setData([newRecord, ...data]);
      message.success('新增成功');
      setAddModalVisible(false);
    });
  };

  // 根据可见列生成实际列配置
  const columns = allColumns
    .filter(col => visibleColumns.includes(col.key) || col.key === 'operation')
    .sort((a, b) => {
      if (a.key === 'operation') return 1;
      if (b.key === 'operation') return -1;
      const indexA = visibleColumns.indexOf(a.key);
      const indexB = visibleColumns.indexOf(b.key);
      return indexA - indexB;
    })
    .map(col => {
      if (col.key === 'operation') {
        return {
          ...col,
          fixed: 'right' as const,
          render: (_: any, record: any) => (
            <Space size="small">
              <Button
                type="link"
                size="small"
                className="action-btn detail"
                icon={<EyeOutlined />}
                onClick={() =>
                  onDetail(`排口详情 - ${record.name}`, <OutletDetailContent record={record} />, 'min(1200px, 96vw)')
                }
              >
                详情
              </Button>
              <Tooltip title="打开详情并定位到实时监测">
                <Button
                  type="link"
                  size="small"
                  className="action-btn detail"
                  icon={<LineChartOutlined />}
                  onClick={() =>
                    onDetail(
                      `排口详情 - ${record.name}`,
                      <OutletDetailContent record={record} initialTabKey="monitor" />,
                      'min(1200px, 96vw)',
                    )
                  }
                >
                  实时监测
                </Button>
              </Tooltip>
              <Button type="link" size="small" className="action-btn edit" icon={<EditOutlined />} onClick={() => handleEdit(record)}>
                编辑
              </Button>
            </Space>
          )
        };
      }
      return col;
    });

  const facilityTableScrollX = getFacilityTableScrollX(
    allColumns.filter(col => visibleColumns.includes(col.key) || col.key === 'operation'),
  );

  return (
    <div className="facility-view">
      <Card
        title="排口管理"
        extra={
          <Space wrap size={[8, 8]} align="center">
            <Button icon={<DownloadOutlined />} className="export-btn">导出</Button>
            <Upload
              beforeUpload={() => {
                message.success('已导入（原型示意）');
                return false;
              }}
              showUploadList={false}
            >
              <Button icon={<UploadOutlined />}>导入</Button>
            </Upload>
            <ColumnManager columns={allColumns} visibleColumns={visibleColumns} onChange={setVisibleColumns} />
            <Button type="primary" icon={<PlusOutlined />} onClick={handleAdd} className="add-btn">新增</Button>
          </Space>
        }
      >
        <Row gutter={16} style={{ marginBottom: 16 }}>
          <Col span={6}><Search placeholder="搜索排口名称或编号" /></Col>
          <Col span={4}>
            <Select placeholder="类别" style={{ width: '100%' }}>
              <Select.Option value="">全部</Select.Option>
              <Select.Option value="雨水">雨水</Select.Option>
              <Select.Option value="污水">污水</Select.Option>
              <Select.Option value="合流">合流</Select.Option>
            </Select>
          </Col>
          <Col span={4}>
            <Select placeholder="排放状态" style={{ width: '100%' }}>
              <Select.Option value="">全部</Select.Option>
              <Select.Option value="正常">正常</Select.Option>
              <Select.Option value="超标">超标</Select.Option>
              <Select.Option value="达标">达标</Select.Option>
            </Select>
          </Col>
        </Row>
        <div className="facility-table-wrap">
          <Table
            dataSource={data}
            columns={columns}
            rowKey="id"
            scroll={{ x: facilityTableScrollX }}
            pagination={{ pageSize: 10 }}
          />
        </div>
      </Card>

      <Modal
        styles={formModalStyles}
        title="新增排口"
        open={addModalVisible}
        onOk={handleAddSave}
        onCancel={() => setAddModalVisible(false)}
        width={800}
        footer={
          <Space>
            <Button onClick={() => setAddModalVisible(false)}>取消</Button>
            <Button type="primary" onClick={handleAddSave}>保存</Button>
          </Space>
        }
      >
        <OutletFormContent form={addForm} />
      </Modal>

      <Modal
        styles={formModalStyles}
        title={isEditMode ? `编辑排口 - ${editingRecord?.name}` : `排口详情 - ${editingRecord?.name}`}
        open={editModalVisible}
        onOk={isEditMode ? handleEditSave : () => setEditModalVisible(false)}
        onCancel={() => setEditModalVisible(false)}
        width={isEditMode ? 800 : 'min(1200px, 96vw)'}
        footer={
          isEditMode ? (
            <Space>
              <Button danger onClick={() => handleDelete(editingRecord?.id)}>删除</Button>
              <Button onClick={() => setEditModalVisible(false)}>取消</Button>
              <Button type="primary" onClick={handleEditSave}>保存</Button>
            </Space>
          ) : (
            <Space>
              <Button
                type="primary"
                onClick={() => {
                  if (editingRecord) editForm.setFieldsValue(editingRecord);
                  setIsEditMode(true);
                }}
              >
                进入编辑
              </Button>
            </Space>
          )
        }
      >
        {editingRecord && (
          isEditMode ? (
            <OutletFormContent form={editForm} initialValues={editingRecord} isEdit />
          ) : (
            <OutletDetailContent record={editingRecord} />
          )
        )}
      </Modal>
    </div>
  );
};

// 污水处理厂视图
const PlantView = ({
  onDetail,
}: {
  onDetail: (title: string, content: React.ReactNode, modalWidth?: number | string) => void;
}) => {
  const [data, setData] = useState(plantData);
  const [editModalVisible, setEditModalVisible] = useState(false);
  const [addModalVisible, setAddModalVisible] = useState(false);
  const [editingRecord, setEditingRecord] = useState<any>(null);
  const [isEditMode, setIsEditMode] = useState(false);
  const [editForm] = Form.useForm();
  const [addForm] = Form.useForm();

  // 污水厂表格列（操作列右侧固定；厂站标识码 defaultVisible:false，其余默认展示）
  const allColumns: ColumnConfig[] = [
    { key: 'id', title: '厂站标识码', dataIndex: 'id', width: 150, defaultVisible: false },
    { key: 'xCoord', title: '坐标X', dataIndex: 'xCoord', width: 110, defaultVisible: true, render: (_: any, record: any) => (record.x * 10000).toFixed(3) },
    { key: 'yCoord', title: '坐标Y', dataIndex: 'yCoord', width: 110, defaultVisible: true, render: (_: any, record: any) => (record.y * 10000).toFixed(3) },
    { key: 'name', title: '污水厂名称', dataIndex: 'name', width: 180, defaultVisible: true },
    { key: 'addr', title: '污水厂地址', dataIndex: 'addr', width: 180, defaultVisible: true },
    { key: 'buildYear', title: '建设年份', dataIndex: 'buildYear', width: 90, defaultVisible: true },
    { key: 'area', title: '占地面积(hm²)', dataIndex: 'area', width: 120, defaultVisible: true, render: (v: number) => `${v} hm²` },
    { key: 'designCapa', title: '设计处理规模（万立方米每日）', dataIndex: 'designCapa', width: 140, defaultVisible: true, render: (v: number) => `${v} 万立方米每日` },
    { key: 'serviceArea', title: '服务范围', dataIndex: 'serviceArea', width: 130, defaultVisible: true },
    { key: 'process', title: '处理工艺', dataIndex: 'process', width: 130, defaultVisible: true },
    { key: 'servicePop', title: '服务人口(万人)', dataIndex: 'servicePop', width: 120, defaultVisible: true, render: (v: number) => `${v} 万人` },
    { key: 'connPollutionNum', title: '纳管污染源数', dataIndex: 'connPollutionNum', width: 110, defaultVisible: true },
    { key: 'inQuality', title: '进水水质目标', dataIndex: 'inQuality', width: 130, defaultVisible: true },
    { key: 'outQuality', title: '出水水质目标', dataIndex: 'outQuality', width: 130, defaultVisible: true },
    { key: 'dataSource', title: '数据来源', dataIndex: 'dataSource', width: 100, defaultVisible: true },
    { key: 'ownership', title: '权属单位', dataIndex: 'ownership', width: 150, defaultVisible: true },
    { key: 'reportUnit', title: '填报单位', dataIndex: 'reportUnit', width: 150, defaultVisible: true },
    { key: 'createTime', title: '记录日期', dataIndex: 'createTime', width: 120, defaultVisible: true },
    { key: 'updateTime', title: '修改日期', dataIndex: 'updateTime', width: 120, defaultVisible: true },
    { key: 'operation', title: '操作', width: 300, defaultVisible: true }
  ];

  const [visibleColumns, setVisibleColumns] = useState<string[]>(() => getDefaultVisibleColumnKeys(allColumns));

  const parsePlantNums = (values: any) => {
    const n = (v: any) => (v === '' || v === undefined || v === null ? undefined : Number(v));
    return {
      ...values,
      x: n(values.x),
      y: n(values.y),
      area: n(values.area),
      designCapa: n(values.designCapa),
      servicePop: n(values.servicePop),
      connPollutionNum: n(values.connPollutionNum),
    };
  };

  const handleDelete = (id: string) => {
    setData(data.filter(item => item.id !== id));
    message.success('删除成功');
    setEditModalVisible(false);
  };

  const handleEdit = (record: any) => {
    setEditingRecord(record);
    setIsEditMode(true);
    editForm.setFieldsValue(record);
    setEditModalVisible(true);
  };

  const handleEditSave = () => {
    editForm.validateFields().then(values => {
      const merged = parsePlantNums(values);
      setData(data.map(item => item.id === editingRecord.id ? { ...item, ...merged } : item));
      message.success('保存成功');
      setEditModalVisible(false);
    });
  };

  const handleAdd = () => {
    addForm.resetFields();
    addForm.setFieldsValue({
      id: generateId('WWTP'),
      systemId: 'SYS001',
      buildYear: String(new Date().getFullYear()),
      status: '1',
      dataSource: '竣工图',
      createTime: getCurrentDate(),
      updateTime: getCurrentDate(),
      serviceArea: '高新区全域',
    });
    setAddModalVisible(true);
  };

  const handleAddSave = () => {
    addForm.validateFields().then(values => {
      const newRecord = parsePlantNums(values);
      setData([newRecord, ...data]);
      message.success('新增成功');
      setAddModalVisible(false);
    });
  };

  // 根据可见列生成实际列配置
  const columns = allColumns
    .filter(col => visibleColumns.includes(col.key) || col.key === 'operation')
    .sort((a, b) => {
      if (a.key === 'operation') return 1;
      if (b.key === 'operation') return -1;
      const indexA = visibleColumns.indexOf(a.key);
      const indexB = visibleColumns.indexOf(b.key);
      return indexA - indexB;
    })
    .map(col => {
      if (col.key === 'operation') {
        return {
          ...col,
          fixed: 'right' as const,
          render: (_: any, record: any) => (
            <Space size="small">
              <Button
                type="link"
                size="small"
                className="action-btn detail"
                icon={<EyeOutlined />}
                onClick={() =>
                  onDetail(`污水厂详情 - ${record.name}`, <PlantDetailContent record={record} />, 'min(1200px, 96vw)')
                }
              >
                详情
              </Button>
              <Tooltip title="打开详情并定位到实时监测">
                <Button
                  type="link"
                  size="small"
                  className="action-btn detail"
                  icon={<LineChartOutlined />}
                  onClick={() =>
                    onDetail(
                      `污水厂详情 - ${record.name}`,
                      <PlantDetailContent record={record} initialTabKey="monitor" />,
                      'min(1200px, 96vw)',
                    )
                  }
                >
                  实时监测
                </Button>
              </Tooltip>
              <Button type="link" size="small" className="action-btn edit" icon={<EditOutlined />} onClick={() => handleEdit(record)}>
                编辑
              </Button>
            </Space>
          )
        };
      }
      return col;
    });

  const facilityTableScrollX = getFacilityTableScrollX(
    allColumns.filter(col => visibleColumns.includes(col.key) || col.key === 'operation'),
  );

  return (
    <div className="facility-view">
      <Card
        title="污水处理厂管理"
        extra={
          <Space wrap size={[8, 8]} align="center">
            <Button icon={<DownloadOutlined />} className="export-btn">导出</Button>
            <Upload
              beforeUpload={() => {
                message.success('已导入（原型示意）');
                return false;
              }}
              showUploadList={false}
            >
              <Button icon={<UploadOutlined />}>导入</Button>
            </Upload>
            <ColumnManager columns={allColumns} visibleColumns={visibleColumns} onChange={setVisibleColumns} />
            <Button type="primary" icon={<PlusOutlined />} onClick={handleAdd} className="add-btn">新增</Button>
          </Space>
        }
      >
        <div className="facility-table-wrap">
          <Table
            dataSource={data}
            columns={columns}
            rowKey="id"
            scroll={{ x: facilityTableScrollX }}
            pagination={{ pageSize: 10 }}
          />
        </div>
      </Card>

      <Modal
        styles={formModalStyles}
        title="新增污水处理厂"
        open={addModalVisible}
        onOk={handleAddSave}
        onCancel={() => setAddModalVisible(false)}
        width={800}
        footer={
          <Space>
            <Button onClick={() => setAddModalVisible(false)}>取消</Button>
            <Button type="primary" onClick={handleAddSave}>保存</Button>
          </Space>
        }
      >
        <PlantFormContent form={addForm} />
      </Modal>

      <Modal
        styles={formModalStyles}
        title={isEditMode ? `编辑厂站 - ${editingRecord?.name}` : `污水厂详情 - ${editingRecord?.name}`}
        open={editModalVisible}
        onOk={isEditMode ? handleEditSave : () => setEditModalVisible(false)}
        onCancel={() => setEditModalVisible(false)}
        width={isEditMode ? 800 : 'min(1200px, 96vw)'}
        footer={
          isEditMode ? (
            <Space>
              <Button danger onClick={() => handleDelete(editingRecord?.id)}>删除</Button>
              <Button onClick={() => setEditModalVisible(false)}>取消</Button>
              <Button type="primary" onClick={handleEditSave}>保存</Button>
            </Space>
          ) : (
            <Space>
              <Button
                type="primary"
                onClick={() => {
                  if (editingRecord) editForm.setFieldsValue(editingRecord);
                  setIsEditMode(true);
                }}
              >
                进入编辑
              </Button>
            </Space>
          )
        }
      >
        {editingRecord && (
          isEditMode ? (
            <PlantFormContent form={editForm} initialValues={editingRecord} isEdit />
          ) : (
            <PlantDetailContent record={editingRecord} />
          )
        )}
      </Modal>
    </div>
  );
};


// ==================== 主应用组件 ====================

const Component = () => {
  const [currentView, setCurrentView] = useState<ViewState>('facilities-pipe-node');
  /** 列表「详情」：与生态整治项目管理「项目详情」一致的居中弹窗（管点详情含运行监控时需加宽） */
  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [detailModalTitle, setDetailModalTitle] = useState('');
  const [detailModalContent, setDetailModalContent] = useState<React.ReactNode>(null);
  const [detailModalWidth, setDetailModalWidth] = useState<number | string>(800);
  /** 每次打开递增，避免同标题不同入口（如「详情」与「实时监测」）时子树复用导致 Tab 停留在上次 */
  const [detailModalKey, setDetailModalKey] = useState(0);

  const openDetailModal = (title: string, content: React.ReactNode, modalWidth: number | string = 800) => {
    setDetailModalKey((k) => k + 1);
    setDetailModalTitle(title);
    setDetailModalContent(content);
    setDetailModalWidth(modalWidth);
    setDetailModalOpen(true);
  };

  const closeDetailModal = () => {
    setDetailModalOpen(false);
    setDetailModalWidth(800);
  };

  // 渲染当前视图（仅设施管理五类页面）
  const renderView = () => {
    switch (currentView) {
      case 'facilities-pipe-node':
        return <PipeNodeView onDetail={openDetailModal} />;
      case 'facilities-pipe-line':
        return <PipeLineView onDetail={openDetailModal} />;
      case 'facilities-pump':
        return <PumpStationView onDetail={openDetailModal} />;
      case 'facilities-outlet':
        return <OutletView onDetail={openDetailModal} />;
      case 'facilities-plant':
        return <PlantView onDetail={openDetailModal} />;
      default:
        return <PipeNodeView onDetail={openDetailModal} />;
    }
  };

  // 面包屑：设施管理 / …（与原一张图侧栏路径一致）
  const getBreadcrumbPath = (): string => {
    const base = '设施管理';
    for (const menu of facilitySidebarMenus) {
      if (menu.key === currentView) {
        return `${base} / ${menu.label}`;
      }
      if (menu.children) {
        for (const child of menu.children) {
          if (child.key === currentView) {
            return `${base} / ${menu.label} / ${child.label}`;
          }
        }
      }
    }
    return base;
  };

  // 左侧边栏（无顶部一级菜单时保留模块内导航）
  const SidebarMenu: React.FC = () => {
    const sidebarMenus = facilitySidebarMenus;

    const [expandedKeys, setExpandedKeys] = useState<string[]>(() => {
      const defaultExpanded: string[] = [];
      for (const menu of sidebarMenus) {
        if (menu.children) {
          for (const child of menu.children) {
            if (child.key === currentView) {
              defaultExpanded.push(menu.key);
              break;
            }
          }
        }
      }
      return defaultExpanded;
    });

    const toggleExpand = (key: string) => {
      setExpandedKeys(prev =>
        prev.includes(key) ? prev.filter(k => k !== key) : [...prev, key]
      );
    };

    return (
      <div className="sidebar-menu">
        <div className="sidebar-menu-title">设施管理</div>
        <div className="sidebar-menu-list">
          {sidebarMenus.map(menu => {
            const hasChildren = menu.children && menu.children.length > 0;
            const isExpanded = expandedKeys.includes(menu.key);
            const isActive =
              currentView === menu.key ||
              (hasChildren && menu.children!.some(c => c.key === currentView));

            return (
              <div key={menu.key} className="sidebar-menu-item-wrapper">
                <div
                  className={`sidebar-menu-item ${isActive ? 'active' : ''}`}
                  onClick={() => {
                    if (hasChildren) {
                      toggleExpand(menu.key);
                    } else {
                      setCurrentView(menu.key as ViewState);
                    }
                  }}
                >
                  <span className="sidebar-menu-icon">{menu.icon}</span>
                  <span className="sidebar-menu-label">{menu.label}</span>
                  {hasChildren && (
                    <span className={`sidebar-menu-arrow ${isExpanded ? 'expanded' : ''}`}>
                      <DownOutlined />
                    </span>
                  )}
                </div>
                {hasChildren && isExpanded && (
                  <div className="sidebar-submenu">
                    {menu.children!.map(child => (
                      <div
                        key={child.key}
                        className={`sidebar-submenu-item ${currentView === child.key ? 'active' : ''}`}
                        onClick={() => setCurrentView(child.key as ViewState)}
                      >
                        {child.label}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <Layout className="water-env-dashboard facility-mgmt-standalone">
      <div className="main-layout with-sidebar">
        <SidebarMenu />
        <div className="main-content-area">
          <div className="breadcrumb-bar">
            <span className="breadcrumb-current">{getBreadcrumbPath()}</span>
          </div>
          <Content className="main-content with-sidebar">
            <div className="content-wrapper">{renderView()}</div>
          </Content>
        </div>
      </div>

      <Modal
        styles={detailModalStyles}
        title={detailModalTitle}
        open={detailModalOpen}
        onCancel={closeDetailModal}
        footer={null}
        width={detailModalWidth}
        destroyOnClose
      >
        <div key={detailModalKey}>{detailModalContent}</div>
      </Modal>
    </Layout>
  );
};

export default Component;

// 应用挂载
const container = document.getElementById('root');
if (container) {
  const root = createRoot(container);
  root.render(<Component />);
}
