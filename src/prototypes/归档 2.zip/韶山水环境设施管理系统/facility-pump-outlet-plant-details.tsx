/**
 * 泵站 / 排口 / 污水厂详情内容（与设施管理 `index.tsx` 内原实现一致，供列表与综合态势地图等共用）
 */
import React from 'react';
import { Badge, Descriptions } from 'antd';
import type { DescriptionsProps } from 'antd';
import { DetailTabsIfMultiple } from '../shared/detailTabsIfMultiple';
import {
  PumpStationMonitoringTabContent,
  OutletMonitoringTabContent,
  PlantMonitoringTabContent,
} from './pipe-node-monitoring';
import {
  PumpStationVideoTabContent,
  OutletVideoTabContent,
  PlantVideoTabContent,
} from './facility-video-monitoring';

/** 详情字段项 */
export interface DetailTableItem {
  label: string;
  value: React.ReactNode;
  span?: 1 | 2 | 3 | 4;
}

interface DetailCardProps {
  title: string;
  items: DetailTableItem[];
}

function renderDetailFieldValue(value: React.ReactNode): React.ReactNode {
  if (value == null || value === '') {
    return <span className="detail-value-empty">—</span>;
  }
  if (typeof value === 'string' && (value.trim() === '' || value === '-' || value === '—')) {
    return <span className="detail-value-empty">—</span>;
  }
  return value;
}

function mapDetailItemSpan(span: number | undefined): number {
  const s = span ?? 1;
  return s >= 2 ? 2 : 1;
}

const DetailCard: React.FC<DetailCardProps> = ({ title, items }) => {
  const descItems: NonNullable<DescriptionsProps['items']> = items.map((item, idx) => ({
    key: `${item.label}-${idx}`,
    label: item.label,
    children: renderDetailFieldValue(item.value),
    span: mapDetailItemSpan(item.span),
  }));

  return (
    <div className="detail-section">
      <div className="detail-section-title">{title}</div>
      <div className="detail-section-content">
        <Descriptions bordered column={2} size="small" items={descItems} />
      </div>
    </div>
  );
};

interface DetailTab {
  key: string;
  label: string;
  children: React.ReactNode;
}

interface XiangtanDetailViewProps {
  title?: string;
  subtitle?: string;
  tabs: DetailTab[];
  extra?: React.ReactNode;
  defaultActiveKey?: string;
}

const XiangtanDetailView: React.FC<XiangtanDetailViewProps> = ({ tabs, defaultActiveKey }) => {
  const resolvedKey =
    defaultActiveKey && tabs.some(t => t.key === defaultActiveKey) ? defaultActiveKey : tabs[0]?.key;
  return (
    <DetailTabsIfMultiple
      className="facility-detail-tabs facility-mgmt-detail-tabs"
      size="small"
      style={{ marginTop: 8 }}
      defaultActiveKey={resolvedKey}
      items={tabs}
    />
  );
};

const StatusTag = ({ status }: { status: string }) => {
  const config: Record<string, { color: string; text: string }> = {
    '1': { color: 'success', text: '正常' },
    '2': { color: 'warning', text: '检修' },
    '3': { color: 'error', text: '故障' },
    '4': { color: 'default', text: '在建' },
    normal: { color: 'success', text: '正常' },
    warning: { color: 'warning', text: '预警' },
    error: { color: 'error', text: '超标' },
    达标: { color: 'success', text: '达标' },
    超标: { color: 'error', text: '超标' },
  };
  const cfg = config[status] || { color: 'default', text: status };
  return <Badge status={cfg.color as any} text={cfg.text} />;
};

export const PumpDetailContent = ({
  record,
  isEdit: _isEdit,
  initialTabKey,
}: {
  record: Record<string, unknown>;
  isEdit?: boolean;
  initialTabKey?: string;
}) => {
  const basicItems: DetailTableItem[] = [
    { label: '泵站标识码', value: record.id as string },
    { label: '排水系统标识码', value: (record.systemId as string) || 'SYS001' },
    { label: '泵站名称', value: record.name as string },
    { label: '泵站地址', value: record.addr as string },
    { label: '泵站类别', value: record.category as string },
    { label: '泵台数', value: record.num != null ? `${record.num} 台` : undefined },
    { label: '设计雨水排水能力', value: record.stormCapa != null ? `${record.stormCapa} 立方米每秒` : '-' },
    { label: '设计污水排水能力', value: record.wwCapa != null ? `${record.wwCapa} 立方米每秒` : '-' },
    { label: '前池长', value: record.forebayLen != null ? `${record.forebayLen} m` : '12.5 m' },
    { label: '前池宽', value: record.forebayWid != null ? `${record.forebayWid} m` : '8.2 m' },
    { label: '前池深', value: record.forebayDep != null ? `${record.forebayDep} m` : '4.5 m' },
    { label: '进水池最高水位', value: record.inPoolMaxLev != null ? `${record.inPoolMaxLev} m` : '15.8 m' },
    { label: '进水池常水位', value: record.inPoolNorLev != null ? `${record.inPoolNorLev} m` : '14.2 m' },
    { label: '进水池最低水位', value: record.inPoolMinLev != null ? `${record.inPoolMinLev} m` : '12.5 m' },
    { label: '出水池设计水位', value: record.outPoolDesLev != null ? `${record.outPoolDesLev} m` : '18.5 m' },
    { label: '出水池最高水位', value: record.outPoolMaxLev != null ? `${record.outPoolMaxLev} m` : '19.2 m' },
    { label: '出水池最低水位', value: record.outPoolMinLev != null ? `${record.outPoolMinLev} m` : '17.8 m' },
    { label: '技术资料文件', value: (record.dataListId as string) || 'TS2024001' },
    { label: '数据来源', value: '竣工图' },
    { label: '记录建立日期', value: (record.createTime as string) || '2024-03-20' },
    { label: '填报单位', value: (record.reportUnit as string) || (record.ownership as string) },
    { label: '权属单位', value: record.ownership as string },
  ];

  const tabs: DetailTab[] = [
    {
      key: 'basic',
      label: '基本信息',
      children: <DetailCard title="泵站基础信息" items={basicItems} />,
    },
    {
      key: 'monitor',
      label: '实时监测',
      children: <PumpStationMonitoringTabContent record={record} />,
    },
    {
      key: 'video',
      label: '视频监控',
      children: <PumpStationVideoTabContent record={record} />,
    },
  ];

  return (
    <XiangtanDetailView title="泵站详情" subtitle={record.name as string} tabs={tabs} defaultActiveKey={initialTabKey} />
  );
};

export const OutletDetailContent = ({
  record,
  isEdit: _isEdit,
  initialTabKey,
}: {
  record: Record<string, unknown>;
  isEdit?: boolean;
  initialTabKey?: string;
}) => {
  const basicItems: DetailTableItem[] = [
    { label: '排放口标识码', value: record.id as string },
    { label: '入河排污口名称', value: (record.pwkName as string) || (record.name as string) },
    { label: '入河排污口编码', value: (record.pwkCode as string) || String(record.id).replace('OF', 'PWK') },
    { label: '一级分类', value: (record.pwkYjfl as string) || '城镇雨洪' },
    { label: '二级分类', value: (record.pwkEjfl as string) || '雨水排口' },
    { label: '审批登记备案', value: (record.spdjbaqk as string) || '登记' },
    { label: '所在行政区域', value: '韶山市高新区' },
    { label: '经度', value: `${Number(record.x).toFixed(6)}°E` },
    { label: '纬度', value: `${Number(record.y).toFixed(6)}°N` },
    { label: '排污水系', value: '韶河' },
    { label: '受纳水体', value: '韶河中游' },
    { label: '排放方式', value: (record.pffs as string) || '连续' },
    { label: '类别', value: record.category as string },
    { label: '类型', value: record.type as string },
    { label: '是否有拍门', value: record.flap === '1' ? '有' : '无' },
    { label: '底部高程', value: record.bottomElev != null ? `${record.bottomElev} m` : '12.5 m' },
    { label: '出流形式', value: (record.outfallType as string) || '自由' },
    { label: '拍门材质', value: (record.flapMaterial as string) || '铸铁' },
    { label: '排放口地址', value: (record.addr as string) || (record.name as string) },
    { label: '地表高程', value: record.surfaceElev != null ? `${record.surfaceElev} 米` : '15.2 米' },
    { label: '状态', value: <StatusTag status={String(record.status)} /> },
    { label: '权属单位', value: record.ownership as string },
  ];

  const tabs: DetailTab[] = [
    {
      key: 'basic',
      label: '基本信息',
      children: <DetailCard title="排口基础信息" items={basicItems} />,
    },
    {
      key: 'monitor',
      label: '实时监测',
      children: <OutletMonitoringTabContent record={record} />,
    },
    {
      key: 'video',
      label: '视频监控',
      children: <OutletVideoTabContent record={record} />,
    },
  ];

  return (
    <XiangtanDetailView title="排口详情" subtitle={record.name as string} tabs={tabs} defaultActiveKey={initialTabKey} />
  );
};

export const PlantDetailContent = ({
  record,
  isEdit: _isEdit,
  initialTabKey,
}: {
  record: Record<string, unknown>;
  isEdit?: boolean;
  initialTabKey?: string;
}) => {
  const basicItems: DetailTableItem[] = [
    { label: '污水处理厂标识码', value: record.id as string },
    { label: '排水系统标识码', value: (record.systemId as string) || 'SYS001' },
    { label: '坐标X', value: (record.xCoord as string) || (Number(record.x) * 10000).toFixed(3) },
    { label: '坐标Y', value: (record.yCoord as string) || (Number(record.y) * 10000).toFixed(3) },
    { label: '污水厂名称', value: record.name as string },
    { label: '污水厂地址', value: (record.addr as string) || '韶山市高新区工业园' },
    { label: '建设年份', value: record.buildYear as string },
    { label: '占地面积', value: record.area != null ? `${record.area} hm²` : undefined },
    { label: '设计处理规模', value: record.designCapa != null ? `${record.designCapa} 万立方米每日` : undefined },
    { label: '服务范围', value: (record.serviceArea as string) || '高新区全域' },
    { label: '处理工艺', value: record.process as string },
    { label: '服务人口', value: record.servicePop != null ? `${record.servicePop} 万人` : undefined },
    { label: '纳管污染源数量', value: record.connPollutionNum != null ? `${record.connPollutionNum} 个` : '15 个' },
    { label: '进水水质目标', value: record.inQuality as string },
    { label: '出水水质目标', value: record.outQuality as string },
    { label: '数据来源', value: '竣工图' },
    { label: '权属单位', value: (record.ownership as string) || '高新区管委会' },
    { label: '填报单位', value: (record.reportUnit as string) || '高新区管委会' },
    { label: '记录建立日期', value: (record.createTime as string) || '2024-01-15' },
    { label: '最后修改日期', value: (record.updateTime as string) || '2024-04-07' },
  ];

  const facilityItems: DetailTableItem[] = [
    { label: '粗格栅', value: 'GSHZ-1200 / 栅隙20mm' },
    { label: '细格栅', value: 'GSHZ-800 / 栅隙5mm' },
    { label: '曝气沉砂池', value: '曝气沉砂工艺段 / 容积约 2000 立方米' },
    { label: '厌氧缺氧好氧生化池', value: '厌氧缺氧好氧工艺段 / 容积约 5000 立方米' },
    { label: '二沉池', value: '二沉工艺段 / 容积约 3000 立方米' },
    { label: '紫外线消毒池', value: '紫外线消毒工艺段 / 约 500 立方米每小时' },
  ];

  const tabs: DetailTab[] = [
    {
      key: 'basic',
      label: '基本信息',
      children: <DetailCard title="污水厂基础信息" items={basicItems} />,
    },
    {
      key: 'facility',
      label: '关键设施',
      children: <DetailCard title="关键处理设施清单" items={facilityItems} />,
    },
    {
      key: 'monitor',
      label: '实时监测',
      children: <PlantMonitoringTabContent record={record} />,
    },
    {
      key: 'video',
      label: '视频监控',
      children: <PlantVideoTabContent record={record} />,
    },
  ];

  return (
    <XiangtanDetailView title="污水厂详情" subtitle={record.name as string} tabs={tabs} defaultActiveKey={initialTabKey} />
  );
};
