/**
 * 设施详情 —「实时监测」标签页（与泵站同一套布局：设备横滑卡片、物联网元数据、指标大卡、按日期三曲线对比；占位数据）。
 * 支持泵站 / 排口 / 污水厂三种场景（文案与元数据区分，交互与指标与泵站保持一致）。
 */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Row,
  Col,
  Tag,
  Space,
  Typography,
  Button,
  DatePicker,
  Badge,
  Table,
  Tooltip,
  Modal,
  Form,
  Empty,
  Alert,
  message,
  Select,
  Card,
} from 'antd';
import {
  WifiOutlined,
  LineChartOutlined,
  BarChartOutlined,
  TableOutlined,
  ThunderboltOutlined,
  QuestionCircleOutlined,
  ApiOutlined,
} from '@ant-design/icons';
import * as echarts from 'echarts';

const { Text, Title } = Typography;
const { RangePicker } = DatePicker;

const EQUIP_TONES = ['pink', 'orange', 'yellow', 'blue', 'green'] as const;

/** 设备链路状态：影响卡片内在线/电量标签与下方监测项配色（占位逻辑） */
export type DeviceLinkStatus = 'running' | 'stopped' | 'abnormal';

export interface MockMonitorDevice {
  key: string;
  name: string;
  deviceId: string;
  time: string;
  tone: (typeof EQUIP_TONES)[number];
  linkStatus: DeviceLinkStatus;
  /** 电量百分比，离线设备可为 null */
  batteryPct: number | null;
  /** 为 false 时指标/曲线/表格均为空占位，用于演示无数据态 */
  hasData: boolean;
}

const MOCK_PUMP_DEVICES = (facilityId: string): MockMonitorDevice[] => {
  const id = facilityId.replace(/\D/g, '').slice(-6) || '000001';
  const main: MockMonitorDevice[] = [1, 2, 3, 4, 5].map((n, i) => {
    const linkCycle: DeviceLinkStatus[] = ['running', 'running', 'stopped', 'abnormal', 'running'];
    const batteries: (number | null)[] = [49, 62, null, 11, 88];
    return {
      key: String(n),
      name: `${n}#泵`,
      deviceId: `DEV-${id}-${n}`,
      time: '2025/10/10 11:50:00',
      tone: EQUIP_TONES[i % EQUIP_TONES.length],
      linkStatus: linkCycle[i],
      batteryPct: batteries[i],
      hasData: true,
    };
  });
  // 若干条无监测数据的空占位，便于验收空态样式
  const empty: MockMonitorDevice[] = [
    {
      key: '6',
      name: '备用接入（空占位）',
      deviceId: `DEV-${id}-6`,
      time: '—',
      tone: 'blue',
      linkStatus: 'stopped',
      batteryPct: null,
      hasData: false,
    },
    {
      key: '7',
      name: '未入网终端（空占位）',
      deviceId: `DEV-${id}-7`,
      time: '—',
      tone: 'green',
      linkStatus: 'stopped',
      batteryPct: null,
      hasData: false,
    },
  ];
  return [...main, ...empty];
};

/** 按设备+测点确定性分配通道状态：绿=运行、灰=停止、红=异常 */
/** 台账可选字段：已关联的物联设备 key 列表；未配置时原型默认关联全部示例设备 */
function getInitialLinkedKeys(record: Record<string, unknown>, pool: MockMonitorDevice[]): string[] {
  const raw = record.iotLinkedDeviceKeys;
  if (Array.isArray(raw)) {
    const keys = (raw as unknown[]).filter((x): x is string => typeof x === 'string');
    return keys.filter((k) => pool.some((p) => p.key === k));
  }
  return pool.map((p) => p.key);
}

/** 按已选 key 顺序还原设备行（与生态整治「河长责任区域 · 责任段」已选表一致） */
function getMonitorDevicesByKeys(pool: MockMonitorDevice[], keys: string[] | undefined): MockMonitorDevice[] {
  if (!keys?.length) return [];
  const map = new Map(pool.map((d) => [d.key, d]));
  return keys.map((k) => map.get(k)).filter(Boolean) as MockMonitorDevice[];
}

function getMetricChannelStatus(deviceKey: string, metricKey: string): DeviceLinkStatus {
  const s = deviceKey + metricKey;
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = (h + s.charCodeAt(i) * (i + 1)) % 997;
  }
  const t = h % 10;
  if (t < 5) return 'running';
  if (t < 8) return 'stopped';
  return 'abnormal';
}

const PUMP_METRICS: { key: string; label: string; unit: string; primary?: boolean }[] = [
  { key: 'inP', label: '总进水压力', unit: 'Mpa', primary: true },
  { key: 'preP', label: '泵前压力', unit: 'Mpa' },
  { key: 'postP', label: '泵后压力', unit: 'Mpa' },
  { key: 'flow', label: '瞬时流量', unit: 'm³/h' },
  { key: 'tank', label: '水箱液位', unit: 'm' },
];

function buildSingleSeries(metricKey: string) {
  const base =
    metricKey === 'tank'
      ? 1.15
      : metricKey === 'inP' || metricKey === 'preP' || metricKey === 'postP'
        ? 0.35
        : metricKey === 'flow'
          ? 18
          : 0.35;
  const hours = Array.from({ length: 24 }, (_, i) => `${String(i).padStart(2, '0')}:00`);
  const data = hours.map((_, i) => {
    const noise = Math.sin(i / 3) * (metricKey === 'tank' ? 0.08 : 2) + Math.cos(i / 5);
    return Math.round((base + noise) * 10) / 10;
  });
  return { hours, data };
}

function buildComparisonSeries(metricKey: string) {
  const { hours, data: today } = buildSingleSeries(metricKey);
  const yesterday = today.map((v, i) => Math.round((v * (0.92 + 0.06 * Math.sin(i / 4))) * 10) / 10);
  const lastYear = today.map((v, i) => Math.round((v * (0.88 + 0.08 * Math.cos(i / 3))) * 10) / 10);
  return {
    hours,
    series: [
      { name: '今日 (2025-10-10)', data: today, color: '#1677ff' },
      { name: '昨日 (2025-10-09)', data: yesterday, color: '#595959' },
      { name: '去年同期 (2024-10-10)', data: lastYear, color: '#73d13d' },
    ],
  };
}

function formatMetricValue(metricKey: string, raw: number): string {
  switch (metricKey) {
    case 'tank':
      return `${raw.toFixed(2)}`;
    case 'inP':
    case 'preP':
    case 'postP':
      return raw.toFixed(3);
    case 'flow':
      return raw.toFixed(1);
    default:
      return String(raw);
  }
}

function metricDisplayFor(metricKey: string, hasData: boolean) {
  if (!hasData) return '—';
  const { data } = buildSingleSeries(metricKey);
  const lv = data[data.length - 1];
  const m = PUMP_METRICS.find((x) => x.key === metricKey);
  const unit = m?.unit ?? '';
  return `${formatMetricValue(metricKey, lv)}${unit ? unit : ''}`;
}

/** 与泵站共用同一套监测布局，仅标题与物联网元数据随场景变化 */
export type FacilityMonitoringScene = 'pump' | 'outlet' | 'plant';

/** 卡片内：在线/电量，随设备状态变化 */
function DeviceCardStatusTags({ device }: { device: MockMonitorDevice }) {
  if (device.linkStatus === 'running') {
    return (
      <Space size={4} wrap className="facility-monitoring-equip-tags-inner">
        <Tag color="success" icon={<WifiOutlined />} style={{ margin: 0 }}>
          在线
        </Tag>
        <Tag icon={<ThunderboltOutlined />} color="processing" style={{ margin: 0 }}>
          电量 {device.batteryPct ?? 0}%
        </Tag>
      </Space>
    );
  }
  if (device.linkStatus === 'stopped') {
    return (
      <Space size={4} wrap className="facility-monitoring-equip-tags-inner">
        <Tag style={{ margin: 0, color: '#8c8c8c', borderColor: '#d9d9d9' }}>离线</Tag>
        <Tag style={{ margin: 0, color: '#8c8c8c', borderColor: '#d9d9d9' }}>电量 --</Tag>
      </Space>
    );
  }
  return (
    <Space size={4} wrap className="facility-monitoring-equip-tags-inner">
      <Tag color="error" style={{ margin: 0 }}>
        异常
      </Tag>
      <Tag icon={<ThunderboltOutlined />} color="warning" style={{ margin: 0 }}>
        电量 {device.batteryPct ?? 0}%
      </Tag>
    </Space>
  );
}

const SCENE_META: Record<
  FacilityMonitoringScene,
  { sectionPrefix: string; product: string; industry: string; installLabel: string; pkPrefix: string; deviceNameSuffix: string }
> = {
  pump: {
    sectionPrefix: '二次泵站',
    product: '二次供水智能网关',
    industry: '供水',
    installLabel: '泵房控制柜',
    pkPrefix: 'PK-PS-',
    deviceNameSuffix: '主控',
  },
  outlet: {
    sectionPrefix: '排口',
    product: '水质在线监测终端',
    industry: '城镇排水',
    installLabel: '排放口现场',
    pkPrefix: 'PK-OF-',
    deviceNameSuffix: '监测主控',
  },
  plant: {
    sectionPrefix: '污水厂',
    product: '污水厂智能物联网网关',
    industry: '污水处理',
    installLabel: '中控室',
    pkPrefix: 'PK-WW-',
    deviceNameSuffix: '监测主控',
  },
};

const FacilityRealtimePanel: React.FC<{
  record: Record<string, unknown>;
  scene: FacilityMonitoringScene;
}> = ({ record, scene }) => {
  const nodeId = String(record.id ?? '');
  const sceneCfg = SCENE_META[scene];

  /** 物联网平台可选设备池（原型固定 5 台，对接后由接口拉取） */
  const allDevicesPool = useMemo(() => MOCK_PUMP_DEVICES(nodeId), [nodeId]);
  const metrics = PUMP_METRICS;

  const [linkedKeys, setLinkedKeys] = useState<string[]>(() => getInitialLinkedKeys(record, MOCK_PUMP_DEVICES(nodeId)));
  const [linkModalOpen, setLinkModalOpen] = useState(false);
  const [linkForm] = Form.useForm<{ keys: string[] }>();

  /** 切换设施（nodeId 变化）时从台账字段或默认全选恢复关联列表 */
  useEffect(() => {
    setLinkedKeys(getInitialLinkedKeys(record, allDevicesPool));
  }, [nodeId, allDevicesPool]);

  const linkedDevices = useMemo(() => {
    const map = new Map(allDevicesPool.map((d) => [d.key, d]));
    return linkedKeys.map((k) => map.get(k)).filter(Boolean) as MockMonitorDevice[];
  }, [allDevicesPool, linkedKeys]);

  const [activeDevKey, setActiveDevKey] = useState(linkedDevices[0]?.key ?? '1');
  const [metricKey, setMetricKey] = useState(metrics[0]?.key ?? 'inP');
  const [dateMode, setDateMode] = useState<'date' | 'range'>('date');
  const [chartKind, setChartKind] = useState<'line' | 'bar' | 'table'>('line');
  const chartRef = useRef<HTMLDivElement>(null);
  const chartInst = useRef<echarts.ECharts | null>(null);

  useEffect(() => {
    if (linkedDevices.length === 0) return;
    if (!linkedDevices.some((d) => d.key === activeDevKey)) {
      setActiveDevKey(linkedDevices[0].key);
    }
  }, [linkedDevices, activeDevKey]);

  const sectionPrefix = sceneCfg.sectionPrefix;

  const activeDevice = useMemo(
    () => linkedDevices.find((d) => d.key === activeDevKey) ?? linkedDevices[0],
    [linkedDevices, activeDevKey],
  );

  const openLinkModal = useCallback(() => {
    linkForm.setFieldsValue({ keys: linkedKeys });
    setLinkModalOpen(true);
  }, [linkForm, linkedKeys]);

  const handleLinkModalOk = useCallback(() => {
    linkForm.validateFields().then((values) => {
      const next = values.keys ?? [];
      setLinkedKeys(next);
      setLinkModalOpen(false);
      message.success('物联设备关联已更新（原型仅本地状态，对接后写入台账/平台）');
    });
  }, [linkForm]);

  const metaRows = useMemo(() => {
    const defaultName = scene === 'pump' ? '泵站' : scene === 'outlet' ? '排口' : '污水厂';
    const dev = activeDevice;
    const devLabel = dev ? `${dev.name}${sceneCfg.deviceNameSuffix}` : `${String(record.name ?? defaultName)}${sceneCfg.deviceNameSuffix}`;
    const noData = dev && !dev.hasData;
    return [
      { label: '设备编码', value: noData ? '—' : dev?.deviceId ?? `IOT-${nodeId}` },
      {
        label: '设备名称',
        value: devLabel,
      },
      { label: '设备密钥', value: '••••••••••••（脱敏）' },
      { label: '所属产品', value: sceneCfg.product },
      { label: '所属行业', value: sceneCfg.industry },
      { label: '产品密钥', value: `${sceneCfg.pkPrefix}${nodeId.slice(-6)}` },
      { label: '监测点', value: String(record.addr ?? '—') },
      { label: '所在区县', value: '韶山市' },
      { label: '所在街道', value: '清溪镇（示例）' },
      { label: '安装位置', value: sceneCfg.installLabel },
      { label: '创建时间', value: '2024-03-20 09:00:00' },
      { label: '安装时间', value: '2024-04-10 10:00:00' },
      { label: '采集频率', value: noData ? '—' : '5min/次' },
    ];
  }, [nodeId, record, scene, sceneCfg, activeDevice]);

  const currentMetric = metrics.find((m) => m.key === metricKey)!;
  const single = useMemo(() => buildSingleSeries(metricKey), [metricKey]);
  const comparison = useMemo(() => buildComparisonSeries(metricKey), [metricKey]);

  const renderChart = useCallback(() => {
    if (!chartRef.current || chartKind === 'table') return;
    if (!chartInst.current) {
      chartInst.current = echarts.init(chartRef.current);
    }
    const inst = chartInst.current;
    const isLine = chartKind === 'line';
    const useCompare = dateMode === 'date';

    const seriesList = useCompare
      ? comparison.series.map((s) => ({
          type: isLine ? 'line' : 'bar',
          name: s.name,
          data: s.data,
          smooth: isLine,
          symbol: isLine ? 'circle' : undefined,
          symbolSize: isLine ? 5 : undefined,
          lineStyle: isLine ? { width: 2, color: s.color } : undefined,
          itemStyle: { color: s.color },
          barMaxWidth: 16,
        }))
      : [
          {
            type: isLine ? 'line' : 'bar',
            name: '监测值',
            data: single.data,
            smooth: isLine,
            symbol: isLine ? 'circle' : undefined,
            symbolSize: isLine ? 6 : undefined,
            lineStyle: isLine ? { width: 2, color: '#1677ff' } : undefined,
            itemStyle: { color: '#1677ff' },
            barMaxWidth: 22,
          },
        ];

    const option: echarts.EChartsOption = {
      grid: { left: 56, right: 56, top: 32, bottom: 28 },
      tooltip: {
        trigger: 'axis',
        axisPointer: { type: 'cross' },
      },
      xAxis: { type: 'category', data: single.hours, boundaryGap: !isLine },
      yAxis: {
        type: 'value',
        scale: true,
        name: currentMetric.unit ? `单位：${currentMetric.unit}` : undefined,
        nameTextStyle: { fontSize: 11, color: '#8c8c8c' },
      },
      series: seriesList as echarts.SeriesOption[],
    };
    inst.setOption(option, true);
  }, [chartKind, comparison.series, currentMetric.unit, dateMode, single.data, single.hours]);

  useEffect(() => {
    if (chartKind === 'table') {
      chartInst.current?.dispose();
      chartInst.current = null;
      return;
    }
    renderChart();
    const ro = new ResizeObserver(() => chartInst.current?.resize());
    if (chartRef.current) ro.observe(chartRef.current);
    return () => {
      ro.disconnect();
    };
  }, [renderChart, chartKind]);

  useEffect(() => {
    return () => {
      chartInst.current?.dispose();
      chartInst.current = null;
    };
  }, []);

  // 切到无数据占位设备时释放图表实例，避免残留画布
  useEffect(() => {
    if (activeDevice && !activeDevice.hasData) {
      chartInst.current?.dispose();
      chartInst.current = null;
    }
  }, [activeDevice?.key, activeDevice?.hasData]);

  const tableColumns =
    dateMode === 'date'
      ? [
          { title: '时间', dataIndex: 't', key: 't', width: 80 },
          { title: '今日', dataIndex: 'v0', key: 'v0' },
          { title: '昨日', dataIndex: 'v1', key: 'v1' },
          { title: '去年同期', dataIndex: 'v2', key: 'v2' },
        ]
      : [
          { title: '时间', dataIndex: 't', key: 't' },
          { title: currentMetric.label, dataIndex: 'v', key: 'v' },
        ];

  const tableDataSource = single.hours.map((h, i) =>
    dateMode === 'date'
      ? {
          key: h,
          t: h,
          v0: comparison.series[0].data[i],
          v1: comparison.series[1].data[i],
          v2: comparison.series[2].data[i],
        }
      : { key: h, t: h, v: single.data[i] },
  );

  const dateHint =
    dateMode === 'date'
      ? '「按日期」展示今日、昨日、去年同期三条曲线，便于同比分析。'
      : '「按范围」在所选时段内展示单条聚合曲线。';

  return (
    <div className="facility-monitoring-realtime facility-monitoring-realtime--v2">
      <div className="facility-monitoring-equipment-section">
        <div className="facility-monitoring-equip-toolbar">
          <Space align="center" wrap style={{ width: '100%', justifyContent: 'space-between' }}>
            <Text type="secondary">
              已关联 <Text strong>{linkedDevices.length}</Text> 台物联设备；非全部设施默认接入，可自行配置。
            </Text>
            <Button type="primary" icon={<ApiOutlined />} onClick={openLinkModal}>
              关联物联设备
            </Button>
          </Space>
        </div>
        {linkedDevices.length === 0 ? (
          <Empty
            className="facility-monitoring-equip-empty"
            image={Empty.PRESENTED_IMAGE_SIMPLE}
            description={
              <span>
                尚未关联物联设备。请点击「关联物联设备」从平台清单中多选绑定，
                <br />
                保存后可在此切换卡片查看各设备数据；支持随时增删、修改关联。
              </span>
            }
          >
            <Button type="primary" icon={<ApiOutlined />} onClick={openLinkModal}>
              关联物联设备
            </Button>
          </Empty>
        ) : (
          <div className="facility-monitoring-equip-scroll">
            {linkedDevices.map((d) => (
              <button
                key={d.key}
                type="button"
                className={`facility-monitoring-equip-card tone-${d.tone} ${activeDevKey === d.key ? 'active' : ''}`}
                onClick={() => setActiveDevKey(d.key)}
              >
                <div className="facility-monitoring-equip-card-head">
                  <ThunderboltOutlined className="facility-monitoring-equip-ico" />
                  <span className="facility-monitoring-equip-name">{d.name}</span>
                </div>
                <div className="facility-monitoring-equip-tags">
                  <DeviceCardStatusTags device={d} />
                </div>
                <div className="facility-monitoring-equip-foot">
                  <span className="facility-monitoring-equip-time">{d.hasData ? d.time : '暂无数据'}</span>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      {linkedDevices.length === 0 ? (
        <Alert
          type="info"
          showIcon
          message="完成物联设备关联后，将展示设备元数据、指标与曲线（当前为物联网平台占位数据）。"
          className="facility-monitoring-link-alert"
        />
      ) : (
      <div className="facility-monitoring-device-info-section">
        <Title level={5} className="facility-monitoring-section-title">
          {sectionPrefix}设备信息
        </Title>
        <Row gutter={[16, 16]}>
          <Col xs={24} xl={8} xxl={7}>
            <div className="facility-monitoring-side-meta facility-monitoring-side-meta--striped">
              {metaRows.map((r) => (
                <div key={r.label} className="facility-monitoring-meta-row">
                  <span className="facility-monitoring-meta-label">{r.label}</span>
                  <span className="facility-monitoring-meta-value">{r.value}</span>
                </div>
              ))}
            </div>
          </Col>
          <Col xs={24} xl={16} xxl={17}>
            <div className="facility-monitoring-main">
              <div className="facility-monitoring-metric-cards">
                {metrics.map((m) => {
                  const active = metricKey === m.key;
                  const display = metricDisplayFor(m.key, activeDevice?.hasData !== false);
                  const isPrimary = !!m.primary;
                  const chStatus = !activeDevice?.hasData ? 'stopped' : getMetricChannelStatus(activeDevKey, m.key);
                  const valStatusClass =
                    chStatus === 'running'
                      ? 'facility-monitoring-metric-card-val--run'
                      : chStatus === 'stopped'
                        ? 'facility-monitoring-metric-card-val--stop'
                        : 'facility-monitoring-metric-card-val--alert';
                  return (
                    <button
                      key={m.key}
                      type="button"
                      className={`facility-monitoring-metric-card ${active ? 'active' : ''} ${isPrimary ? 'primary' : ''}`}
                      onClick={() => setMetricKey(m.key)}
                    >
                      <div className="facility-monitoring-metric-card-label">{m.label}</div>
                      <div className={`facility-monitoring-metric-card-val ${valStatusClass}`}>{display}</div>
                      {m.unit ? <div className="facility-monitoring-metric-card-unit">{m.unit}</div> : null}
                    </button>
                  );
                })}
              </div>

              <div className="facility-monitoring-toolbar">
                <Space wrap size={[8, 8]} align="center">
                  <Badge dot={false}>
                    <Button type={dateMode === 'date' ? 'primary' : 'default'} onClick={() => setDateMode('date')}>
                      按日期
                    </Button>
                  </Badge>
                  <Badge dot={false}>
                    <Button type={dateMode === 'range' ? 'primary' : 'default'} onClick={() => setDateMode('range')}>
                      按范围
                    </Button>
                  </Badge>
                  <Tooltip title={dateHint}>
                    <QuestionCircleOutlined className="facility-monitoring-hint-ico" />
                  </Tooltip>
                  <RangePicker placeholder={['开始日期', '结束日期']} style={{ minWidth: 260 }} />
                  <Button type="primary" className="search-btn">
                    查询
                  </Button>
                </Space>
                <Space className="facility-monitoring-chart-tools">
                  <Button
                    type={chartKind === 'line' ? 'link' : 'text'}
                    icon={<LineChartOutlined />}
                    onClick={() => setChartKind('line')}
                  />
                  <Button
                    type={chartKind === 'bar' ? 'link' : 'text'}
                    icon={<BarChartOutlined />}
                    onClick={() => setChartKind('bar')}
                  />
                  <Button
                    type={chartKind === 'table' ? 'link' : 'text'}
                    icon={<TableOutlined />}
                    onClick={() => setChartKind('table')}
                  />
                </Space>
              </div>

              {dateMode === 'date' && chartKind !== 'table' && activeDevice?.hasData !== false && (
                <div className="facility-monitoring-chart-legend-inline">
                  {comparison.series.map((s) => (
                    <span key={s.name} className="facility-monitoring-legend-item">
                      <i className="facility-monitoring-legend-dot" style={{ background: s.color }} />
                      {s.name}
                    </span>
                  ))}
                </div>
              )}

              <div className="facility-monitoring-chart-area">
                {activeDevice && !activeDevice.hasData ? (
                  <div className="facility-monitoring-chart-empty">
                    <Empty
                      image={Empty.PRESENTED_IMAGE_SIMPLE}
                      description="暂无监测数据（空占位，对接时序库后展示曲线）"
                    />
                  </div>
                ) : (
                  <>
                    {chartKind !== 'table' && <div ref={chartRef} className="facility-monitoring-echart" />}
                    {chartKind === 'table' && (
                      <Table
                        size="small"
                        pagination={false}
                        scroll={{ x: dateMode === 'date' ? 420 : undefined }}
                        columns={tableColumns}
                        dataSource={tableDataSource}
                      />
                    )}
                  </>
                )}
              </div>

              <Text type="secondary" style={{ fontSize: 12, display: 'block', marginTop: 8 }}>
                当前展示设备：{linkedDevices.find((d) => d.key === activeDevKey)?.name ?? '—'}
                ；曲线为物联网平台模拟数据，对接后请替换为时序查询接口。
              </Text>
            </div>
          </Col>
        </Row>
      </div>
      )}

      <Modal
        title="关联物联设备"
        open={linkModalOpen}
        onCancel={() => setLinkModalOpen(false)}
        onOk={handleLinkModalOk}
        width={520}
        destroyOnClose
        okText="保存"
        cancelText="取消"
      >
        <Text type="secondary" style={{ display: 'block', marginBottom: 12 }}>
          从物联平台已入网设备清单中选择与本设施绑定的终端；交互与「河湖长制 · 河长责任区域」责任段多选一致：上方下拉可搜索多选，下方表格汇总已选并可单行移除；保存后上方卡片仅展示已关联设备。
        </Text>
        <Form form={linkForm} layout="vertical">
          <Form.Item name="keys" label="物联设备">
            <Select
              mode="multiple"
              placeholder="请选择物联设备（可多选，对接平台清单）"
              style={{ width: '100%' }}
              options={allDevicesPool.map((d) => ({
                value: d.key,
                // 名称 + 编码写入 label，便于 showSearch 一并过滤
                label: `${d.name} ${d.deviceId}`,
              }))}
              showSearch
              optionFilterProp="label"
              maxTagCount="responsive"
            />
          </Form.Item>
          <Form.Item dependencies={['keys']} noStyle>
            {() => {
              const keys = linkForm.getFieldValue('keys') as string[] | undefined;
              const rows = getMonitorDevicesByKeys(allDevicesPool, keys);
              return (
                <Card size="small" title={`已选物联设备（${rows.length}）`} style={{ marginBottom: 0 }}>
                  <Table
                    size="small"
                    rowKey="key"
                    pagination={false}
                    locale={{ emptyText: '暂未选择设备，请在上方搜索并多选' }}
                    dataSource={rows}
                    scroll={{ x: 420 }}
                    columns={[
                      { title: '设备名称', dataIndex: 'name', ellipsis: true },
                      { title: '设备编码', dataIndex: 'deviceId', width: 168, ellipsis: true },
                      {
                        title: '操作',
                        key: 'rm',
                        width: 72,
                        fixed: 'right' as const,
                        render: (_: unknown, r: MockMonitorDevice) => (
                          <Button
                            type="link"
                            size="small"
                            className="action-btn edit"
                            onClick={() => {
                              const cur = (linkForm.getFieldValue('keys') as string[]) ?? [];
                              linkForm.setFieldsValue({ keys: cur.filter((k) => k !== r.key) });
                            }}
                          >
                            移除
                          </Button>
                        ),
                      },
                    ]}
                  />
                </Card>
              );
            }}
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export const PumpStationMonitoringTabContent: React.FC<{ record: Record<string, unknown> }> = ({ record }) => (
  <FacilityRealtimePanel record={record} scene="pump" />
);

export const OutletMonitoringTabContent: React.FC<{ record: Record<string, unknown> }> = ({ record }) => (
  <FacilityRealtimePanel record={record} scene="outlet" />
);

export const PlantMonitoringTabContent: React.FC<{ record: Record<string, unknown> }> = ({ record }) => (
  <FacilityRealtimePanel record={record} scene="plant" />
);
