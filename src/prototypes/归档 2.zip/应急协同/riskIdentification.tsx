/**
 * 风险识别 — 六类台账（与生态整治设施管理交互一致：查询、字段管理、导入导出、增删改查、详情）
 */
import React, { useCallback, useMemo, useState } from 'react';
import dayjs from 'dayjs';
import {
  Card,
  Row,
  Col,
  Table,
  Tag,
  Button,
  Input,
  Select,
  Space,
  Typography,
  Modal,
  Form,
  message,
  Popconfirm,
  Descriptions,
  DatePicker,
  Tabs,
  InputNumber,
  Checkbox,
  Divider,
  Dropdown,
  Tooltip,
  Upload,
} from 'antd';
import type { ColumnsType } from 'antd/es/table';
import {
  ColumnHeightOutlined,
  SearchOutlined,
  PlusOutlined,
  DownloadOutlined,
  UploadOutlined,
  EditOutlined,
  EyeOutlined,
} from '@ant-design/icons';

const { Text } = Typography;
const { TextArea } = Input;

const DEMO_PLAN_PDF = 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf';

// —— 与 index 中一致的字段管理类型（避免循环依赖，局部复制）——
export interface EcoColumnConfig {
  key: string;
  title: React.ReactNode;
  columnManagerLabel?: string;
  dataIndex?: string;
  width?: number;
  fixed?: 'left' | 'right';
  render?: (value: unknown, record: unknown) => React.ReactNode;
  defaultVisible?: boolean;
}

interface EcoColumnManagerProps {
  columns: EcoColumnConfig[];
  visibleColumns: string[];
  onChange: (visibleColumns: string[]) => void;
}

/** 与生态整治一致的表格字段管理（供事件复盘等模块复用） */
export const RiskEcoColumnManager: React.FC<EcoColumnManagerProps> = ({ columns, visibleColumns, onChange }) => {
  const [open, setOpen] = useState(false);
  const [isSortMode, setIsSortMode] = useState(false);

  const handleToggleColumn = (key: string, checked: boolean) => {
    if (checked) onChange([...visibleColumns, key]);
    else {
      if (key === 'operation') {
        message.warning('操作列不可隐藏');
        return;
      }
      onChange(visibleColumns.filter(k => k !== key));
    }
  };

  const handleReset = () => {
    onChange(columns.filter(c => c.key !== 'operation' && c.defaultVisible !== false).map(c => c.key));
    message.success('已重置为默认显示');
  };

  const sortableColumns = visibleColumns.filter(key => key !== 'operation');
  const handleMoveUp = (index: number) => {
    if (index <= 0) return;
    const newOrder = [...visibleColumns];
    [newOrder[index], newOrder[index - 1]] = [newOrder[index - 1], newOrder[index]];
    onChange(newOrder);
  };
  const handleMoveDown = (index: number) => {
    if (index >= sortableColumns.length - 1) return;
    const newOrder = [...visibleColumns];
    [newOrder[index], newOrder[index + 1]] = [newOrder[index + 1], newOrder[index]];
    onChange(newOrder);
  };

  const dropdownContent = (
    <Card
      title={
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span>字段管理</span>
          <Button type="link" size="small" onClick={() => setIsSortMode(!isSortMode)}>
            {isSortMode ? '完成排序' : '排序'}
          </Button>
        </div>
      }
      style={{ width: isSortMode ? 360 : 320 }}
      size="small"
    >
      <div style={{ maxHeight: 400, overflow: 'auto' }}>
        {isSortMode ? (
          <>
            {sortableColumns.map((key, index) => {
              const col = columns.find(c => c.key === key);
              const sortLabel =
                col?.columnManagerLabel ?? (typeof col?.title === 'string' ? col.title : col?.key ?? key);
              return (
                <div
                  key={key}
                  style={{ display: 'flex', alignItems: 'center', padding: '8px 0', borderBottom: '1px solid #f0f0f0' }}
                >
                  <span style={{ flex: 1 }}>{sortLabel}</span>
                  <Space>
                    <Button type="text" size="small" disabled={index === 0} onClick={() => handleMoveUp(index)}>
                      ↑
                    </Button>
                    <Button
                      type="text"
                      size="small"
                      disabled={index === sortableColumns.length - 1}
                      onClick={() => handleMoveDown(index)}
                    >
                      ↓
                    </Button>
                  </Space>
                </div>
              );
            })}
          </>
        ) : (
          columns.map(col => (
            <div key={col.key} style={{ marginBottom: 8 }}>
              <Checkbox
                checked={col.key === 'operation' || visibleColumns.includes(col.key)}
                onChange={e => handleToggleColumn(col.key, e.target.checked)}
                disabled={col.key === 'operation'}
              >
                <Space>
                  {col.columnManagerLabel ?? (typeof col.title === 'string' ? col.title : col.key)}
                  {col.key === 'operation' && (
                    <Tag color="blue" style={{ fontSize: 10 }}>
                      固定
                    </Tag>
                  )}
                </Space>
              </Checkbox>
            </div>
          ))
        )}
      </div>
      {!isSortMode && (
        <>
          <Divider style={{ margin: '12px 0' }} />
          <Button type="link" onClick={handleReset} size="small">
            恢复默认
          </Button>
        </>
      )}
    </Card>
  );

  return (
    <Dropdown
      open={open}
      popupRender={() => dropdownContent}
      placement="bottomRight"
      onOpenChange={visible => {
        setOpen(visible);
        if (!visible) setIsSortMode(false);
      }}
    >
      <Tooltip title="字段管理">
        <Button icon={<ColumnHeightOutlined />}>字段</Button>
      </Tooltip>
    </Dropdown>
  );
};

export const getEcoDefaultVisibleColumnKeys = (cols: EcoColumnConfig[]): string[] =>
  cols.filter(c => c.key !== 'operation' && c.defaultVisible !== false).map(c => c.key);

const ECO_DEFAULT_COL_WIDTH = 120;
export function getEcoTableScrollX(cols: { width?: number }[]): number {
  const total = cols.reduce(
    (sum, c) => sum + (typeof c.width === 'number' ? c.width : ECO_DEFAULT_COL_WIDTH),
    0,
  );
  return Math.max(total, 100);
}

export function buildTableColumnsFromEcoConfig(
  allCols: EcoColumnConfig[],
  visibleKeys: string[],
  operationRender: (record: unknown) => React.ReactNode,
): ColumnsType<unknown> {
  return allCols
    .filter(col => visibleKeys.includes(col.key) || col.key === 'operation')
    .sort((a, b) => {
      if (a.key === 'operation') return 1;
      if (b.key === 'operation') return -1;
      return visibleKeys.indexOf(a.key) - visibleKeys.indexOf(b.key);
    })
    .map(col => {
      if (col.key === 'operation') {
        const { defaultVisible: _d, ...opRest } = col;
        return {
          ...opRest,
          fixed: 'right' as const,
          render: (_: unknown, record: unknown) => operationRender(record),
        };
      }
      const { defaultVisible: _dv, ...rest } = col;
      return { ...rest };
    }) as ColumnsType<unknown>;
}

const EcoProtoExportBtn = ({ onClick }: { onClick?: () => void }) => (
  <Button icon={<DownloadOutlined />} className="export-btn" onClick={onClick ?? (() => message.success('已导出'))}>
    导出
  </Button>
);

const EcoProtoImportBtn = () => (
  <Upload
    beforeUpload={() => {
      message.success('已导入');
      return false;
    }}
    showUploadList={false}
  >
    <Button icon={<UploadOutlined />} className="secondary-btn">导入</Button>
  </Upload>
);

const formModalStyles = {
  body: {
    maxHeight: 'calc(100vh - 240px)',
    overflowY: 'auto' as const,
    overflowX: 'hidden' as const,
    minWidth: 0,
  },
};

/** 只读详情弹窗：与生态整治大型详情一致，内容区可滚动高度略增 */
const detailModalStyles = {
  ...formModalStyles,
  body: { ...formModalStyles.body, maxHeight: 'min(85vh, 900px)', overflowY: 'auto' as const },
};

// ========== 数据类型 ==========
export interface RiskEnterpriseRow {
  id: string;
  enterpriseName: string;
  address: string;
  industryType: string;
  mainPollutants: string;
  dischargeScale: string;
  riskLevel: string;
  contactName: string;
  contactPhone: string;
  region: string;
  updatedAt: string;
}

export interface SocialSupplyPointRow {
  id: string;
  name: string;
  address: string;
  materialTypesQty: string;
  contactPhone: string;
  callProcess: string;
}

export interface EmergencySupplyRow {
  id: string;
  name: string;
  materialType: string;
  specModel: string;
  quantity: number;
  socialPointId: string;
  manager: string;
  replenishCycle: string;
  usageNote: string;
}

export interface EmergencyPlanRow {
  id: string;
  name: string;
  planType: string;
  publishTime: string;
  compileOrg: string;
  orgSystem: string;
  responseFlow: string;
  measures: string;
  dutyDivision: string;
  attachmentName: string;
  pdfUrl: string;
}

export interface TeamMemberRow {
  id: string;
  name: string;
  role: string;
  phone: string;
  skill: string;
}

export interface EmergencyTeamRow {
  id: string;
  name: string;
  specialty: string;
  equipment: string;
  contactPhone: string;
  dutyDivision: string;
  members: TeamMemberRow[];
}

export interface ExpertRow {
  id: string;
  name: string;
  background: string;
  expertise: string;
  org: string;
  title: string;
  phone: string;
}

export interface RiskDataBundle {
  enterprises: RiskEnterpriseRow[];
  socialPoints: SocialSupplyPointRow[];
  supplies: EmergencySupplyRow[];
  plans: EmergencyPlanRow[];
  teams: EmergencyTeamRow[];
  experts: ExpertRow[];
}

const riskLevelColor: Record<string, string> = { 高: 'red', 中: 'orange', 低: 'blue', 一般: 'default' };

export const initialRiskData: RiskDataBundle = {
  socialPoints: [
    {
      id: 'ss-1',
      name: '清溪镇防汛物资互助点',
      address: '韶山市清溪镇××路18 号',
      materialTypesQty: '沙袋约 2000 个、抽水泵 6 台',
      contactPhone: '0732-55×××××',
      callProcess: '向乡镇应急办报备后2 小时内可启运',
    },
  ],
  enterprises: [
    {
      id: 're-1',
      enterpriseName: '湘潭某化工有限公司',
      address: '湘潭市××开发区化工园',
      industryType: '化学原料制造',
      mainPollutants: '化学需氧量、石油类',
      dischargeScale: '废水约 120 吨/日',
      riskLevel: '较大',
      contactName: '刘某',
      contactPhone: '0731-88×××××',
      region: '湘潭市',
      updatedAt: '2025-03-01',
    },
  ],
  supplies: [
    {
      id: 'es-1',
      name: '吸油毡',
      materialType: '吸附类',
      specModel: '1m×2m',
      quantity: 120,
      socialPointId: 'ss-1',
      manager: '张某',
      replenishCycle: '每季度盘点补充',
      usageNote: '围控后铺设于油膜集中区域',
    },
    {
      id: 'es-2',
      name: '围油栏',
      materialType: '围控类',
      specModel: 'PVC 浮体',
      quantity: 50,
      socialPointId: 'ss-1',
      manager: '张某',
      replenishCycle: '每季度盘点补充',
      usageNote: '布设于水面围控油污',
    },
  ],
  plans: [
    {
      id: 'ep-1',
      name: '湘潭市突发水环境污染事件应急预案',
      planType: '总体应急预案',
      publishTime: '2024-11-01',
      compileOrg: '湘潭市人民政府',
      orgSystem: '市指挥部—专项组—现场组三级体系',
      responseFlow: '接报核实→响应启动→现场处置→终止与调查',
      measures: '监测加密、溯源管控、饮用水保障',
      dutyDivision: '生态环境牵头，水利、卫健、海事协同',
      attachmentName: '湘潭市水环境应急预案（发布稿）.pdf',
      pdfUrl: DEMO_PLAN_PDF,
    },
  ],
  teams: [
    {
      id: 'et-1',
      name: '市生态环境应急救援一队',
      specialty: '水质应急监测、围控与吸附',
      equipment: '便携式多参数仪4 台、应急车辆 2 辆',
      contactPhone: '0731-12369',
      dutyDivision: '现场监测与污染跟踪',
      members: [
        { id: 'tm-1', name: '周某', role: '现场指挥', phone: '138****1001', skill: '应急调度' },
        { id: 'tm-2', name: '吴某', role: '监测组长', phone: '138****1002', skill: '水质快检' },
      ],
    },
  ],
  experts: [
    {
      id: 'ex-1',
      name: '陈某',
      background: '环境工程硕士，从事水环境应急 15 年',
      expertise: '水环境应急监测、油污应急处置',
      org: '省环科院水环境所',
      title: '高级工程师',
      phone: '138****0001',
    },
  ],
};

// ========== 1风险源企业 ==========
export const RiskEnterprisePage: React.FC<{
  rows: RiskEnterpriseRow[];
  onChange: React.Dispatch<React.SetStateAction<RiskEnterpriseRow[]>>;
}> = ({ rows, onChange }) => {
  const [filterForm] = Form.useForm();
  const [editForm] = Form.useForm();
  const [query, setQuery] = useState<Record<string, unknown>>({});
  const [detail, setDetail] = useState<RiskEnterpriseRow | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [editing, setEditing] = useState<RiskEnterpriseRow | null>(null);

  const filtered = useMemo(() => {
    const kw = String(query.keyword ?? '').trim();
    const region = query.region as string | undefined;
    const riskLevel = query.riskLevel as string | undefined;
    return rows.filter(r => {
      if (region && r.region !== region) return false;
      if (riskLevel && r.riskLevel !== riskLevel) return false;
      if (kw) {
        const blob = `${r.enterpriseName}${r.address}${r.industryType}${r.mainPollutants}${r.contactName}`;
        if (!blob.includes(kw)) return false;
      }
      return true;
    });
  }, [rows, query]);

  const allCols: EcoColumnConfig[] = useMemo(
    () => [
      { key: 'enterpriseName', title: '企业名称', dataIndex: 'enterpriseName', width: 200, fixed: 'left' },
      { key: 'region', title: '所属区域', dataIndex: 'region', width: 100 },
      { key: 'address', title: '地理位置', dataIndex: 'address', width: 200, ellipsis: true },
      { key: 'industryType', title: '行业类型', dataIndex: 'industryType', width: 130 },
      { key: 'mainPollutants', title: '主要污染物', dataIndex: 'mainPollutants', width: 160, ellipsis: true },
      { key: 'dischargeScale', title: '排放规模', dataIndex: 'dischargeScale', width: 120 },
      {
        key: 'riskLevel',
        title: '风险等级',
        dataIndex: 'riskLevel',
        width: 100,
        render: (v: unknown) => <Tag color={riskLevelColor[String(v)] ?? 'default'}>{String(v)}</Tag>,
      },
      { key: 'contactName', title: '应急联系人', dataIndex: 'contactName', width: 100 },
      { key: 'contactPhone', title: '联系方式', dataIndex: 'contactPhone', width: 130 },
      { key: 'updatedAt', title: '更新日期', dataIndex: 'updatedAt', width: 120 },
      { key: 'operation', title: '操作', width: 148, defaultVisible: true },
    ],
    [],
  );
  const [visibleCols, setVisibleCols] = useState(() => getEcoDefaultVisibleColumnKeys(allCols));
  const columns = useMemo(
    () =>
      buildTableColumnsFromEcoConfig(allCols, visibleCols, record => {
        const row = record as RiskEnterpriseRow;
        return (
          <Space size="small">
            <Button type="link" size="small" className="action-btn detail" icon={<EyeOutlined />} onClick={() => { setDetail(row); setDetailOpen(true); }}>
              详情
            </Button>
            <Button
              type="link"
              size="small"
              className="action-btn edit"
              icon={<EditOutlined />}
              onClick={() => {
                setEditing(row);
                editForm.setFieldsValue(row);
                setEditOpen(true);
              }}
            >
              编辑
            </Button>
          </Space>
        );
      }),
    [allCols, visibleCols, editForm],
  );

  const save = async () => {
    const v = await editForm.validateFields();
    const payload: RiskEnterpriseRow = {
      id: editing?.id ?? `re-${Date.now()}`,
      ...v,
      updatedAt: dayjs().format('YYYY-MM-DD'),
    };
    if (editing) onChange(prev => prev.map(r => (r.id === editing.id ? payload : r)));
    else onChange(prev => [...prev, payload]);
    message.success(editing ? '已保存' : '已新增');
    setEditOpen(false);
    setEditing(null);
    editForm.resetFields();
  };

  return (
    <div className="facility-view">
      <Card
        title="风险源企业信息"
        extra={
          <Space wrap>
            <EcoProtoExportBtn />
            <EcoProtoImportBtn />
            <RiskEcoColumnManager columns={allCols} visibleColumns={visibleCols} onChange={setVisibleCols} />
            <Button type="primary" icon={<PlusOutlined />} className="add-btn" onClick={() => { setEditing(null); editForm.resetFields(); setEditOpen(true); }}>
              新增
            </Button>
          </Space>
        }
      >
        <Form form={filterForm} layout="vertical" style={{ marginBottom: 12 }}>
          <Row gutter={[12, 12]}>
            <Col xs={24} sm={12} md={8}>
              <Form.Item name="keyword" style={{ marginBottom: 0 }}>
                <Input allowClear placeholder="关键词：企业名称、地址、行业、污染物、联系人" prefix={<SearchOutlined />} />
              </Form.Item>
            </Col>
            <Col xs={24} sm={12} md={6}>
              <Form.Item name="region" style={{ marginBottom: 0 }}>
                <Select allowClear placeholder="所属区域" options={['湘潭市', '韶山市', '湘潭县', '湘乡市', '雨湖区', '岳塘市'].map(x => ({ label: x, value: x }))} />
              </Form.Item>
            </Col>
            <Col xs={24} sm={12} md={6}>
              <Form.Item name="riskLevel" style={{ marginBottom: 0 }}>
                <Select allowClear placeholder="风险等级" options={['高', '较大', '中', '低', '一般'].map(x => ({ label: x, value: x }))} />
              </Form.Item>
            </Col>
            <Col xs={24} style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <Space>
                <Button
                  type="primary"
                  className="search-btn"
                  icon={<SearchOutlined />}
                  onClick={() => {
                    const v = filterForm.getFieldsValue();
                    setQuery(v);
                    message.success('已查询');
                  }}
                >
                  查询
                </Button>
                <Button className="secondary-btn" onClick={() => { filterForm.resetFields(); setQuery({}); message.info('已重置'); }}>重置</Button>
              </Space>
            </Col>
          </Row>
        </Form>
        <div className="facility-table-wrap">
          <Table
            rowKey="id"
            size="small"
            scroll={{ x: getEcoTableScrollX(allCols.filter(c => visibleCols.includes(c.key) || c.key === 'operation')) }}
            pagination={{ pageSize: 10, showTotal: t => `共 ${t} 条` }}
            columns={columns}
            dataSource={filtered}
          />
        </div>
      </Card>
      <Modal title="企业详情" open={detailOpen} onCancel={() => { setDetailOpen(false); setDetail(null); }} footer={null} width={880} destroyOnClose styles={detailModalStyles}>
        {detail && (
          <Descriptions bordered column={2} size="small" style={{ marginTop: 8 }}>
            <Descriptions.Item label="企业名称" span={2}><Text strong>{detail.enterpriseName}</Text></Descriptions.Item>
            <Descriptions.Item label="所属区域">{detail.region}</Descriptions.Item>
            <Descriptions.Item label="更新日期">{detail.updatedAt}</Descriptions.Item>
            <Descriptions.Item label="地理位置" span={2}>{detail.address}</Descriptions.Item>
            <Descriptions.Item label="行业类型">{detail.industryType}</Descriptions.Item>
            <Descriptions.Item label="风险等级"><Tag color={riskLevelColor[detail.riskLevel]}>{detail.riskLevel}</Tag></Descriptions.Item>
            <Descriptions.Item label="主要污染物" span={2}>{detail.mainPollutants}</Descriptions.Item>
            <Descriptions.Item label="排放规模" span={2}>{detail.dischargeScale}</Descriptions.Item>
            <Descriptions.Item label="应急联系人">{detail.contactName}</Descriptions.Item>
            <Descriptions.Item label="联系方式">{detail.contactPhone}</Descriptions.Item>
          </Descriptions>
        )}
      </Modal>
      <Modal
        title={editing ? '编辑企业' : '新增企业'}
        open={editOpen}
        onCancel={() => { setEditOpen(false); setEditing(null); editForm.resetFields(); }}
        width={800}
        destroyOnClose
        styles={formModalStyles}
        onOk={() => void save()}
      >
        <Form form={editForm} layout="vertical">
          <Row gutter={16}>
            <Col span={24}>
              <Form.Item name="enterpriseName" label="企业名称" rules={[{ required: true }]}><Input /></Form.Item>
            </Col>
            <Col xs={24} sm={12}>
              <Form.Item name="region" label="所属区域" rules={[{ required: true }]}><Input /></Form.Item>
            </Col>
            <Col xs={24} sm={12}>
              <Form.Item name="riskLevel" label="风险等级" rules={[{ required: true }]}>
                <Select options={['高', '较大', '中', '低', '一般'].map(x => ({ value: x, label: x }))} />
              </Form.Item>
            </Col>
            <Col span={24}>
              <Form.Item name="address" label="地理位置" rules={[{ required: true }]}><Input /></Form.Item>
            </Col>
            <Col span={24}>
              <Form.Item name="industryType" label="行业类型" rules={[{ required: true }]}><Input /></Form.Item>
            </Col>
            <Col span={24}>
              <Form.Item name="mainPollutants" label="主要污染物" rules={[{ required: true }]}><TextArea rows={2} /></Form.Item>
            </Col>
            <Col span={24}>
              <Form.Item name="dischargeScale" label="排放规模" rules={[{ required: true }]}><Input /></Form.Item>
            </Col>
            <Col xs={24} sm={12}>
              <Form.Item name="contactName" label="应急联系人" rules={[{ required: true }]}><Input /></Form.Item>
            </Col>
            <Col xs={24} sm={12}>
              <Form.Item name="contactPhone" label="联系方式" rules={[{ required: true }]}><Input /></Form.Item>
            </Col>
          </Row>
        </Form>
      </Modal>
    </div>
  );
};

// ========== 2 应急物资（依赖社会物资点选项）==========
export const EmergencySupplyPage: React.FC<{
  rows: EmergencySupplyRow[];
  socialPoints: SocialSupplyPointRow[];
  onChange: React.Dispatch<React.SetStateAction<EmergencySupplyRow[]>>;
}> = ({ rows, socialPoints, onChange }) => {
  const [filterForm] = Form.useForm();
  const [editForm] = Form.useForm();
  const [query, setQuery] = useState<Record<string, unknown>>({});
  const [detail, setDetail] = useState<EmergencySupplyRow | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [editing, setEditing] = useState<EmergencySupplyRow | null>(null);

  const pointOptions = useMemo(() => socialPoints.map(s => ({ value: s.id, label: s.name })), [socialPoints]);

  const filtered = useMemo(() => {
    const kw = String(query.keyword ?? '').trim();
    const type = query.materialType as string | undefined;
    return rows.filter(r => {
      if (type && r.materialType !== type) return false;
      if (kw && !`${r.name}${r.specModel}${r.manager}`.includes(kw)) return false;
      return true;
    });
  }, [rows, query]);

  const allCols: EcoColumnConfig[] = useMemo(
    () => [
      { key: 'name', title: '物资名称', dataIndex: 'name', width: 140 },
      { key: 'materialType', title: '类型', dataIndex: 'materialType', width: 100 },
      { key: 'specModel', title: '规格型号', dataIndex: 'specModel', width: 120 },
      { key: 'quantity', title: '储备数量', dataIndex: 'quantity', width: 100 },
      {
        key: 'socialPointId',
        title: '关联社会物资点',
        dataIndex: 'socialPointId',
        width: 180,
        ellipsis: true,
        render: (id: unknown) => socialPoints.find(s => s.id === id)?.name ?? String(id),
      },
      { key: 'manager', title: '管理责任人', dataIndex: 'manager', width: 100 },
      { key: 'replenishCycle', title: '补充周期', dataIndex: 'replenishCycle', width: 120 },
      { key: 'operation', title: '操作', width: 148, defaultVisible: true },
    ],
    [socialPoints],
  );
  const [visibleCols, setVisibleCols] = useState(() => getEcoDefaultVisibleColumnKeys(allCols));
  const columns = useMemo(
    () =>
      buildTableColumnsFromEcoConfig(allCols, visibleCols, record => {
        const row = record as EmergencySupplyRow;
        return (
          <Space size="small">
            <Button type="link" size="small" className="action-btn detail" icon={<EyeOutlined />} onClick={() => { setDetail(row); setDetailOpen(true); }}>详情</Button>
            <Button
              type="link"
              size="small"
              className="action-btn edit"
              icon={<EditOutlined />}
              onClick={() => {
                setEditing(row);
                editForm.setFieldsValue(row);
                setEditOpen(true);
              }}
            >
              编辑
            </Button>
          </Space>
        );
      }),
    [allCols, visibleCols, editForm],
  );

  const save = async () => {
    const v = await editForm.validateFields();
    const payload: EmergencySupplyRow = { id: editing?.id ?? `es-${Date.now()}`, ...v };
    if (editing) onChange(prev => prev.map(r => (r.id === editing.id ? payload : r)));
    else onChange(prev => [...prev, payload]);
    message.success(editing ? '已保存' : '已新增');
    setEditOpen(false);
    setEditing(null);
    editForm.resetFields();
  };

  return (
    <div className="facility-view">
      <Card
        title="应急物资"
        extra={
          <Space wrap>
            <EcoProtoExportBtn />
            <EcoProtoImportBtn />
            <RiskEcoColumnManager columns={allCols} visibleColumns={visibleCols} onChange={setVisibleCols} />
            <Button type="primary" icon={<PlusOutlined />} className="add-btn" onClick={() => { setEditing(null); editForm.resetFields(); setEditOpen(true); }}>新增</Button>
          </Space>
        }
      >
        <Form form={filterForm} layout="vertical" style={{ marginBottom: 12 }}>
          <Row gutter={[12, 12]}>
            <Col xs={24} sm={12} md={8}>
              <Form.Item name="keyword" style={{ marginBottom: 0 }}>
                <Input allowClear placeholder="关键词：物资名称、规格、责任人" prefix={<SearchOutlined />} />
              </Form.Item>
            </Col>
            <Col xs={24} sm={12} md={8}>
              <Form.Item name="materialType" style={{ marginBottom: 0 }}>
                <Select allowClear placeholder="物资类型" options={['吸附类', '围控类', '监测类', '通用'].map(x => ({ label: x, value: x }))} />
              </Form.Item>
            </Col>
            <Col xs={24} style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <Space>
                <Button type="primary" className="search-btn" icon={<SearchOutlined />} onClick={() => { setQuery(filterForm.getFieldsValue()); message.success('已查询'); }}>查询</Button>
                <Button className="secondary-btn" onClick={() => { filterForm.resetFields(); setQuery({}); }}>重置</Button>
              </Space>
            </Col>
          </Row>
        </Form>
        <div className="facility-table-wrap">
          <Table
            rowKey="id"
            size="small"
            scroll={{ x: getEcoTableScrollX(allCols.filter(c => visibleCols.includes(c.key) || c.key === 'operation')) }}
            pagination={{ pageSize: 10, showTotal: t => `共 ${t} 条` }}
            columns={columns}
            dataSource={filtered}
          />
        </div>
      </Card>
      <Modal title="物资详情" open={detailOpen} onCancel={() => { setDetailOpen(false); setDetail(null); }} footer={null} width={720} destroyOnClose styles={detailModalStyles}>
        {detail && (
          <Descriptions bordered column={2} size="small" style={{ marginTop: 8 }}>
            <Descriptions.Item label="物资名称" span={2}><Text strong>{detail.name}</Text></Descriptions.Item>
            <Descriptions.Item label="类型">{detail.materialType}</Descriptions.Item>
            <Descriptions.Item label="储备数量">{detail.quantity}</Descriptions.Item>
            <Descriptions.Item label="规格型号" span={2}>{detail.specModel}</Descriptions.Item>
            <Descriptions.Item label="关联社会物资点" span={2}>{socialPoints.find(s => s.id === detail.socialPointId)?.name ?? '—'}</Descriptions.Item>
            <Descriptions.Item label="管理责任人">{detail.manager}</Descriptions.Item>
            <Descriptions.Item label="补充周期">{detail.replenishCycle}</Descriptions.Item>
            <Descriptions.Item label="使用说明" span={2}>{detail.usageNote}</Descriptions.Item>
          </Descriptions>
        )}
      </Modal>
      <Modal
        title={editing ? '编辑物资' : '新增物资'}
        open={editOpen}
        onCancel={() => { setEditOpen(false); setEditing(null); editForm.resetFields(); }}
        width={720}
        destroyOnClose
        styles={formModalStyles}
        onOk={() => void save()}
      >
        <Form form={editForm} layout="vertical">
          <Form.Item name="name" label="物资名称" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="materialType" label="物资类型" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="specModel" label="规格型号" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="quantity" label="储备数量" rules={[{ required: true }]}><InputNumber min={0} style={{ width: '100%' }} /></Form.Item>
          <Form.Item name="socialPointId" label="所属社会物资点" rules={[{ required: true, message: '请选择社会物资点' }]}>
            <Select options={pointOptions} placeholder="下拉单选" showSearch optionFilterProp="label" />
          </Form.Item>
          <Form.Item name="manager" label="管理责任人" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="replenishCycle" label="补充周期" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="usageNote" label="使用说明" rules={[{ required: true }]}><TextArea rows={3} /></Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

// ========== 3 社会物资点 ==========
export const SocialSupplyPointPage: React.FC<{
  rows: SocialSupplyPointRow[];
  supplies: EmergencySupplyRow[];
  onChange: React.Dispatch<React.SetStateAction<SocialSupplyPointRow[]>>;
}> = ({ rows, supplies, onChange }) => {
  const [filterForm] = Form.useForm();
  const [editForm] = Form.useForm();
  const [query, setQuery] = useState<Record<string, unknown>>({});
  const [detail, setDetail] = useState<SocialSupplyPointRow | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [editing, setEditing] = useState<SocialSupplyPointRow | null>(null);

  const filtered = useMemo(() => {
    const kw = String(query.keyword ?? '').trim();
    return rows.filter(r => !kw || `${r.name}${r.address}${r.contactPhone}`.includes(kw));
  }, [rows, query]);

  const linkedForDetail = useMemo(
    () => (detail ? supplies.filter(s => s.socialPointId === detail.id) : []),
    [detail, supplies],
  );

  const allCols: EcoColumnConfig[] = useMemo(
    () => [
      { key: 'name', title: '物资点名称', dataIndex: 'name', width: 200, ellipsis: true },
      { key: 'address', title: '位置', dataIndex: 'address', width: 220, ellipsis: true },
      { key: 'materialTypesQty', title: '可提供物资类型及数量', dataIndex: 'materialTypesQty', ellipsis: true },
      { key: 'contactPhone', title: '联络方式', dataIndex: 'contactPhone', width: 130 },
      {
        key: 'linkedCount',
        title: '关联应急物资数',
        width: 130,
        render: (_: unknown, record: unknown) => supplies.filter(s => s.socialPointId === (record as SocialSupplyPointRow).id).length,
      },
      { key: 'operation', title: '操作', width: 148, defaultVisible: true },
    ],
    [supplies],
  );
  const [visibleCols, setVisibleCols] = useState(() => getEcoDefaultVisibleColumnKeys(allCols));
  const columns = useMemo(
    () =>
      buildTableColumnsFromEcoConfig(allCols, visibleCols, record => {
        const row = record as SocialSupplyPointRow;
        return (
          <Space size="small">
            <Button type="link" size="small" className="action-btn detail" icon={<EyeOutlined />} onClick={() => { setDetail(row); setDetailOpen(true); }}>详情</Button>
            <Button type="link" size="small" className="action-btn edit" icon={<EditOutlined />} onClick={() => { setEditing(row); editForm.setFieldsValue(row); setEditOpen(true); }}>编辑</Button>
          </Space>
        );
      }),
    [allCols, visibleCols, editForm],
  );

  const save = async () => {
    const v = await editForm.validateFields();
    const payload: SocialSupplyPointRow = { id: editing?.id ?? `ss-${Date.now()}`, ...v };
    if (editing) onChange(prev => prev.map(r => (r.id === editing.id ? payload : r)));
    else onChange(prev => [...prev, payload]);
    message.success(editing ? '已保存' : '已新增');
    setEditOpen(false);
    setEditing(null);
    editForm.resetFields();
  };

  return (
    <div className="facility-view">
      <Card
        title="社会物资点"
        extra={
          <Space wrap>
            <EcoProtoExportBtn />
            <EcoProtoImportBtn />
            <RiskEcoColumnManager columns={allCols} visibleColumns={visibleCols} onChange={setVisibleCols} />
            <Button type="primary" icon={<PlusOutlined />} className="add-btn" onClick={() => { setEditing(null); editForm.resetFields(); setEditOpen(true); }}>新增</Button>
          </Space>
        }
      >
        <Form form={filterForm} layout="vertical" style={{ marginBottom: 12 }}>
          <Row gutter={[12, 12]}>
            <Col xs={24} sm={12} md={10}>
              <Form.Item name="keyword" style={{ marginBottom: 0 }}>
                <Input allowClear placeholder="关键词：名称、地址、电话" prefix={<SearchOutlined />} />
              </Form.Item>
            </Col>
            <Col xs={24} style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <Space>
                <Button type="primary" className="search-btn" icon={<SearchOutlined />} onClick={() => { setQuery(filterForm.getFieldsValue()); message.success('已查询'); }}>查询</Button>
                <Button className="secondary-btn" onClick={() => { filterForm.resetFields(); setQuery({}); }}>重置</Button>
              </Space>
            </Col>
          </Row>
        </Form>
        <div className="facility-table-wrap">
          <Table
            rowKey="id"
            size="small"
            scroll={{ x: getEcoTableScrollX(allCols.filter(c => visibleCols.includes(c.key) || c.key === 'operation')) }}
            pagination={{ pageSize: 10, showTotal: t => `共 ${t} 条` }}
            columns={columns}
            dataSource={filtered}
          />
        </div>
      </Card>
      <Modal title="物资点详情" open={detailOpen} onCancel={() => { setDetailOpen(false); setDetail(null); }} footer={null} width={900} destroyOnClose styles={detailModalStyles}>
        {detail && (
          <>
            <Descriptions bordered column={2} size="small" style={{ marginBottom: 16 }}>
              <Descriptions.Item label="物资点名称" span={2}><Text strong>{detail.name}</Text></Descriptions.Item>
              <Descriptions.Item label="位置" span={2}>{detail.address}</Descriptions.Item>
              <Descriptions.Item label="可提供物资类型及数量" span={2}>{detail.materialTypesQty}</Descriptions.Item>
              <Descriptions.Item label="联络方式">{detail.contactPhone}</Descriptions.Item>
              <Descriptions.Item label="调用流程" span={2}>{detail.callProcess}</Descriptions.Item>
            </Descriptions>
            <Card size="small" title="关联的应急物资列表">
              <Table
                rowKey="id"
                size="small"
                pagination={false}
                dataSource={linkedForDetail}
                columns={[
                  { title: '物资名称', dataIndex: 'name' },
                  { title: '类型', dataIndex: 'materialType' },
                  { title: '规格型号', dataIndex: 'specModel' },
                  { title: '储备数量', dataIndex: 'quantity' },
                  { title: '责任人', dataIndex: 'manager' },
                ]}
              />
            </Card>
          </>
        )}
      </Modal>
      <Modal title={editing ? '编辑物资点' : '新增物资点'} open={editOpen} onCancel={() => { setEditOpen(false); setEditing(null); editForm.resetFields(); }} width={720} destroyOnClose styles={formModalStyles} onOk={() => void save()}>
        <Form form={editForm} layout="vertical">
          <Form.Item name="name" label="名称" rules={[{ required: true }]}><Input placeholder="企业、商超、物流站点等" /></Form.Item>
          <Form.Item name="address" label="位置" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="materialTypesQty" label="可提供物资类型及数量" rules={[{ required: true }]}><TextArea rows={2} /></Form.Item>
          <Form.Item name="contactPhone" label="联络方式" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="callProcess" label="调用流程" rules={[{ required: true }]}><TextArea rows={3} /></Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

// ========== 4 应急预案 ==========
export const EmergencyPlanPage: React.FC<{
  rows: EmergencyPlanRow[];
  onChange: React.Dispatch<React.SetStateAction<EmergencyPlanRow[]>>;
}> = ({ rows, onChange }) => {
  const [filterForm] = Form.useForm();
  const [editForm] = Form.useForm();
  const [query, setQuery] = useState<Record<string, unknown>>({});
  const [detail, setDetail] = useState<EmergencyPlanRow | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [editing, setEditing] = useState<EmergencyPlanRow | null>(null);

  const filtered = useMemo(() => {
    const kw = String(query.keyword ?? '').trim();
    const pt = query.planType as string | undefined;
    return rows.filter(r => {
      if (pt && r.planType !== pt) return false;
      if (kw && !`${r.name}${r.compileOrg}`.includes(kw)) return false;
      return true;
    });
  }, [rows, query]);

  const allCols: EcoColumnConfig[] = useMemo(
    () => [
      { key: 'name', title: '预案名称', dataIndex: 'name', width: 220, ellipsis: true },
      { key: 'planType', title: '预案类型', dataIndex: 'planType', width: 120 },
      { key: 'publishTime', title: '发布时间', dataIndex: 'publishTime', width: 120 },
      { key: 'compileOrg', title: '编制单位', dataIndex: 'compileOrg', width: 160, ellipsis: true },
      {
        key: 'attachmentName',
        title: '附件',
        dataIndex: 'attachmentName',
        width: 200,
        ellipsis: true,
        render: (text: unknown, record: unknown) => {
          const r = record as EmergencyPlanRow;
          return r.pdfUrl ? (
            <Button type="link" size="small" className="action-btn detail" href={r.pdfUrl} target="_blank" rel="noopener noreferrer" onClick={e => e.stopPropagation()}>
              {String(text)}
            </Button>
          ) : (
            String(text ?? '—')
          );
        },
      },
      { key: 'operation', title: '操作', width: 148, defaultVisible: true },
    ],
    [],
  );
  const [visibleCols, setVisibleCols] = useState(() => getEcoDefaultVisibleColumnKeys(allCols));
  const columns = useMemo(
    () =>
      buildTableColumnsFromEcoConfig(allCols, visibleCols, record => {
        const row = record as EmergencyPlanRow;
        return (
          <Space size="small">
            <Button type="link" size="small" className="action-btn detail" icon={<EyeOutlined />} onClick={() => { setDetail(row); setDetailOpen(true); }}>详情</Button>
            <Button type="link" size="small" className="action-btn edit" icon={<EditOutlined />} onClick={() => {
              setEditing(row);
              editForm.setFieldsValue({ ...row, publishTime: row.publishTime ? dayjs(row.publishTime) : undefined });
 setEditOpen(true);
            }}>编辑</Button>
          </Space>
        );
      }),
    [allCols, visibleCols, editForm],
  );

  const save = async () => {
    const v = await editForm.validateFields();
    const pt = v.publishTime;
    const publishTimeStr = pt && dayjs.isDayjs(pt) ? (pt as dayjs.Dayjs).format('YYYY-MM-DD') : String(pt ?? '');
    const payload: EmergencyPlanRow = {
      id: editing?.id ?? `ep-${Date.now()}`,
      name: v.name,
      planType: v.planType,
      publishTime: publishTimeStr,
      compileOrg: v.compileOrg,
      orgSystem: v.orgSystem,
      responseFlow: v.responseFlow,
      measures: v.measures,
      dutyDivision: v.dutyDivision,
      attachmentName: v.attachmentName || '预案附件.pdf',
      pdfUrl: typeof v.pdfUrl === 'string' && v.pdfUrl ? v.pdfUrl : DEMO_PLAN_PDF,
    };
    if (editing) onChange(prev => prev.map(r => (r.id === editing.id ? payload : r)));
    else onChange(prev => [...prev, payload]);
    message.success(editing ? '已保存' : '已新增');
    setEditOpen(false);
    setEditing(null);
    editForm.resetFields();
  };

  return (
    <div className="facility-view">
      <Card
        title="应急预案信息"
        extra={
          <Space wrap>
            <EcoProtoExportBtn />
            <EcoProtoImportBtn />
            <RiskEcoColumnManager columns={allCols} visibleColumns={visibleCols} onChange={setVisibleCols} />
            <Button type="primary" icon={<PlusOutlined />} className="add-btn" onClick={() => { setEditing(null); editForm.resetFields(); setEditOpen(true); }}>新增</Button>
          </Space>
        }
      >
        <Form form={filterForm} layout="vertical" style={{ marginBottom: 12 }}>
          <Row gutter={[12, 12]}>
            <Col xs={24} sm={12} md={8}>
              <Form.Item name="keyword" style={{ marginBottom: 0 }}>
                <Input allowClear placeholder="关键词：预案名称、编制单位" prefix={<SearchOutlined />} />
              </Form.Item>
            </Col>
            <Col xs={24} sm={12} md={8}>
              <Form.Item name="planType" style={{ marginBottom: 0 }}>
                <Select allowClear placeholder="预案类型" options={['总体应急预案', '专项应急预案', '现场处置方案'].map(x => ({ label: x, value: x }))} />
              </Form.Item>
            </Col>
            <Col xs={24} style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <Space>
                <Button type="primary" className="search-btn" icon={<SearchOutlined />} onClick={() => { setQuery(filterForm.getFieldsValue()); message.success('已查询'); }}>查询</Button>
                <Button className="secondary-btn" onClick={() => { filterForm.resetFields(); setQuery({}); }}>重置</Button>
              </Space>
            </Col>
          </Row>
        </Form>
        <div className="facility-table-wrap">
          <Table rowKey="id" size="small" scroll={{ x: getEcoTableScrollX(allCols.filter(c => visibleCols.includes(c.key) || c.key === 'operation')) }} pagination={{ pageSize: 10, showTotal: t => `共 ${t} 条` }} columns={columns} dataSource={filtered} />
        </div>
      </Card>
      <Modal title="预案详情" open={detailOpen} onCancel={() => { setDetailOpen(false); setDetail(null); }} footer={null} width={920} destroyOnClose styles={detailModalStyles}>
        {detail && (
          <Descriptions bordered column={2} size="small" style={{ marginTop: 8 }}>
            <Descriptions.Item label="预案名称" span={2}><Text strong>{detail.name}</Text></Descriptions.Item>
            <Descriptions.Item label="预案类型">{detail.planType}</Descriptions.Item>
            <Descriptions.Item label="发布时间">{detail.publishTime}</Descriptions.Item>
            <Descriptions.Item label="编制单位" span={2}>{detail.compileOrg}</Descriptions.Item>
            <Descriptions.Item label="应急组织体系" span={2}>{detail.orgSystem}</Descriptions.Item>
            <Descriptions.Item label="响应流程" span={2}>{detail.responseFlow}</Descriptions.Item>
            <Descriptions.Item label="处置措施" span={2}>{detail.measures}</Descriptions.Item>
            <Descriptions.Item label="责任分工" span={2}>{detail.dutyDivision}</Descriptions.Item>
            <Descriptions.Item label="附件" span={2}>
              <Space>
                <Text>{detail.attachmentName}</Text>
                {detail.pdfUrl ? (
                  <>
                    <Button type="link" className="action-btn detail" href={detail.pdfUrl} target="_blank" rel="noopener noreferrer">查看</Button>
                    <Button type="link" className="action-btn detail" href={detail.pdfUrl} download={detail.attachmentName}>下载</Button>
                  </>
                ) : null}
              </Space>
            </Descriptions.Item>
          </Descriptions>
        )}
      </Modal>
      <Modal title={editing ? '编辑预案' : '新增预案'} open={editOpen} onCancel={() => { setEditOpen(false); setEditing(null); editForm.resetFields(); }} width={880} destroyOnClose styles={formModalStyles} onOk={() => void save()}>
        <Form form={editForm} layout="vertical">
          <Form.Item name="name" label="预案名称" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="planType" label="预案类型" rules={[{ required: true }]}>
            <Select options={['总体应急预案', '专项应急预案', '现场处置方案'].map(x => ({ value: x, label: x }))} />
          </Form.Item>
          <Form.Item name="publishTime" label="发布时间" rules={[{ required: true }]}><DatePicker style={{ width: '100%' }} /></Form.Item>
          <Form.Item name="compileOrg" label="编制单位" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="orgSystem" label="应急组织体系" rules={[{ required: true }]}><TextArea rows={2} /></Form.Item>
          <Form.Item name="responseFlow" label="响应流程" rules={[{ required: true }]}><TextArea rows={2} /></Form.Item>
          <Form.Item name="measures" label="处置措施" rules={[{ required: true }]}><TextArea rows={2} /></Form.Item>
          <Form.Item name="dutyDivision" label="责任分工" rules={[{ required: true }]}><TextArea rows={2} /></Form.Item>
          <Form.Item name="attachmentName" label="附件显示名称" rules={[{ required: true }]}><Input placeholder="列表与详情中展示的名称" /></Form.Item>
          <Form.Item name="pdfUrl" label="附件链接（演示可填公开 PDF 地址）" tooltip="原型阶段可填可空，空则使用演示 PDF">
            <Input placeholder="https://..." />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

// ========== 5 应急队伍（Tab：基本信息 / 人员列表）==========
export const EmergencyTeamPage: React.FC<{
  rows: EmergencyTeamRow[];
  onChange: React.Dispatch<React.SetStateAction<EmergencyTeamRow[]>>;
}> = ({ rows, onChange }) => {
  const [filterForm] = Form.useForm();
  const [editForm] = Form.useForm();
  const [memberForm] = Form.useForm();
  const [query, setQuery] = useState<Record<string, unknown>>({});
  const [detail, setDetail] = useState<EmergencyTeamRow | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [editing, setEditing] = useState<EmergencyTeamRow | null>(null);
  const [editTab, setEditTab] = useState('base');
  const [membersDraft, setMembersDraft] = useState<TeamMemberRow[]>([]);
  const [memberModalOpen, setMemberModalOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<TeamMemberRow | null>(null);

  const filtered = useMemo(() => {
    const kw = String(query.keyword ?? '').trim();
    return rows.filter(r => !kw || `${r.name}${r.specialty}${r.contactPhone}`.includes(kw));
  }, [rows, query]);

  const openEdit = (row: EmergencyTeamRow | null) => {
    setEditing(row);
    setMembersDraft(row ? [...row.members] : []);
    setEditTab('base');
    if (row) {
      editForm.setFieldsValue({
        name: row.name,
        specialty: row.specialty,
        equipment: row.equipment,
        contactPhone: row.contactPhone,
        dutyDivision: row.dutyDivision,
      });
    } else editForm.resetFields();
    setEditOpen(true);
  };

  const saveTeam = async () => {
    const v = await editForm.validateFields();
    const payload: EmergencyTeamRow = {
      id: editing?.id ?? `et-${Date.now()}`,
      name: v.name,
      specialty: v.specialty,
      equipment: v.equipment,
      contactPhone: v.contactPhone,
      dutyDivision: v.dutyDivision,
      members: membersDraft,
    };
    if (editing) onChange(prev => prev.map(r => (r.id === editing.id ? payload : r)));
    else onChange(prev => [...prev, payload]);
    message.success(editing ? '已保存' : '已新增');
    setEditOpen(false);
    setEditing(null);
    editForm.resetFields();
    setMembersDraft([]);
  };

  const saveMember = async () => {
    const v = await memberForm.validateFields();
    const m: TeamMemberRow = { id: editingMember?.id ?? `tm-${Date.now()}`, ...v };
    if (editingMember) setMembersDraft(prev => prev.map(x => (x.id === editingMember.id ? m : x)));
    else setMembersDraft(prev => [...prev, m]);
    setMemberModalOpen(false);
    setEditingMember(null);
    memberForm.resetFields();
  };

  const allCols: EcoColumnConfig[] = useMemo(
    () => [
      { key: 'name', title: '队伍名称', dataIndex: 'name', width: 220, ellipsis: true },
      { key: 'memberCount', title: '人员构成', width: 100, render: (_: unknown, r: unknown) => (r as EmergencyTeamRow).members.length },
      { key: 'specialty', title: '专业技能', dataIndex: 'specialty', ellipsis: true },
      { key: 'equipment', title: '装备配置', dataIndex: 'equipment', width: 160, ellipsis: true },
      { key: 'contactPhone', title: '联络方式', dataIndex: 'contactPhone', width: 130 },
      { key: 'dutyDivision', title: '职责分工', dataIndex: 'dutyDivision', ellipsis: true, defaultVisible: false },
      { key: 'operation', title: '操作', width: 148, defaultVisible: true },
    ],
    [],
  );
  const [visibleCols, setVisibleCols] = useState(() => getEcoDefaultVisibleColumnKeys(allCols));
  const columns = useMemo(
    () =>
      buildTableColumnsFromEcoConfig(allCols, visibleCols, record => {
        const row = record as EmergencyTeamRow;
        return (
          <Space size="small">
            <Button type="link" size="small" className="action-btn detail" icon={<EyeOutlined />} onClick={() => { setDetail(row); setDetailOpen(true); }}>详情</Button>
            <Button type="link" size="small" className="action-btn edit" icon={<EditOutlined />} onClick={() => openEdit(row)}>编辑</Button>
          </Space>
        );
      }),
    [allCols, visibleCols],
  );

  return (
    <div className="facility-view">
      <Card
        title="应急队伍信息"
        extra={
          <Space wrap>
            <EcoProtoExportBtn />
            <EcoProtoImportBtn />
            <RiskEcoColumnManager columns={allCols} visibleColumns={visibleCols} onChange={setVisibleCols} />
            <Button type="primary" icon={<PlusOutlined />} className="add-btn" onClick={() => openEdit(null)}>新增</Button>
          </Space>
        }
      >
        <Form form={filterForm} layout="vertical" style={{ marginBottom: 12 }}>
          <Row gutter={[12, 12]}>
            <Col xs={24} sm={12} md={10}>
              <Form.Item name="keyword" style={{ marginBottom: 0 }}>
                <Input allowClear placeholder="关键词：队伍名称、专长、电话" prefix={<SearchOutlined />} />
              </Form.Item>
            </Col>
            <Col xs={24} style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <Space>
                <Button type="primary" className="search-btn" icon={<SearchOutlined />} onClick={() => { setQuery(filterForm.getFieldsValue()); message.success('已查询'); }}>查询</Button>
                <Button className="secondary-btn" onClick={() => { filterForm.resetFields(); setQuery({}); }}>重置</Button>
              </Space>
            </Col>
          </Row>
        </Form>
        <div className="facility-table-wrap">
          <Table rowKey="id" size="small" scroll={{ x: getEcoTableScrollX(allCols.filter(c => visibleCols.includes(c.key) || c.key === 'operation')) }} pagination={{ pageSize: 10, showTotal: t => `共 ${t} 条` }} columns={columns} dataSource={filtered} />
        </div>
      </Card>
      <Modal title="队伍详情" open={detailOpen} onCancel={() => { setDetailOpen(false); setDetail(null); }} footer={null} width={920} destroyOnClose styles={detailModalStyles}>
        {detail && (
          <>
            <Descriptions bordered column={2} size="small" style={{ marginTop: 8, marginBottom: 16 }}>
              <Descriptions.Item label="队伍名称" span={2}><Text strong>{detail.name}</Text></Descriptions.Item>
              <Descriptions.Item label="专业技能" span={2}>{detail.specialty}</Descriptions.Item>
              <Descriptions.Item label="装备配置" span={2}>{detail.equipment}</Descriptions.Item>
              <Descriptions.Item label="联络方式">{detail.contactPhone}</Descriptions.Item>
              <Descriptions.Item label="职责分工" span={2}>{detail.dutyDivision}</Descriptions.Item>
            </Descriptions>
            <Card size="small" title="人员列表">
              <Table
                rowKey="id"
                size="small"
                pagination={false}
                dataSource={detail.members}
                columns={[
                  { title: '姓名', dataIndex: 'name' },
                  { title: '岗位/角色', dataIndex: 'role' },
                  { title: '联系电话', dataIndex: 'phone' },
                  { title: '专业技能', dataIndex: 'skill' },
                ]}
              />
            </Card>
          </>
        )}
      </Modal>
      <Modal
        title={editing ? '编辑队伍' : '新增队伍'}
        open={editOpen}
        onCancel={() => { setEditOpen(false); setEditing(null); editForm.resetFields(); setMembersDraft([]); }}
        width={880}
        destroyOnClose
        styles={formModalStyles}
        footer={
          <Space>
            <Button className="secondary-btn" onClick={() => { setEditOpen(false); setEditing(null); editForm.resetFields(); setMembersDraft([]); }}>取消</Button>
            <Button type="primary" onClick={() => void saveTeam()}>保存</Button>
          </Space>
        }
      >
        <Tabs activeKey={editTab} onChange={setEditTab} size="small" className="facility-detail-tabs" items={[
          {
            key: 'base',
            label: '基本信息',
            children: (
              <Form form={editForm} layout="vertical" style={{ marginTop: 8 }}>
                <Form.Item name="name" label="队伍名称" rules={[{ required: true }]}><Input /></Form.Item>
                <Form.Item name="specialty" label="专业技能" rules={[{ required: true }]}><TextArea rows={2} /></Form.Item>
                <Form.Item name="equipment" label="装备配置" rules={[{ required: true }]}><TextArea rows={2} /></Form.Item>
                <Form.Item name="contactPhone" label="联络方式" rules={[{ required: true }]}><Input /></Form.Item>
                <Form.Item name="dutyDivision" label="职责分工" rules={[{ required: true }]}><TextArea rows={2} /></Form.Item>
              </Form>
            ),
          },
          {
            key: 'members',
            label: '人员列表',
            children: (
              <div style={{ marginTop: 8 }}>
                <Space style={{ marginBottom: 12 }}>
                  <Button type="primary" icon={<PlusOutlined />} className="add-btn" onClick={() => { setEditingMember(null); memberForm.resetFields(); setMemberModalOpen(true); }}>添加人员</Button>
                </Space>
                <Table
                  rowKey="id"
                  size="small"
                  dataSource={membersDraft}
                  columns={[
                    { title: '姓名', dataIndex: 'name' },
                    { title: '岗位/角色', dataIndex: 'role' },
                    { title: '联系电话', dataIndex: 'phone' },
                    { title: '专业技能', dataIndex: 'skill' },
                    {
                      title: '操作',
                      width: 120,
                      render: (_: unknown, r: TeamMemberRow) => (
                        <Space>
                          <Button type="link" size="small" className="action-btn edit" onClick={() => { setEditingMember(r); memberForm.setFieldsValue(r); setMemberModalOpen(true); }}>编辑</Button>
                          <Popconfirm title="删除该人员？" onConfirm={() => setMembersDraft(prev => prev.filter(x => x.id !== r.id))}>
                            <Button type="link" size="small" className="action-btn delete" danger>删除</Button>
                          </Popconfirm>
                        </Space>
                      ),
                    },
                  ]}
                />
              </div>
            ),
          },
        ]}
        />
      </Modal>
      <Modal title={editingMember ? '编辑人员' : '添加人员'} open={memberModalOpen} onCancel={() => { setMemberModalOpen(false); setEditingMember(null); memberForm.resetFields(); }} onOk={() => void saveMember()} width={560} destroyOnClose styles={formModalStyles}>
        <Form form={memberForm} layout="vertical">
          <Form.Item name="name" label="姓名" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="role" label="岗位/角色" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="phone" label="联系电话" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="skill" label="专业技能" rules={[{ required: true }]}><Input /></Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

// ========== 6 专家库 ==========
export const ExpertPage: React.FC<{
  rows: ExpertRow[];
  onChange: React.Dispatch<React.SetStateAction<ExpertRow[]>>;
}> = ({ rows, onChange }) => {
  const [filterForm] = Form.useForm();
  const [editForm] = Form.useForm();
  const [query, setQuery] = useState<Record<string, unknown>>({});
  const [detail, setDetail] = useState<ExpertRow | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [editing, setEditing] = useState<ExpertRow | null>(null);

  const filtered = useMemo(() => {
    const kw = String(query.keyword ?? '').trim();
    return rows.filter(r => !kw || `${r.name}${r.expertise}${r.org}`.includes(kw));
  }, [rows, query]);

  const allCols: EcoColumnConfig[] = useMemo(
    () => [
      { key: 'name', title: '姓名', dataIndex: 'name', width: 100 },
      { key: 'expertise', title: '擅长方向', dataIndex: 'expertise', ellipsis: true },
      { key: 'background', title: '专业背景', dataIndex: 'background', ellipsis: true, defaultVisible: false },
      { key: 'org', title: '单位', dataIndex: 'org', ellipsis: true },
      { key: 'title', title: '职称', dataIndex: 'title', width: 100 },
      { key: 'phone', title: '联系方式', dataIndex: 'phone', width: 130 },
      { key: 'operation', title: '操作', width: 148, defaultVisible: true },
    ],
    [],
  );
  const [visibleCols, setVisibleCols] = useState(() => getEcoDefaultVisibleColumnKeys(allCols));
  const columns = useMemo(
    () =>
      buildTableColumnsFromEcoConfig(allCols, visibleCols, record => {
        const row = record as ExpertRow;
        return (
          <Space size="small">
            <Button type="link" size="small" className="action-btn detail" icon={<EyeOutlined />} onClick={() => { setDetail(row); setDetailOpen(true); }}>详情</Button>
            <Button type="link" size="small" className="action-btn edit" icon={<EditOutlined />} onClick={() => { setEditing(row); editForm.setFieldsValue(row); setEditOpen(true); }}>编辑</Button>
          </Space>
        );
      }),
    [allCols, visibleCols, editForm],
  );

  const save = async () => {
    const v = await editForm.validateFields();
    const payload: ExpertRow = { id: editing?.id ?? `ex-${Date.now()}`, ...v };
    if (editing) onChange(prev => prev.map(r => (r.id === editing.id ? payload : r)));
    else onChange(prev => [...prev, payload]);
    message.success(editing ? '已保存' : '已新增');
    setEditOpen(false);
    setEditing(null);
    editForm.resetFields();
  };

  return (
    <div className="facility-view">
      <Card
        title="应急专家库"
        extra={
          <Space wrap>
            <EcoProtoExportBtn />
            <EcoProtoImportBtn />
            <RiskEcoColumnManager columns={allCols} visibleColumns={visibleCols} onChange={setVisibleCols} />
            <Button type="primary" icon={<PlusOutlined />} className="add-btn" onClick={() => { setEditing(null); editForm.resetFields(); setEditOpen(true); }}>新增</Button>
          </Space>
        }
      >
        <Form form={filterForm} layout="vertical" style={{ marginBottom: 12 }}>
          <Row gutter={[12, 12]}>
            <Col xs={24} sm={12} md={10}>
              <Form.Item name="keyword" style={{ marginBottom: 0 }}>
                <Input allowClear placeholder="关键词：姓名、擅长方向、单位" prefix={<SearchOutlined />} />
              </Form.Item>
            </Col>
            <Col xs={24} style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <Space>
                <Button type="primary" className="search-btn" icon={<SearchOutlined />} onClick={() => { setQuery(filterForm.getFieldsValue()); message.success('已查询'); }}>查询</Button>
                <Button className="secondary-btn" onClick={() => { filterForm.resetFields(); setQuery({}); }}>重置</Button>
              </Space>
            </Col>
          </Row>
        </Form>
        <div className="facility-table-wrap">
          <Table rowKey="id" size="small" scroll={{ x: getEcoTableScrollX(allCols.filter(c => visibleCols.includes(c.key) || c.key === 'operation')) }} pagination={{ pageSize: 10, showTotal: t => `共 ${t} 条` }} columns={columns} dataSource={filtered} />
        </div>
      </Card>
      <Modal title="专家详情" open={detailOpen} onCancel={() => { setDetailOpen(false); setDetail(null); }} footer={null} width={720} destroyOnClose styles={detailModalStyles}>
        {detail && (
          <Descriptions bordered column={2} size="small" style={{ marginTop: 8 }}>
            <Descriptions.Item label="姓名" span={2}><Text strong>{detail.name}</Text></Descriptions.Item>
            <Descriptions.Item label="单位">{detail.org}</Descriptions.Item>
            <Descriptions.Item label="职称">{detail.title}</Descriptions.Item>
            <Descriptions.Item label="擅长方向" span={2}>{detail.expertise}</Descriptions.Item>
            <Descriptions.Item label="专业背景" span={2}>{detail.background}</Descriptions.Item>
            <Descriptions.Item label="联系方式">{detail.phone}</Descriptions.Item>
          </Descriptions>
        )}
      </Modal>
      <Modal title={editing ? '编辑专家' : '新增专家'} open={editOpen} onCancel={() => { setEditOpen(false); setEditing(null); editForm.resetFields(); }} width={720} destroyOnClose styles={formModalStyles} onOk={() => void save()}>
        <Form form={editForm} layout="vertical">
          <Form.Item name="name" label="姓名" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="org" label="单位" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="title" label="职称" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="expertise" label="擅长方向" rules={[{ required: true }]}><TextArea rows={2} /></Form.Item>
          <Form.Item name="background" label="专业背景" rules={[{ required: true }]}><TextArea rows={3} /></Form.Item>
          <Form.Item name="phone" label="联系方式" rules={[{ required: true }]}><Input /></Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

// ========== 路由 ==========
export type RiskMenuKey =
  | 'risk-enterprise'
  | 'emergency-supply'
  | 'social-supply'
  | 'emergency-plan'
  | 'emergency-team'
  | 'expert';

export const RiskIdentificationRouter: React.FC<{
  activeSubMenu: RiskMenuKey;
  data: RiskDataBundle;
  setData: React.Dispatch<React.SetStateAction<RiskDataBundle>>;
}> = ({ activeSubMenu, data, setData }) => {
  const setEnterprises = useCallback((u: React.SetStateAction<RiskEnterpriseRow[]>) => {
    setData(d => ({ ...d, enterprises: typeof u === 'function' ? u(d.enterprises) : u }));
  }, [setData]);
  const setSocial = useCallback((u: React.SetStateAction<SocialSupplyPointRow[]>) => {
    setData(d => ({ ...d, socialPoints: typeof u === 'function' ? u(d.socialPoints) : u }));
  }, [setData]);
  const setSupplies = useCallback((u: React.SetStateAction<EmergencySupplyRow[]>) => {
    setData(d => ({ ...d, supplies: typeof u === 'function' ? u(d.supplies) : u }));
  }, [setData]);
  const setPlans = useCallback((u: React.SetStateAction<EmergencyPlanRow[]>) => {
    setData(d => ({ ...d, plans: typeof u === 'function' ? u(d.plans) : u }));
  }, [setData]);
  const setTeams = useCallback((u: React.SetStateAction<EmergencyTeamRow[]>) => {
    setData(d => ({ ...d, teams: typeof u === 'function' ? u(d.teams) : u }));
  }, [setData]);
  const setExperts = useCallback((u: React.SetStateAction<ExpertRow[]>) => {
    setData(d => ({ ...d, experts: typeof u === 'function' ? u(d.experts) : u }));
  }, [setData]);

  switch (activeSubMenu) {
    case 'risk-enterprise':
      return <RiskEnterprisePage rows={data.enterprises} onChange={setEnterprises} />;
    case 'emergency-supply':
      return <EmergencySupplyPage rows={data.supplies} socialPoints={data.socialPoints} onChange={setSupplies} />;
    case 'social-supply':
      return <SocialSupplyPointPage rows={data.socialPoints} supplies={data.supplies} onChange={setSocial} />;
    case 'emergency-plan':
      return <EmergencyPlanPage rows={data.plans} onChange={setPlans} />;
    case 'emergency-team':
      return <EmergencyTeamPage rows={data.teams} onChange={setTeams} />;
    case 'expert':
      return <ExpertPage rows={data.experts} onChange={setExperts} />;
    default:
      return null;
  }
};
