/**
 * @name 应急协同
 * 应急协同 — 风险识别台账 + 应急事件信息 + 事件评估（侧栏与样式对齐「生态整治」设施管理）
 */
import './style.css';
import { DetailTabsIfMultiple } from '../shared/detailTabsIfMultiple';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import dayjs from 'dayjs';
import zhCN from 'antd/locale/zh_CN';
import {
  ConfigProvider,
  Layout,
  Card,
  Row,
  Col,
  Table,
  Tag,
  Button,
  Input,
  Select,
  Space,
  Typography,
  Modal,
  Form,
  message,
  Popconfirm,
  Descriptions,
  Checkbox,
  Divider,
  Dropdown,
  Tooltip,
  Upload,
  Empty,
  DatePicker,
  Tabs,
  Image,
} from 'antd';
import type { UploadFile } from 'antd';
import {
  ColumnHeightOutlined,
  SearchOutlined,
  PlusOutlined,
  DownloadOutlined,
  UploadOutlined,
  EditOutlined,
  EyeOutlined,
  DownOutlined,
  AlertOutlined,
  FileTextOutlined,
  EnvironmentOutlined,
} from '@ant-design/icons';
import type { ColumnsType } from 'antd/es/table';
import type { FormInstance } from 'antd/es/form';
import { initialLakeWaterBodyData, initialRiverChannelMasterData } from '../生态整治/riverChiefDb4401';
import { initialRiskData, RiskIdentificationRouter, type RiskMenuKey } from './riskIdentification';
import { EventReviewPage, initialEventReviews } from './eventReview';
import { EmergencyEventDetailMap } from './emergencyEventDetailMap';
import { EmergencyEventFormMap } from './emergencyEventFormMap';

const { Content } = Layout;
const { Text, Paragraph } = Typography;
const { TextArea } = Input;
const { RangePicker } = DatePicker;

const formModalStyles = {
  body: {
    maxHeight: 'calc(100vh - 240px)',
    overflowY: 'auto' as const,
    overflowX: 'hidden' as const,
    minWidth: 0,
  },
};

/** 只读详情弹窗：与生态整治一致，内容区可滚动区域略增高 */
const detailModalStyles = {
  ...formModalStyles,
  body: { ...formModalStyles.body, maxHeight: 'min(85vh, 900px)', overflowY: 'auto' as const },
};

// ========== 表格字段管理（与生态整治一致） ==========
interface EcoColumnConfig {
  key: string;
  title: React.ReactNode;
  columnManagerLabel?: string;
  dataIndex?: string;
  width?: number;
  fixed?: 'left' | 'right';
  render?: (value: unknown, record: unknown) => React.ReactNode;
  defaultVisible?: boolean;
}

interface EcoColumnManagerProps {
  columns: EcoColumnConfig[];
  visibleColumns: string[];
  onChange: (visibleColumns: string[]) => void;
}

const EcoColumnManager: React.FC<EcoColumnManagerProps> = ({ columns, visibleColumns, onChange }) => {
  const [open, setOpen] = useState(false);
  const [isSortMode, setIsSortMode] = useState(false);

  const handleToggleColumn = (key: string, checked: boolean) => {
    if (checked) onChange([...visibleColumns, key]);
    else {
      if (key === 'operation') {
        message.warning('操作列不可隐藏');
        return;
      }
      onChange(visibleColumns.filter(k => k !== key));
    }
  };

  const handleReset = () => {
    onChange(columns.filter(c => c.key !== 'operation' && c.defaultVisible !== false).map(c => c.key));
    message.success('已重置为默认显示');
  };

  const sortableColumns = visibleColumns.filter(key => key !== 'operation');
  const handleMoveUp = (index: number) => {
    if (index <= 0) return;
    const newOrder = [...visibleColumns];
    [newOrder[index], newOrder[index - 1]] = [newOrder[index - 1], newOrder[index]];
    onChange(newOrder);
  };
  const handleMoveDown = (index: number) => {
    if (index >= sortableColumns.length - 1) return;
    const newOrder = [...visibleColumns];
    [newOrder[index], newOrder[index + 1]] = [newOrder[index + 1], newOrder[index]];
    onChange(newOrder);
  };

  const dropdownContent = (
    <Card
      title={
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span>字段管理</span>
          <Button type="link" size="small" onClick={() => setIsSortMode(!isSortMode)}>
            {isSortMode ? '完成排序' : '排序'}
          </Button>
        </div>
      }
      style={{ width: isSortMode ? 360 : 320 }}
      size="small"
    >
      <div style={{ maxHeight: 400, overflow: 'auto' }}>
        {isSortMode ? (
          <>
            {sortableColumns.map((key, index) => {
              const col = columns.find(c => c.key === key);
              const sortLabel =
                col?.columnManagerLabel ?? (typeof col?.title === 'string' ? col.title : col?.key ?? key);
              return (
                <div
                  key={key}
                  style={{ display: 'flex', alignItems: 'center', padding: '8px 0', borderBottom: '1px solid #f0f0f0' }}
                >
                  <span style={{ flex: 1 }}>{sortLabel}</span>
                  <Space>
                    <Button type="text" size="small" disabled={index === 0} onClick={() => handleMoveUp(index)}>
                      ↑
                    </Button>
                    <Button
                      type="text"
                      size="small"
                      disabled={index === sortableColumns.length - 1}
                      onClick={() => handleMoveDown(index)}
                    >
                      ↓
                    </Button>
                  </Space>
                </div>
              );
            })}
          </>
        ) : (
          columns.map(col => (
            <div key={col.key} style={{ marginBottom: 8 }}>
              <Checkbox
                checked={col.key === 'operation' || visibleColumns.includes(col.key)}
                onChange={e => handleToggleColumn(col.key, e.target.checked)}
                disabled={col.key === 'operation'}
              >
                <Space>
                  {col.columnManagerLabel ?? (typeof col.title === 'string' ? col.title : col.key)}
                  {col.key === 'operation' && (
                    <Tag color="blue" style={{ fontSize: 10 }}>
                      固定
                    </Tag>
                  )}
                </Space>
              </Checkbox>
            </div>
          ))
        )}
      </div>
      {!isSortMode && (
        <>
          <Divider style={{ margin: '12px 0' }} />
          <Button type="link" onClick={handleReset} size="small">
            恢复默认
          </Button>
        </>
      )}
    </Card>
  );

  return (
    <Dropdown
      open={open}
      popupRender={() => dropdownContent}
      placement="bottomRight"
      onOpenChange={visible => {
        setOpen(visible);
        if (!visible) setIsSortMode(false);
      }}
    >
      <Tooltip title="字段管理">
        <Button icon={<ColumnHeightOutlined />}>字段</Button>
      </Tooltip>
    </Dropdown>
  );
};

const getEcoDefaultVisibleColumnKeys = (cols: EcoColumnConfig[]): string[] =>
  cols.filter(c => c.key !== 'operation' && c.defaultVisible !== false).map(c => c.key);

const ECO_DEFAULT_COL_WIDTH = 120;
function getEcoTableScrollX(cols: { width?: number }[]): number {
  const total = cols.reduce(
    (sum, c) => sum + (typeof c.width === 'number' ? c.width : ECO_DEFAULT_COL_WIDTH),
    0,
  );
  return Math.max(total, 100);
}

const ECO_ELLIPSIS = new Set([
  'eventTitle',
  'eventCode',
  'location',
  'pollutionType',
  'problemType',
  'problemSource',
  'sectionCode',
  'responsibleParty',
  'assessmentCode',
]);

const EcoProtoExportBtn = ({ onClick }: { onClick?: () => void }) => (
  <Button icon={<DownloadOutlined />} className="export-btn" onClick={onClick ?? (() => message.success('已导出'))}>
    导出
  </Button>
);

const EcoProtoImportBtn = () => (
  <Upload
    beforeUpload={() => {
      message.success('已导入');
      return false;
    }}
    showUploadList={false}
  >
    <Button icon={<UploadOutlined />} className="secondary-btn">导入</Button>
  </Upload>
);

function buildTableColumnsFromEcoConfig(
  allCols: EcoColumnConfig[],
  visibleKeys: string[],
  operationRender: (record: unknown) => React.ReactNode,
): ColumnsType<unknown> {
  return allCols
    .filter(col => visibleKeys.includes(col.key) || col.key === 'operation')
    .sort((a, b) => {
      if (a.key === 'operation') return 1;
      if (b.key === 'operation') return -1;
      return visibleKeys.indexOf(a.key) - visibleKeys.indexOf(b.key);
    })
    .map(col => {
      if (col.key === 'operation') {
        const { defaultVisible: _d, ...opRest } = col;
        return {
          ...opRest,
          fixed: 'right' as const,
          render: (_: unknown, record: unknown) => operationRender(record),
        };
      }
      const ellipsis = typeof col.dataIndex === 'string' && ECO_ELLIPSIS.has(col.dataIndex);
      const { defaultVisible: _dv, ...rest } = col;
      return { ...rest, ...(ellipsis ? { ellipsis: true } : {}) };
    }) as ColumnsType<unknown>;
}

// ========== 业务类型与常量 ==========
export interface EmergencyEventDisposal {
  contactPhone: string;
  disposalDescribe: string;
  completedTime: string;
  images: string[];
}

export interface EmergencyEventRow {
  id: string;
  eventCode: string;
  eventTitle: string;
  sectionCode: string;
  problemType: string;
  problemSource: string;
  occurTime: string;
  reportTime: string;
  addvcd: string;
  region: string;
  location: string;
  longitude: string;
  latitude: string;
  situationDescribe: string;
  pollutionType: string;
  impactScope: string;
  cause: string;
  pollutionLevel: string;
  warningLevel: string;
  reporterName: string;
  reporterPhone: string;
  inchargePerson: string;
  responsibleParty: string;
  nativeProcessing: string;
  disposalStatus: string;
  disposalProgress: string;
  measuresTaken: string;
  teamsUsage: string;
  materialsUsage: string;
  waterRecovery: string;
  eventResult: string;
  endDate: string;
  /** 基本信息-事件现场/佐证图（data URL） */
  eventImages: string[];
  eventDisposal: EmergencyEventDisposal;
}

export interface EventAssessmentRow {
  id: string;
  linkedEventId: string;
  assessmentCode: string;
  assessTime: string;
  assessOrg: string;
  overallAssessment: string;
  personnelDamage: string;
  propertyDamage: string;
  pollutionDamageAssessment: string;
  ecoDamageAssessment: string;
  pdfUrl: string | null;
  attachmentFileName: string;
}

const POLLUTION_LEVEL_OPTIONS = ['特别重大', '重大', '较大', '一般'] as const;
const WARNING_LEVEL_OPTIONS = ['红色', '橙色', '黄色', '蓝色'] as const;
const DISPOSAL_STATUS_OPTIONS = ['接报核实', '响应启动', '现场处置', '污染控制', '应急终止', '后期跟踪'] as const;
const REPORT_PROBLEM_TYPE_OPTIONS = [
  '工业废水排放',
  '养殖污染',
  '排水设施',
  '违法建设',
  '农家乐',
  '建筑废弃物',
  '堆场码头',
  '工程维护',
  '生活垃圾',
  '其他',
  '水体污染（含突发）',
] as const;
const REPORT_PROBLEM_SOURCE_OPTIONS = [
  '河长制应用',
  '电话投诉',
  '微信相关',
  '省平台推送',
  '舆情处理',
  '媒体曝光',
  '暗访处理',
  '巡查发现',
  '监测预警',
] as const;
const NATIVE_PROCESSING_OPTIONS = ['是', '否'] as const;
/** 所属区域：韶山市下辖乡镇（街道），与生态整治河道水体主数据地域一致 */
const SHAOSHAN_SUB_REGION_OPTIONS = ['清溪镇', '银田镇', '韶山乡', '杨林乡'] as const;

/** 河段或湖泊编码：与生态整治「河湖长制 — 河道水体」河流/湖泊主数据 `riverObjectId` / `lakeObjectId` 同源下拉 */
const RIVER_LAKE_SECTION_SELECT_OPTIONS = [
  ...initialRiverChannelMasterData.map(r => ({
    value: r.riverObjectId,
    label: `${r.riverName}（河流 · ${r.riverObjectId}）`,
  })),
  ...initialLakeWaterBodyData.map(l => ({
    value: l.lakeObjectId,
    label: `${l.lakeName}（湖泊 · ${l.lakeObjectId}）`,
  })),
];

function getRiverLakeSectionLabel(code: string): string {
  const o = RIVER_LAKE_SECTION_SELECT_OPTIONS.find(x => x.value === code);
  return o?.label ?? code;
}

const pollutionLevelColor: Record<string, string> = { 特别重大: 'magenta', 重大: 'red', 较大: 'orange', 一般: 'blue' };
const warningLevelColor: Record<string, string> = { 红色: 'red', 橙色: 'orange', 黄色: 'gold', 蓝色: 'blue' };
const disposalStatusColor: Record<string, string> = {
  接报核实: 'default',
  响应启动: 'processing',
  现场处置: 'warning',
  污染控制: 'orange',
  应急终止: 'success',
  后期跟踪: 'cyan',
};

const DEMO_PLAN_PDF_URL = 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf';

/** 事件评估附件：原型本地，单文件体积上限 */
const ASSESSMENT_ATTACH_MAX_MB = 20;
const ASSESSMENT_ATTACH_ACCEPT = '.pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document';

const initialEmergencyEvents: EmergencyEventRow[] = [
  {
    id: 'evt-1',
    eventCode: '水应〔2025〕0312-01',
    eventTitle: '湘江湘潭段不明油污带漂移',
    sectionCode: 'ROV-AHD030212-XJ-MAIN',
    problemType: '水体污染（含突发）',
    problemSource: '监测预警',
    occurTime: '2025-03-12 06:40',
    reportTime: '2025-03-12 07:05',
    addvcd: '',
    region: '清溪镇',
    location: '湘江干流湘潭四桥上游约 1.2 千米水域',
    longitude: '112.942000',
    latitude: '27.831000',
    situationDescribe: '巡查与在线监测发现江面带状油膜，伴轻微异味，下游为饮用水源敏感区。',
    pollutionType: '石油类、水面油膜',
    impactScope: '约 3.5 千米河段水质感官异常，下游一水厂取水口上游 8 千米',
    pollutionLevel: '较大',
    warningLevel: '橙色',
    cause: '疑似过往船舶违规排油或陆上含油废水入江，具体溯源调查中',
    reporterName: '值班员甲',
    reporterPhone: '0731-12369',
    inchargePerson: '周某（现场指挥）',
    responsibleParty: '市生态环境局牵头，海事、水利、卫健按预案分工',
    nativeProcessing: '否',
    disposalStatus: '现场处置',
    disposalProgress: '已完成围控与吸油毡铺设，加密断面监测 6 次，漂移团逐步消解',
    measuresTaken: '启动应急响应；海事通航管制；布设围油栏；投加吸油毡；饮用水加密监测',
    teamsUsage: '市生态环境应急救援一队（现场指挥与监测）、海事巡逻艇两艘、消防水域分队备勤',
    materialsUsage: '吸油毡约 120 平方米、围油栏 800 米、便携式多参数仪 4 台套',
    waterRecovery: '事发 48 小时内特征指标回落至背景值区间，取水口未检出异常',
    eventResult: '未造成供水中断；污染源初步锁定为通航密集区，案件移交海事与公安进一步侦办',
    endDate: '2025-03-15',
    eventImages: [],
    eventDisposal: {
      contactPhone: '0731-12345',
      disposalDescribe: '快检数据回传稳定，漂移团消解，向卫健部门通报水厂源水监测结果',
      completedTime: '2025-03-12 18:00',
      images: [],
    },
  },
  {
    id: 'evt-2',
    eventCode: '水应〔2025〕0128-02',
    eventTitle: '韶山河流域暴雨后面源高浊度冲击',
    sectionCode: 'LK-430382-QNSK-001',
    problemType: '其他',
    problemSource: '巡查发现',
    occurTime: '2025-01-28 14:20',
    reportTime: '2025-01-28 14:35',
    addvcd: '',
    region: '银田镇',
    location: '韶河清溪段与支流汇合口下游',
    longitude: '112.526000',
    latitude: '27.915000',
    situationDescribe: '强降雨后支流汇口下游水体浑浊度骤升，农灌取水户反映感官异常。',
    pollutionType: '高浊度、泥沙及面源冲刷',
    impactScope: '支流汇入口以下约 6 千米，对下游河道景观与局部农灌取水有影响',
    pollutionLevel: '一般',
    warningLevel: '黄色',
    cause: '短时强降雨导致周边施工场地与农田径流集中入河',
    reporterName: '乡镇网格员乙',
    reporterPhone: '0732-55×××××',
    inchargePerson: '县级分局现场负责人',
    responsibleParty: '韶山市人民政府组织，生态环境分局综合协调',
    nativeProcessing: '是',
    disposalStatus: '后期跟踪',
    disposalProgress: '已终止应急响应，开展河床淤积巡查与管网排查',
    measuresTaken: '加密悬浮物与化学需氧量监测；临时导流与沉淀；对施工点下达整改通知',
    teamsUsage: '县级生态环境分局现场组、乡镇网格员、第三方检测公司',
    materialsUsage: '应急沙袋 200 个、抽水泵 3 台、快检试剂若干',
    waterRecovery: '72 小时后浊度恢复至同期历史区间，未对县级集中式饮用水源构成风险',
    eventResult: '事件闭环，形成复盘简报一份，纳入汛前面源管控清单',
    endDate: '2025-02-10',
    eventImages: [],
    eventDisposal: {
      contactPhone: '0732-55×××××',
      disposalDescribe: '派员复核并指导筑堰导流，责令施工点限期整改',
      completedTime: '2025-01-28 17:00',
      images: [],
    },
  },
];

const initialEventAssessments: EventAssessmentRow[] = [
  {
    id: 'asr-1',
    linkedEventId: 'evt-1',
    assessmentCode: 'PG-2025-0315-01',
    assessTime: '2025-03-15',
    assessOrg: '市生态环境局应急科、省环科院水环境所（联合）',
    overallAssessment:
      '本次事件为水上漂移态石油类污染，响应及时，围控与吸附措施有效，敏感目标（饮用水源）未受实质影响。',
    personnelDamage: '无人员伤亡报告；现场及应急人员完成健康问询。',
    propertyDamage: '直接损失主要为应急物资消耗与监测费用。',
    pollutionDamageAssessment: '石油类峰值出现在事发下游断面，48h 内回落至评价标准内。',
    ecoDamageAssessment: '浮游生物短期波动在可接受范围。',
    pdfUrl: DEMO_PLAN_PDF_URL,
    attachmentFileName: '事件评估报告-SJ油污-20250315.pdf',
  },
];

/** 多图上传（data URL），用于「事件图片」「处置图片」等 */
const EVENT_RECORD_IMAGE_MAX_COUNT = 12;
const EVENT_RECORD_IMAGE_MAX_MB = 5;
const EVENT_RECORD_IMAGE_ACCEPT = 'image/jpeg,image/png,image/webp,image/gif';

interface DataUrlImageCardUploadProps {
  value?: string[];
  onChange?: (v: string[]) => void;
  /** 用于列表项 uid 前缀，避免多实例同索引冲突 */
  listKey: string;
  /** 列表展示文件名前缀 */
  fileNamePrefix: string;
  uploadLabel: string;
}

const DataUrlImageCardUpload: React.FC<DataUrlImageCardUploadProps> = ({
  value,
  onChange,
  listKey,
  fileNamePrefix,
  uploadLabel,
}) => {
  const urls = value ?? [];
  const urlsRef = useRef(urls);
  urlsRef.current = urls;

  const fileList: UploadFile[] = useMemo(
    () =>
      urls.map((url, i) => ({
        uid: `${listKey}-${i}-${url.length}-${url.slice(22, 38)}`,
        name: `${fileNamePrefix}-${String(i + 1).padStart(2, '0')}.jpg`,
        status: 'done',
        url,
      })),
    [urls, listKey, fileNamePrefix],
  );

  const beforeUpload = useCallback(
    (file: File) => {
      const allowedMime = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
      const extOk = /\.(jpe?g|png|webp|gif)$/i.test(file.name);
      const typeOk = file.type ? allowedMime.includes(file.type) : extOk;
      if (!typeOk) {
        message.error('仅支持 JPG、PNG、WebP、GIF 格式');
        return Upload.LIST_IGNORE;
      }
      const maxBytes = EVENT_RECORD_IMAGE_MAX_MB * 1024 * 1024;
      if (file.size > maxBytes) {
        message.error(`单张图片不能超过 ${EVENT_RECORD_IMAGE_MAX_MB}MB`);
        return Upload.LIST_IGNORE;
      }
      if (urlsRef.current.length >= EVENT_RECORD_IMAGE_MAX_COUNT) {
        message.warning(`最多上传 ${EVENT_RECORD_IMAGE_MAX_COUNT} 张图片`);
        return Upload.LIST_IGNORE;
      }

      return new Promise<boolean | typeof Upload.LIST_IGNORE>(resolve => {
        const reader = new FileReader();
        reader.onload = () => {
          const dataUrl = reader.result;
          if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image')) {
            message.error('图片解析失败，请换一张重试');
            resolve(Upload.LIST_IGNORE);
            return;
          }
          const next = [...urlsRef.current, dataUrl];
          urlsRef.current = next;
          onChange?.(next);
          resolve(false);
        };
        reader.onerror = () => {
          message.error('读取文件失败，请重试');
          resolve(Upload.LIST_IGNORE);
        };
        reader.readAsDataURL(file);
      });
    },
    [onChange],
  );

  const onRemove = useCallback(
    (file: UploadFile) => {
      const idx = fileList.findIndex(f => f.uid === file.uid);
      if (idx < 0) return;
      const next = urlsRef.current.filter((_, i) => i !== idx);
      urlsRef.current = next;
      onChange?.(next);
    },
    [fileList, onChange],
  );

  return (
    <div className="data-url-image-card-upload">
      <Upload
        listType="picture-card"
        accept={EVENT_RECORD_IMAGE_ACCEPT}
        multiple
        maxCount={EVENT_RECORD_IMAGE_MAX_COUNT}
        fileList={fileList}
        beforeUpload={beforeUpload}
        onRemove={onRemove}
      >
        {fileList.length >= EVENT_RECORD_IMAGE_MAX_COUNT ? null : (
          <div>
            <PlusOutlined />
            <div style={{ marginTop: 8 }}>{uploadLabel}</div>
          </div>
        )}
      </Upload>
    </div>
  );
};

/** 事件编号：水应〔年〕MMDD-序号，按当日已有编号递增（保存时生成） */
function generateNextEventCode(events: EmergencyEventRow[]): string {
  const d = dayjs();
  const y = d.format('YYYY');
  const md = d.format('MMDD');
  const prefix = `水应〔${y}〕${md}-`;
  let max = 0;
  for (const e of events) {
    if (!e.eventCode.startsWith(prefix)) continue;
    const suf = e.eventCode.slice(prefix.length);
    const n = parseInt(suf, 10);
    if (!Number.isNaN(n)) max = Math.max(max, n);
  }
  return `${prefix}${String(max + 1).padStart(2, '0')}`;
}

/** 基本信息：MapLibre 地图选点；事发地点、经度、纬度联动 */
const EmergencyMapLocationPicker: React.FC<{ form: FormInstance }> = ({ form }) => {
  const lngWatch = Form.useWatch('longitude', form);
  const latWatch = Form.useWatch('latitude', form);
  const locWatch = Form.useWatch('location', form);
  return (
    <EmergencyEventFormMap
      longitude={String(lngWatch ?? '').trim()}
      latitude={String(latWatch ?? '').trim()}
      location={String(locWatch ?? '').trim()}
      onFormSync={patch => {
        form.setFieldsValue(patch);
      }}
    />
  );
};

// ========== 应急事件信息 ==========
interface EmergencyEventInfoPageProps {
  events: EmergencyEventRow[];
  onEventsChange: React.Dispatch<React.SetStateAction<EmergencyEventRow[]>>;
  /** 用于详情弹窗「事件评估」页签展示关联记录 */
  assessments: EventAssessmentRow[];
}

const EmergencyEventInfoPage: React.FC<EmergencyEventInfoPageProps> = ({ events: rows, onEventsChange: setRows, assessments }) => {
  const [filterForm] = Form.useForm();
  const [editForm] = Form.useForm();
  const [query, setQuery] = useState<Record<string, unknown>>({});
  const [detail, setDetail] = useState<EmergencyEventRow | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [editing, setEditing] = useState<EmergencyEventRow | null>(null);
  const [eventEditTab, setEventEditTab] = useState('basic');
  /** 详情-事件评估：多条关联时选中的评估 id */
  const [detailAssessmentPickId, setDetailAssessmentPickId] = useState<string | null>(null);

  const closeEdit = useCallback(() => {
    setEditOpen(false);
    setEditing(null);
    editForm.resetFields();
    setEventEditTab('basic');
  }, [editForm]);

  /** 打开编辑弹窗并填充行数据；`tab` 为 disposal 时用于「处置上报」快速进入事件处置 */
  const openEventEdit = useCallback(
    (row: EmergencyEventRow, tab: 'basic' | 'disposal') => {
      setEditing(row);
      setEventEditTab(tab);
      editForm.setFieldsValue({
        ...row,
        occurTime: dayjs(row.occurTime),
        reportTime: dayjs(row.reportTime),
        endDate: row.endDate ? dayjs(row.endDate) : undefined,
        eventImages: Array.isArray(row.eventImages) ? row.eventImages : [],
        eventDisposal: {
          ...(row.eventDisposal ?? { contactPhone: '', disposalDescribe: '', completedTime: '', images: [] }),
          completedTime: row.eventDisposal?.completedTime ? dayjs(row.eventDisposal.completedTime) : undefined,
          images: Array.isArray(row.eventDisposal?.images) ? row.eventDisposal!.images : [],
        },
      });
      setEditOpen(true);
    },
    [editForm],
  );

  /** 详情弹窗展示用：与列表 rows 同源，编辑保存后地图与经纬度等与表格一致 */
  const detailDisplay = useMemo(
    () => (detail ? rows.find(r => r.id === detail.id) ?? detail : null),
    [detail, rows],
  );

  const detailLinkedAssessments = useMemo(
    () => (detailDisplay ? assessments.filter(a => a.linkedEventId === detailDisplay.id) : []),
    [assessments, detailDisplay],
  );

  const selectedDetailAssessment = useMemo(() => {
    if (detailLinkedAssessments.length === 0) return null;
    if (detailAssessmentPickId) {
      return detailLinkedAssessments.find(a => a.id === detailAssessmentPickId) ?? detailLinkedAssessments[0];
    }
    return detailLinkedAssessments[0];
  }, [detailLinkedAssessments, detailAssessmentPickId]);

  const filtered = useMemo(() => {
    const keyword = String(query.keyword ?? '').trim();
    const region = query.region as string | undefined;
    const disposalStatus = query.disposalStatus as string | undefined;
    const pollutionLevel = query.pollutionLevel as string | undefined;
    const problemType = query.problemType as string | undefined;
    const t0 = query.occurTimeStart as string | undefined;
    const t1 = query.occurTimeEnd as string | undefined;
    return rows.filter(r => {
      if (t0 && dayjs(r.occurTime).isBefore(dayjs(t0))) return false;
      if (t1 && dayjs(r.occurTime).isAfter(dayjs(t1))) return false;
      if (region && r.region !== region) return false;
      if (disposalStatus && r.disposalStatus !== disposalStatus) return false;
      if (pollutionLevel && r.pollutionLevel !== pollutionLevel) return false;
      if (problemType && r.problemType !== problemType) return false;
      if (keyword) {
        const blob = `${r.eventTitle}${r.eventCode}${r.location}${r.pollutionType}${r.problemType}${r.problemSource}${r.sectionCode}${getRiverLakeSectionLabel(r.sectionCode)}`;
        if (!blob.includes(keyword)) return false;
      }
      return true;
    });
  }, [rows, query]);

  const allCols: EcoColumnConfig[] = useMemo(
    () => [
      { key: 'eventCode', title: '事件编号', dataIndex: 'eventCode', width: 150, fixed: 'left' },
      { key: 'eventTitle', title: '事件名称', dataIndex: 'eventTitle', width: 200 },
      {
        key: 'sectionCode',
        title: '河段或湖泊编码',
        dataIndex: 'sectionCode',
        width: 260,
        ellipsis: true,
        defaultVisible: false,
        render: (v: unknown) => getRiverLakeSectionLabel(String(v ?? '')),
      },
      { key: 'problemType', title: '问题类型', dataIndex: 'problemType', width: 130 },
      { key: 'problemSource', title: '信息来源', dataIndex: 'problemSource', width: 100, defaultVisible: false },
      { key: 'occurTime', title: '事发时间', dataIndex: 'occurTime', width: 132 },
      { key: 'reportTime', title: '上报时间', dataIndex: 'reportTime', width: 132, defaultVisible: false },
      { key: 'region', title: '所属区域', dataIndex: 'region', width: 100 },
      {
        key: 'pollutionLevel',
        title: '污染等级',
        dataIndex: 'pollutionLevel',
        width: 88,
        render: (t: unknown) => <Tag color={pollutionLevelColor[String(t)] ?? 'default'}>{String(t)}</Tag>,
      },
      {
        key: 'warningLevel',
        title: '预警级别',
        dataIndex: 'warningLevel',
        width: 88,
        render: (t: unknown) => <Tag color={warningLevelColor[String(t)] ?? 'default'}>{String(t)}</Tag>,
        defaultVisible: false,
      },
      {
        key: 'disposalStatus',
        title: '处置状态',
        dataIndex: 'disposalStatus',
        width: 100,
        render: (t: unknown) => <Tag color={disposalStatusColor[String(t)] ?? 'default'}>{String(t)}</Tag>,
      },
      { key: 'inchargePerson', title: '负责处理人', dataIndex: 'inchargePerson', width: 120, defaultVisible: false },
      { key: 'responsibleParty', title: '责任主体', dataIndex: 'responsibleParty', width: 180 },
      { key: 'location', title: '事发地点', dataIndex: 'location', width: 200 },
      { key: 'pollutionType', title: '特征污染', dataIndex: 'pollutionType', width: 130, defaultVisible: false },
      { key: 'impactScope', title: '影响范围', dataIndex: 'impactScope', width: 180, defaultVisible: false },
      { key: 'operation', title: '操作', width: 228, defaultVisible: true },
    ],
    [],
  );
  const [visibleCols, setVisibleCols] = useState(() => getEcoDefaultVisibleColumnKeys(allCols));
  const columns = useMemo(
    () =>
      buildTableColumnsFromEcoConfig(allCols, visibleCols, record => {
        const row = record as EmergencyEventRow;
        return (
          <Space size="small">
          <Button
            type="link"
            size="small"
            className="action-btn detail"
            icon={<EyeOutlined />}
            onClick={() => {
              const linked = assessments.filter(a => a.linkedEventId === row.id);
              setDetailAssessmentPickId(linked[0]?.id ?? null);
              setDetail(row);
              setDetailOpen(true);
            }}
          >
            详情
          </Button>
          <Button
            type="link"
            size="small"
            className="action-btn edit"
            icon={<AlertOutlined />}
            onClick={() => openEventEdit(row, 'disposal')}
          >
            处置上报
          </Button>
          <Button
            type="link"
            size="small"
            className="action-btn edit"
            icon={<EditOutlined />}
            onClick={() => openEventEdit(row, 'basic')}
          >
            编辑
          </Button>
        </Space>
        );
      }),
    [allCols, visibleCols, assessments, openEventEdit],
  );

  const handleSearch = () => {
    const v = filterForm.getFieldsValue() as {
      keyword?: string;
      region?: string;
      disposalStatus?: string;
      pollutionLevel?: string;
      problemType?: string;
      occurTimeRange?: [dayjs.Dayjs, dayjs.Dayjs] | null;
    };
    const range = v.occurTimeRange;
    setQuery({
      keyword: (v.keyword ?? '').trim(),
      region: v.region,
      disposalStatus: v.disposalStatus,
      pollutionLevel: v.pollutionLevel,
      problemType: v.problemType,
      occurTimeStart: range?.[0]?.format('YYYY-MM-DD HH:mm:ss'),
      occurTimeEnd: range?.[1]?.format('YYYY-MM-DD HH:mm:ss'),
    });
    message.success('已查询');
  };

  const handleReset = () => {
    filterForm.resetFields();
    setQuery({});
    message.info('已重置筛选条件');
  };

  const save = async () => {
    const v = await editForm.validateFields();
    const occurTimeStr = (v.occurTime as dayjs.Dayjs).format('YYYY-MM-DD HH:mm');
    const reportTimeStr = (v.reportTime as dayjs.Dayjs).format('YYYY-MM-DD HH:mm');
    const endD = v.endDate as dayjs.Dayjs | undefined | null;
    const endDateStr = endD ? dayjs(endD).format('YYYY-MM-DD') : '';
    const ed = (v.eventDisposal ?? {}) as Record<string, unknown>;
    const ct = ed.completedTime;
    const completedTimeStr =
      ct != null && dayjs.isDayjs(ct)
        ? (ct as dayjs.Dayjs).format('YYYY-MM-DD HH:mm')
        : typeof ct === 'string'
          ? ct
          : '';
    const rawEventImgs = v.eventImages;
    const eventImages: string[] = Array.isArray(rawEventImgs)
      ? rawEventImgs.filter((x): x is string => typeof x === 'string')
      : [];
    const imgs = ed.images;
    const images: string[] = Array.isArray(imgs) ? imgs.filter((x): x is string => typeof x === 'string') : [];
    const eventDisposal: EmergencyEventDisposal = {
      contactPhone: String(ed.contactPhone ?? ''),
      disposalDescribe: String(ed.disposalDescribe ?? editing?.eventDisposal?.disposalDescribe ?? ''),
      completedTime: completedTimeStr,
      images,
    };
    const payload: EmergencyEventRow = {
      id: editing?.id ?? `evt-${Date.now()}`,
      eventCode: editing ? editing.eventCode : generateNextEventCode(rows),
      eventTitle: v.eventTitle,
      sectionCode: typeof v.sectionCode === 'string' ? v.sectionCode : String(v.sectionCode ?? ''),
      problemType: v.problemType,
      problemSource: v.problemSource,
      occurTime: occurTimeStr,
      reportTime: reportTimeStr,
      addvcd: editing?.addvcd ?? '',
      region: v.region,
      location: v.location,
      longitude: v.longitude,
      latitude: v.latitude,
      situationDescribe: v.situationDescribe,
      pollutionType: v.pollutionType,
      impactScope: v.impactScope,
      cause: v.cause,
      pollutionLevel: v.pollutionLevel,
      warningLevel: v.warningLevel,
      reporterName: v.reporterName,
      reporterPhone: v.reporterPhone,
      inchargePerson: v.inchargePerson,
      responsibleParty: v.responsibleParty,
      nativeProcessing: v.nativeProcessing,
      disposalStatus: v.disposalStatus,
      disposalProgress: v.disposalProgress,
      measuresTaken: v.measuresTaken,
      teamsUsage: v.teamsUsage,
      materialsUsage: v.materialsUsage,
      waterRecovery: v.waterRecovery,
      eventResult: v.eventResult,
      endDate: endDateStr,
      eventImages,
      eventDisposal,
    };
    if (editing) {
      setRows(prev => prev.map(r => (r.id === editing.id ? payload : r)));
      if (detail?.id === editing.id) {
        setDetail(payload);
      }
      message.success('已保存');
    } else {
      setRows(prev => [...prev, payload]);
      message.success('已新增');
    }
    closeEdit();
  };

  const del = () => {
    if (!editing) return;
    setRows(prev => prev.filter(r => r.id !== editing.id));
    if (detail?.id === editing.id) {
      setDetail(null);
      setDetailOpen(false);
      setDetailAssessmentPickId(null);
    }
    message.success('已删除');
    closeEdit();
  };

  const openCreate = () => {
    setEditing(null);
    editForm.resetFields();
    setEventEditTab('basic');
    editForm.setFieldsValue({
      occurTime: dayjs(),
      reportTime: dayjs(),
      pollutionLevel: '一般',
      warningLevel: '蓝色',
      disposalStatus: '接报核实',
      nativeProcessing: '否',
      problemType: '水体污染（含突发）',
      problemSource: '电话投诉',
      sectionCode: undefined,
      longitude: '',
      latitude: '',
      situationDescribe: '',
      reporterName: '',
      reporterPhone: '',
      inchargePerson: '',
      responsibleParty: '',
      disposalProgress: '',
      measuresTaken: '',
      teamsUsage: '',
      materialsUsage: '',
      waterRecovery: '',
      eventResult: '',
      eventImages: [],
      eventDisposal: {
        contactPhone: '',
        disposalDescribe: '',
        completedTime: undefined,
        images: [],
      },
    });
    setEditOpen(true);
  };

  return (
    <div className="facility-view">
      <Card
        title="应急事件信息"
        extra={
          <Space wrap size={[8, 8]} align="center">
            <EcoProtoExportBtn />
            <EcoProtoImportBtn />
            <EcoColumnManager columns={allCols} visibleColumns={visibleCols} onChange={setVisibleCols} />
            <Button type="primary" icon={<PlusOutlined />} className="add-btn" onClick={openCreate}>
              新增
            </Button>
          </Space>
        }
      >
        <Form form={filterForm}>
          <Row gutter={[16, 12]} style={{ marginBottom: 16 }} align="middle">
            <Col xs={24} sm={12} md={8} lg={6}>
              <Form.Item name="occurTimeRange" style={{ marginBottom: 0 }}>
                <RangePicker showTime style={{ width: '100%' }} placeholder={['事发时间起', '事发时间止']} />
              </Form.Item>
            </Col>
            <Col xs={24} sm={12} md={8} lg={4}>
              <Form.Item name="region" style={{ marginBottom: 0 }}>
                <Select allowClear placeholder="所属区域" optionFilterProp="label" showSearch style={{ width: '100%' }} options={[...SHAOSHAN_SUB_REGION_OPTIONS].map(x => ({ value: x, label: x }))} />
              </Form.Item>
            </Col>
            <Col xs={24} sm={12} md={8} lg={4}>
              <Form.Item name="problemType" style={{ marginBottom: 0 }}>
                <Select allowClear placeholder="问题类型" optionFilterProp="label" showSearch style={{ width: '100%' }} options={[...REPORT_PROBLEM_TYPE_OPTIONS].map(x => ({ value: x, label: x }))} />
              </Form.Item>
            </Col>
            <Col xs={24} sm={12} md={8} lg={4}>
              <Form.Item name="disposalStatus" style={{ marginBottom: 0 }}>
                <Select allowClear placeholder="处置状态" optionFilterProp="label" showSearch style={{ width: '100%' }} options={[...DISPOSAL_STATUS_OPTIONS].map(x => ({ value: x, label: x }))} />
              </Form.Item>
            </Col>
            <Col xs={24} sm={12} md={8} lg={4}>
              <Form.Item name="pollutionLevel" style={{ marginBottom: 0 }}>
                <Select allowClear placeholder="污染等级" optionFilterProp="label" showSearch style={{ width: '100%' }} options={[...POLLUTION_LEVEL_OPTIONS].map(x => ({ value: x, label: x }))} />
              </Form.Item>
            </Col>
            <Col xs={24} sm={12} md={8} lg={6}>
              <Form.Item name="keyword" style={{ marginBottom: 0 }}>
                <Input allowClear placeholder="关键词：名称、编号、地点、河段编码、类型、来源等" prefix={<SearchOutlined />} />
              </Form.Item>
            </Col>
            <Col xs={24} lg={24} style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <Space>
                <Button type="primary" className="search-btn" icon={<SearchOutlined />} onClick={handleSearch}>
                  查询
                </Button>
                <Button onClick={handleReset}>重置</Button>
              </Space>
            </Col>
          </Row>
        </Form>
        <div className="facility-table-wrap">
          <Table
            rowKey="id"
            size="small"
            scroll={{ x: getEcoTableScrollX(allCols.filter(c => visibleCols.includes(c.key) || c.key === 'operation')) }}
            pagination={{ pageSize: 10, showTotal: t => `共 ${t} 条` }}
            columns={columns}
            dataSource={filtered}
          />
        </div>
      </Card>
      <Modal
        title={`应急事件详情${detailDisplay ? ` — ${detailDisplay.eventCode}` : ''}`}
        open={detailOpen}
        onCancel={() => {
          setDetailOpen(false);
          setDetail(null);
          setDetailAssessmentPickId(null);
        }}
        width={960}
        footer={null}
        destroyOnClose
        styles={detailModalStyles}
      >
        {detailDisplay && (
          <DetailTabsIfMultiple
            key={detailDisplay.id}
            size="small"
            defaultActiveKey="basic"
            className="facility-detail-tabs facility-event-detail-tabs"
            items={[
              {
                key: 'basic',
                label: '基本信息',
                children: (
                  <>
                    <Descriptions bordered column={2} size="small" title="登记与位置信息">
                      <Descriptions.Item label="事件编号" span={2}>
                        <Text strong>{detailDisplay.eventCode}</Text>
                      </Descriptions.Item>
                      <Descriptions.Item label="事件名称" span={2}>
                        {detailDisplay.eventTitle}
                      </Descriptions.Item>
                      <Descriptions.Item label="河段或湖泊编码" span={2}>
                        {getRiverLakeSectionLabel(detailDisplay.sectionCode)}
                      </Descriptions.Item>
                      <Descriptions.Item label="问题类型">{detailDisplay.problemType}</Descriptions.Item>
                      <Descriptions.Item label="信息来源">{detailDisplay.problemSource}</Descriptions.Item>
                      <Descriptions.Item label="事发时间">{detailDisplay.occurTime}</Descriptions.Item>
                      <Descriptions.Item label="上报时间">{detailDisplay.reportTime}</Descriptions.Item>
                      <Descriptions.Item label="上报人">{detailDisplay.reporterName}</Descriptions.Item>
                      <Descriptions.Item label="上报人联系电话">{detailDisplay.reporterPhone}</Descriptions.Item>
                      <Descriptions.Item label="所属区域">{detailDisplay.region}</Descriptions.Item>
                      <Descriptions.Item label="事发地点" span={2}>
                        {detailDisplay.location}
                      </Descriptions.Item>
                      <Descriptions.Item label="事发经度（度）">{detailDisplay.longitude || '—'}</Descriptions.Item>
                      <Descriptions.Item label="事发纬度（度）">{detailDisplay.latitude || '—'}</Descriptions.Item>
                      <Descriptions.Item label="事发位置地图" span={2}>
                        <EmergencyEventDetailMap
                          longitude={detailDisplay.longitude}
                          latitude={detailDisplay.latitude}
                          eventTitle={detailDisplay.eventTitle}
                          location={detailDisplay.location}
                        />
                      </Descriptions.Item>
                      <Descriptions.Item label="情况描述" span={2}>
                        {detailDisplay.situationDescribe}
                      </Descriptions.Item>
                      <Descriptions.Item label="特征污染物或类型" span={2}>
                        {detailDisplay.pollutionType}
                      </Descriptions.Item>
                      <Descriptions.Item label="影响范围" span={2}>
                        {detailDisplay.impactScope}
                      </Descriptions.Item>
                      <Descriptions.Item label="事发原因" span={2}>
                        {detailDisplay.cause}
                      </Descriptions.Item>
                      <Descriptions.Item label="事件图片" span={2}>
                        {detailDisplay.eventImages && detailDisplay.eventImages.length > 0 ? (
                          <Image.PreviewGroup>
                            <Space wrap size={4}>
                              {detailDisplay.eventImages.map((url, i) => (
                                <Image key={i} src={url} width={48} height={48} style={{ objectFit: 'cover' }} alt={`事件图${i + 1}`} />
                              ))}
                            </Space>
                          </Image.PreviewGroup>
                        ) : (
                          '—'
                        )}
                      </Descriptions.Item>
                    </Descriptions>
                  </>
                ),
              },
              {
                key: 'disposal',
                label: '事件处置',
                children: (
                  <Descriptions bordered column={2} size="small">
                    <Descriptions.Item label="负责处理人">{detailDisplay.inchargePerson}</Descriptions.Item>
                    <Descriptions.Item label="是否自行先期处置">{detailDisplay.nativeProcessing}</Descriptions.Item>
                    <Descriptions.Item label="联系电话">{detailDisplay.eventDisposal?.contactPhone || '—'}</Descriptions.Item>
                    <Descriptions.Item label="处置完成时间">{detailDisplay.eventDisposal?.completedTime || '—'}</Descriptions.Item>
                    <Descriptions.Item label="办结日期">{detailDisplay.endDate || '—'}</Descriptions.Item>
                    <Descriptions.Item label="责任主体" span={2}>
                      {detailDisplay.responsibleParty}
                    </Descriptions.Item>
                    <Descriptions.Item label="处置进展" span={2}>
                      {detailDisplay.disposalProgress}
                    </Descriptions.Item>
                    <Descriptions.Item label="已采取应急措施" span={2}>
                      {detailDisplay.measuresTaken}
                    </Descriptions.Item>
                    <Descriptions.Item label="队伍使用情况" span={2}>
                      {detailDisplay.teamsUsage}
                    </Descriptions.Item>
                    <Descriptions.Item label="物资使用情况" span={2}>
                      {detailDisplay.materialsUsage}
                    </Descriptions.Item>
                    <Descriptions.Item label="水质恢复状况" span={2}>
                      {detailDisplay.waterRecovery}
                    </Descriptions.Item>
                    <Descriptions.Item label="事件结果" span={2}>
                      {detailDisplay.eventResult}
                    </Descriptions.Item>
                    <Descriptions.Item label="处置图片" span={2}>
                      {detailDisplay.eventDisposal?.images && detailDisplay.eventDisposal.images.length > 0 ? (
                        <Image.PreviewGroup>
                          <Space wrap size={4}>
                            {detailDisplay.eventDisposal.images.map((url, i) => (
                              <Image key={i} src={url} width={48} height={48} style={{ objectFit: 'cover' }} alt={`处置图${i + 1}`} />
                            ))}
                          </Space>
                        </Image.PreviewGroup>
                      ) : (
                        '—'
                      )}
                    </Descriptions.Item>
                  </Descriptions>
                ),
              },
              {
                key: 'assessment',
                label: '事件评估',
                children:
                  detailLinkedAssessments.length === 0 ? (
                    <Empty style={{ margin: '24px 0' }} description="暂无关联本事件的评估记录（请在「事件评估」菜单中维护并关联本事件）" />
                  ) : (
                    <div style={{ marginTop: 8 }}>
                      {detailLinkedAssessments.length > 1 ? (
                        <div style={{ marginBottom: 16, maxWidth: 480 }}>
                          <Select
                            value={detailAssessmentPickId ?? selectedDetailAssessment?.id}
                            onChange={id => setDetailAssessmentPickId(id)}
                            style={{ width: '100%' }}
                            options={detailLinkedAssessments.map(a => ({
                              value: a.id,
                              label: `${a.assessmentCode}（${a.assessTime}）`,
                            }))}
                          />
                        </div>
                      ) : null}
                      {selectedDetailAssessment ? (
                        <Descriptions
                          key={selectedDetailAssessment.id}
                          bordered
                          column={2}
                          size="small"
                          style={{ marginTop: detailLinkedAssessments.length > 1 ? 0 : 8 }}
                          title="评估信息"
                        >
                          <Descriptions.Item label="评估编号" span={2}>
                            <Text strong>{selectedDetailAssessment.assessmentCode}</Text>
                          </Descriptions.Item>
                          <Descriptions.Item label="评估日期">{selectedDetailAssessment.assessTime || '—'}</Descriptions.Item>
                          <Descriptions.Item label="评估单位">{selectedDetailAssessment.assessOrg || '—'}</Descriptions.Item>
                          <Descriptions.Item label="总体评估" span={2}>
                            {selectedDetailAssessment.overallAssessment || '—'}
                          </Descriptions.Item>
                          <Descriptions.Item label="人员损害" span={2}>
                            {selectedDetailAssessment.personnelDamage || '—'}
                          </Descriptions.Item>
                          <Descriptions.Item label="财产损害" span={2}>
                            {selectedDetailAssessment.propertyDamage || '—'}
                          </Descriptions.Item>
                          <Descriptions.Item label="污染损害评估" span={2}>
                            {selectedDetailAssessment.pollutionDamageAssessment || '—'}
                          </Descriptions.Item>
                          <Descriptions.Item label="生态环境损害评估" span={2}>
                            {selectedDetailAssessment.ecoDamageAssessment || '—'}
                          </Descriptions.Item>
                          <Descriptions.Item label="评估附件" span={2}>
                            {selectedDetailAssessment.attachmentFileName || selectedDetailAssessment.pdfUrl ?
                              <Space wrap align="center">
                                <Text>{selectedDetailAssessment.attachmentFileName || '附件'}</Text>
                                {selectedDetailAssessment.pdfUrl ?
                                  <>
                                    <Button
                                      type="link"
                                      className="action-btn detail"
                                      href={selectedDetailAssessment.pdfUrl}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                    >
                                      查看
                                    </Button>
                                    <Button
                                      type="link"
                                      className="action-btn detail"
                                      href={selectedDetailAssessment.pdfUrl}
                                      download={selectedDetailAssessment.attachmentFileName || '评估附件'}
                                    >
                                      下载
                                    </Button>
                                  </>
                                : null}
                              </Space>
                            : '—'}
                          </Descriptions.Item>
                        </Descriptions>
                      ) : null}
                    </div>
                  ),
              },
            ]}
          />
        )}
      </Modal>
      <Modal
        title={editing ? '编辑应急事件' : '新增应急事件'}
        open={editOpen}
        width={920}
        onCancel={closeEdit}
        destroyOnClose
        styles={formModalStyles}
        footer={
          <Space>
            {editing ? (
              <Popconfirm title="确认删除？" onConfirm={del}>
                <Button danger>删除</Button>
              </Popconfirm>
            ) : null}
            <Button className="secondary-btn" onClick={closeEdit}>取消</Button>
            <Button type="primary" onClick={() => void save()}>
              保存
            </Button>
          </Space>
        }
      >
        <Form form={editForm} layout="vertical" preserve={false}>
          <Tabs
            activeKey={eventEditTab}
            onChange={setEventEditTab}
            size="small"
            className="facility-detail-tabs facility-event-edit-tabs"
            items={[
              {
                key: 'basic',
                label: '基本信息',
                children: (
                  <Row gutter={[16, 0]}>
                    <Col xs={24} sm={12}>
                      {/* 与生态整治「河湖长制 — 事务列表」事务编号栏一致：只读 Input + extra 规则说明 */}
                      <Form.Item
                        label="事件编号"
                        extra={
                          <Paragraph type="secondary" style={{ marginBottom: 0, marginTop: 4, fontSize: 12 }}>
                            保存时按「水应〔年〕MMDD-序号」规则自动生成
                          </Paragraph>
                        }
                        style={{ marginBottom: 12 }}
                      >
                        <Input readOnly placeholder="保存后显示编号" value={editing?.eventCode ?? ''} />
                      </Form.Item>
                    </Col>
                    <Col xs={24} sm={12}>
                      <Form.Item name="eventTitle" label="事件名称" rules={[{ required: true, message: '请填写事件名称' }]} style={{ marginBottom: 12 }}>
                        <Input placeholder="简要概括事件" />
                      </Form.Item>
                    </Col>
                    <Col xs={24} sm={24}>
                      <Form.Item name="sectionCode" label="河段或湖泊编码" rules={[{ required: true, message: '请选择河流或湖泊对象' }]} style={{ marginBottom: 12 }}>
                        <Select
                          showSearch
                          allowClear
                          optionFilterProp="label"
                          placeholder="选自生态整治「河道水体」河流/湖泊主数据"
                          options={RIVER_LAKE_SECTION_SELECT_OPTIONS}
                          style={{ width: '100%' }}
                        />
                      </Form.Item>
                    </Col>
                    <Col xs={24} sm={24}>
                      <Form.Item name="region" label="所属区域" rules={[{ required: true }]} style={{ marginBottom: 12 }}>
                        <Select options={[...SHAOSHAN_SUB_REGION_OPTIONS].map(x => ({ value: x, label: x }))} placeholder="韶山市下辖乡镇（街道）" />
                      </Form.Item>
                    </Col>
                    <Col xs={24} sm={12}>
                      <Form.Item name="problemType" label="问题类型" rules={[{ required: true }]} style={{ marginBottom: 12 }}>
                        <Select placeholder="请选择" options={[...REPORT_PROBLEM_TYPE_OPTIONS].map(x => ({ value: x, label: x }))} />
                      </Form.Item>
                    </Col>
                    <Col xs={24} sm={12}>
                      <Form.Item name="problemSource" label="信息来源" rules={[{ required: true }]} style={{ marginBottom: 12 }}>
                        <Select placeholder="请选择" options={[...REPORT_PROBLEM_SOURCE_OPTIONS].map(x => ({ value: x, label: x }))} />
                      </Form.Item>
                    </Col>
                    <Col xs={24} sm={12}>
                      <Form.Item name="pollutionLevel" label="污染等级" rules={[{ required: true }]} style={{ marginBottom: 12 }}>
                        <Select options={[...POLLUTION_LEVEL_OPTIONS].map(x => ({ value: x, label: x }))} />
                      </Form.Item>
                    </Col>
                    <Col xs={24} sm={12}>
                      <Form.Item name="warningLevel" label="预警级别" rules={[{ required: true }]} style={{ marginBottom: 12 }}>
                        <Select options={[...WARNING_LEVEL_OPTIONS].map(x => ({ value: x, label: x }))} />
                      </Form.Item>
                    </Col>
                    <Col xs={24} sm={12}>
                      <Form.Item name="reporterName" label="上报人" rules={[{ required: true }]} style={{ marginBottom: 12 }}>
                        <Input />
                      </Form.Item>
                    </Col>
                    <Col xs={24} sm={12}>
                      <Form.Item name="reporterPhone" label="上报人联系电话" rules={[{ required: true }]} style={{ marginBottom: 12 }}>
                        <Input />
                      </Form.Item>
                    </Col>
                    <Col xs={24} sm={12}>
                      <Form.Item name="occurTime" label="事发时间" rules={[{ required: true, message: '请选择事发时间' }]} style={{ marginBottom: 12 }}>
                        <DatePicker showTime style={{ width: '100%' }} />
                      </Form.Item>
                    </Col>
                    <Col xs={24} sm={12}>
                      <Form.Item name="reportTime" label="上报时间" rules={[{ required: true, message: '请选择上报时间' }]} style={{ marginBottom: 12 }}>
                        <DatePicker showTime style={{ width: '100%' }} />
                      </Form.Item>
                    </Col>
                    <Col span={24}>
                      <Form.Item name="location" label="事发地点" rules={[{ required: true }]} style={{ marginBottom: 12 }}>
                        <Input placeholder="问题发生位置文字描述" />
                      </Form.Item>
                    </Col>
                    <Col span={24}>
                      <EmergencyMapLocationPicker form={editForm} />
                    </Col>
                    <Col xs={24} sm={12}>
                      <Form.Item name="longitude" label="事发经度（度）" rules={[{ required: true, message: '请填写经度' }]} style={{ marginBottom: 12 }}>
                        <Input placeholder="保留六位小数" />
                      </Form.Item>
                    </Col>
                    <Col xs={24} sm={12}>
                      <Form.Item name="latitude" label="事发纬度（度）" rules={[{ required: true, message: '请填写纬度' }]} style={{ marginBottom: 12 }}>
                        <Input placeholder="保留六位小数" />
                      </Form.Item>
                    </Col>
                    <Col span={24}>
                      <Form.Item name="pollutionType" label="特征污染物或污染类型" rules={[{ required: true }]} style={{ marginBottom: 12 }}>
                        <Input placeholder="如石油类、高浊度等" />
                      </Form.Item>
                    </Col>
                    <Col span={24}>
                      <Form.Item name="impactScope" label="影响范围" rules={[{ required: true }]} style={{ marginBottom: 12 }}>
                        <TextArea rows={2} placeholder="河段里程、敏感目标、供水人口等" />
                      </Form.Item>
                    </Col>
                    <Col span={24}>
                      <Form.Item name="situationDescribe" label="情况描述" rules={[{ required: true }]} style={{ marginBottom: 12 }}>
                        <TextArea rows={3} placeholder="现场情况、感官特征、监测线索等" />
                      </Form.Item>
                    </Col>
                    <Col span={24}>
                      <Form.Item name="cause" label="事发原因" rules={[{ required: true }]} style={{ marginBottom: 12 }}>
                        <TextArea rows={2} placeholder="初步或核实后的原因说明" />
                      </Form.Item>
                    </Col>
                    <Col span={24}>
                      <Form.Item name="eventImages" label="事件图片" style={{ marginBottom: 12 }}>
                        <DataUrlImageCardUpload
                          listKey="event"
                          fileNamePrefix="事件图"
                          uploadLabel="上传照片"
                        />
                      </Form.Item>
                    </Col>
                  </Row>
                ),
              },
              {
                key: 'disposal',
                label: '事件处置',
                children: (
                  <Row gutter={[16, 0]}>
                    <Col xs={24} sm={12}>
                      <Form.Item name="disposalStatus" label="处置状态" rules={[{ required: true }]} style={{ marginBottom: 12 }}>
                        <Select options={[...DISPOSAL_STATUS_OPTIONS].map(x => ({ value: x, label: x }))} />
                      </Form.Item>
                    </Col>
                    <Col xs={24} sm={12}>
                      <Form.Item name="inchargePerson" label="负责处理人" rules={[{ required: true, message: '请填写负责处理人' }]} style={{ marginBottom: 12 }}>
                        <Input placeholder="当前牵头处置责任人" />
                      </Form.Item>
                    </Col>
                    <Col xs={24} sm={12}>
                      <Form.Item name="nativeProcessing" label="是否自行先期处置" rules={[{ required: true }]} style={{ marginBottom: 12 }}>
                        <Select options={[...NATIVE_PROCESSING_OPTIONS].map(x => ({ value: x, label: x }))} />
                      </Form.Item>
                    </Col>
                    <Col xs={24} sm={12}>
                      <Form.Item name={['eventDisposal', 'contactPhone']} label="联系电话" rules={[{ required: true, message: '请填写联系电话' }]} style={{ marginBottom: 12 }}>
                        <Input placeholder="手机或座机" />
                      </Form.Item>
                    </Col>
                    <Col xs={24} sm={12}>
                      <Form.Item name={['eventDisposal', 'completedTime']} label="处置完成时间" rules={[{ required: true, message: '请选择处置完成时间' }]} style={{ marginBottom: 12 }}>
                        <DatePicker showTime style={{ width: '100%' }} />
                      </Form.Item>
                    </Col>
                    <Col span={24}>
                      <Form.Item name="responsibleParty" label="责任主体" rules={[{ required: true }]} style={{ marginBottom: 12 }}>
                        <Input placeholder="牵头单位与协同部门" />
                      </Form.Item>
                    </Col>
                    <Col span={24}>
                      <Form.Item name="disposalProgress" label="处置进展" rules={[{ required: true }]} style={{ marginBottom: 12 }}>
                        <TextArea rows={3} placeholder="动态更新现场与调度进展" />
                      </Form.Item>
                    </Col>
                    <Col span={24}>
                      <Form.Item name="measuresTaken" label="已采取应急措施" rules={[{ required: true }]} style={{ marginBottom: 12 }}>
                        <TextArea rows={3} />
                      </Form.Item>
                    </Col>
                    <Col span={24}>
                      <Form.Item name="teamsUsage" label="队伍使用情况" rules={[{ required: true }]} style={{ marginBottom: 12 }}>
                        <TextArea rows={2} />
                      </Form.Item>
                    </Col>
                    <Col span={24}>
                      <Form.Item name="materialsUsage" label="物资使用情况" rules={[{ required: true }]} style={{ marginBottom: 12 }}>
                        <TextArea rows={2} />
                      </Form.Item>
                    </Col>
                    <Col span={24}>
                      <Form.Item name="waterRecovery" label="水质恢复状况" rules={[{ required: true }]} style={{ marginBottom: 12 }}>
                        <TextArea rows={2} />
                      </Form.Item>
                    </Col>
                    <Col span={24}>
                      <Form.Item name="eventResult" label="事件结果" rules={[{ required: true }]} style={{ marginBottom: 12 }}>
                        <TextArea rows={2} placeholder="终止响应、调查结论、移交与复盘要点" />
                      </Form.Item>
                    </Col>
                    <Col xs={24} sm={12}>
                      <Form.Item name="endDate" label="办结日期" style={{ marginBottom: 12 }}>
                        <DatePicker style={{ width: '100%' }} placeholder="可选" />
                      </Form.Item>
                    </Col>
                    <Col span={24}>
                      <Form.Item name={['eventDisposal', 'images']} label="处置图片" style={{ marginBottom: 12 }}>
                        <DataUrlImageCardUpload
                          listKey="disposal"
                          fileNamePrefix="处置图"
                          uploadLabel="上传照片"
                        />
                      </Form.Item>
                    </Col>
                  </Row>
                ),
              },
            ]}
          />
        </Form>
      </Modal>
    </div>
  );
};

// ========== 事件评估（精简） ==========
interface EventAssessmentPageProps {
  events: EmergencyEventRow[];
  assessments: EventAssessmentRow[];
  onAssessmentsChange: React.Dispatch<React.SetStateAction<EventAssessmentRow[]>>;
}

const EventAssessmentPage: React.FC<EventAssessmentPageProps> = ({ events, assessments: rows, onAssessmentsChange: setRows }) => {
  const [editForm] = Form.useForm();
  const [editOpen, setEditOpen] = useState(false);
  const [editing, setEditing] = useState<EventAssessmentRow | null>(null);
  /** 评估附件：文件地址（远程 URL 或本地上传 data URL）与展示文件名，与表单其它字段分离避免超大字符串进 Form store */
  const [assessAttach, setAssessAttach] = useState<{ url: string | null; name: string }>({ url: null, name: '' });

  const closeEdit = useCallback(() => {
    setEditOpen(false);
    setEditing(null);
    editForm.resetFields();
    setAssessAttach({ url: null, name: '' });
  }, [editForm]);

  const assessmentAttachFileList: UploadFile[] = useMemo(
    () =>
      assessAttach.name ?
        [{ uid: 'assessment-attach', name: assessAttach.name, status: 'done' }]
      : [],
    [assessAttach.name],
  );

  const save = async () => {
    const v = await editForm.validateFields();
    const payload: EventAssessmentRow = {
      id: editing?.id ?? `asr-${Date.now()}`,
      linkedEventId: v.linkedEventId,
      assessmentCode: v.assessmentCode,
      assessTime: (v.assessTime as dayjs.Dayjs).format('YYYY-MM-DD'),
      assessOrg: v.assessOrg,
      overallAssessment: v.overallAssessment,
      personnelDamage: v.personnelDamage,
      propertyDamage: v.propertyDamage,
      pollutionDamageAssessment: v.pollutionDamageAssessment,
      ecoDamageAssessment: v.ecoDamageAssessment,
      pdfUrl: assessAttach.url,
      attachmentFileName: assessAttach.name.trim(),
    };
    if (editing) setRows(prev => prev.map(r => (r.id === editing.id ? payload : r)));
    else setRows(prev => [...prev, payload]);
    message.success(editing ? '已保存' : '已新增');
    closeEdit();
  };

  const columns: ColumnsType<EventAssessmentRow> = [
    { title: '评估编号', dataIndex: 'assessmentCode', width: 160 },
    { title: '关联事件', dataIndex: 'linkedEventId', width: 100, render: (id: string) => events.find(e => e.id === id)?.eventTitle ?? id },
    { title: '评估日期', dataIndex: 'assessTime', width: 120 },
    { title: '操作', key: 'op', width: 120, render: (_, r) => (
      <Button type="link" size="small" className="action-btn edit" onClick={() => {
        setEditing(r);
        setAssessAttach({ url: r.pdfUrl, name: r.attachmentFileName });
        editForm.setFieldsValue({ ...r, assessTime: dayjs(r.assessTime) });
        setEditOpen(true);
      }}>编辑</Button>
    )},
  ];

  return (
    <div className="facility-view">
      <Card title="事件评估" extra={<Button type="primary" icon={<PlusOutlined />} className="add-btn" onClick={() => { setEditing(null); editForm.resetFields(); setAssessAttach({ url: null, name: '' }); setEditOpen(true); }}>新增</Button>}>
        <div className="facility-table-wrap">
          <Table rowKey="id" size="small" columns={columns} dataSource={rows} pagination={{ pageSize: 10, showTotal: t => `共 ${t} 条` }} />
        </div>
      </Card>
      <Modal title={editing ? '编辑评估' : '新增评估'} open={editOpen} onCancel={closeEdit} width={880} destroyOnClose styles={formModalStyles}
        footer={<Space><Button className="secondary-btn" onClick={closeEdit}>取消</Button><Button type="primary" onClick={() => void save()}>保存</Button></Space>}>
        <Form form={editForm} layout="vertical">
          <Form.Item name="linkedEventId" label="关联应急事件" rules={[{ required: true }]}>
            <Select options={events.map(e => ({ value: e.id, label: `${e.eventCode} ${e.eventTitle}` }))} showSearch optionFilterProp="label" />
          </Form.Item>
          <Form.Item name="assessmentCode" label="评估编号" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="assessTime" label="评估日期" rules={[{ required: true }]}><DatePicker style={{ width: '100%' }} /></Form.Item>
          <Form.Item name="assessOrg" label="评估单位" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="overallAssessment" label="总体评估" rules={[{ required: true }]}><TextArea rows={3} /></Form.Item>
          <Form.Item name="personnelDamage" label="人员损害"><TextArea rows={2} /></Form.Item>
          <Form.Item name="propertyDamage" label="财产损害"><TextArea rows={2} /></Form.Item>
          <Form.Item name="pollutionDamageAssessment" label="污染损害评估"><TextArea rows={2} /></Form.Item>
          <Form.Item name="ecoDamageAssessment" label="生态环境损害评估"><TextArea rows={2} /></Form.Item>
          <Form.Item
            label="评估附件"
            extra={`支持 PDF、Word；单文件不超过 ${ASSESSMENT_ATTACH_MAX_MB}MB。上传后在详情中可「查看 / 下载」；原型为浏览器本地 data URL，刷新页面可能丢失。`}
          >
            <Upload
              fileList={assessmentAttachFileList}
              maxCount={1}
              accept={ASSESSMENT_ATTACH_ACCEPT}
              beforeUpload={file => {
                const mb = file.size / 1024 / 1024;
                if (mb > ASSESSMENT_ATTACH_MAX_MB) {
                  message.error(`附件不超过 ${ASSESSMENT_ATTACH_MAX_MB}MB`);
                  return Upload.LIST_IGNORE;
                }
                const reader = new FileReader();
                reader.onload = () => {
                  const dataUrl = reader.result as string;
                  setAssessAttach({ url: dataUrl, name: file.name });
                };
                reader.onerror = () => message.error('读取文件失败');
                reader.readAsDataURL(file);
                return false;
              }}
              onRemove={() => {
                setAssessAttach({ url: null, name: '' });
                return true;
              }}
            >
              <Button icon={<UploadOutlined />}>上传文件</Button>
            </Upload>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

const PlaceholderPage: React.FC<{ title: string }> = ({ title }) => (
  <div className="facility-view">
    <Card title={title}>
      <Empty description="功能建设中" />
    </Card>
  </div>
);

// ========== 侧栏与主应用 ==========
type SubKey =
  | 'risk-enterprise'
  | 'emergency-supply'
  | 'social-supply'
  | 'emergency-plan'
  | 'emergency-team'
  | 'expert'
  | 'emergency-events'
  | 'event-assessment'
  | 'event-review';

/** 风险识别子菜单 key（与 RiskMenuKey 一致） */
const RISK_SUB_KEYS: RiskMenuKey[] = [
  'risk-enterprise',
  'emergency-supply',
  'social-supply',
  'emergency-plan',
  'emergency-team',
  'expert',
];

interface MenuGroup {
  key: string;
  label: string;
  icon: React.ReactNode;
  children: { key: SubKey; label: string }[];
}

const SIDEBAR_MENUS: MenuGroup[] = [
  {
    key: 'risk',
    label: '风险识别',
    icon: <AlertOutlined />,
    children: [
      { key: 'risk-enterprise', label: '风险源企业信息' },
      { key: 'emergency-supply', label: '应急物资' },
      { key: 'social-supply', label: '社会物资点' },
      { key: 'emergency-plan', label: '应急预案信息' },
      { key: 'emergency-team', label: '应急队伍信息' },
      { key: 'expert', label: '应急专家库' },
    ],
  },
  {
    key: 'event',
    label: '应急事件',
    icon: <FileTextOutlined />,
    children: [
      { key: 'emergency-events', label: '应急事件信息' },
      { key: 'event-assessment', label: '事件评估' },
      { key: 'event-review', label: '事件复盘' },
    ],
  },
];

const App: React.FC = () => {
  const [expandedKeys, setExpandedKeys] = useState<string[]>(['risk', 'event']);
  const [activeModule, setActiveModule] = useState('event');
  const [activeSubMenu, setActiveSubMenu] = useState<SubKey>('emergency-events');
  const [emergencyEvents, setEmergencyEvents] = useState<EmergencyEventRow[]>(() => [...initialEmergencyEvents]);
  const [assessments, setAssessments] = useState<EventAssessmentRow[]>(() => [...initialEventAssessments]);
  const [riskData, setRiskData] = useState(() => ({ ...initialRiskData }));
  const [eventReviews, setEventReviews] = useState(() => [...initialEventReviews]);

  const toggleExpand = (key: string) => {
    setExpandedKeys(prev => (prev.includes(key) ? prev.filter(k => k !== key) : [...prev, key]));
  };

  const getBreadcrumbPath = () => {
    for (const m of SIDEBAR_MENUS) {
      const c = m.children.find(x => x.key === activeSubMenu);
      if (c) return `${m.label} / ${c.label}`;
    }
    return '应急协同';
  };

  const renderContent = () => {
    switch (activeSubMenu) {
      case 'emergency-events':
        return (
          <EmergencyEventInfoPage events={emergencyEvents} onEventsChange={setEmergencyEvents} assessments={assessments} />
        );
      case 'event-assessment':
        return <EventAssessmentPage events={emergencyEvents} assessments={assessments} onAssessmentsChange={setAssessments} />;
      case 'event-review':
        return (
          <EventReviewPage
            events={emergencyEvents}
            assessments={assessments}
            teams={riskData.teams}
            experts={riskData.experts}
            supplies={riskData.supplies}
            socialPoints={riskData.socialPoints}
            reviews={eventReviews}
            onReviewsChange={setEventReviews}
          />
        );
      default:
        if (RISK_SUB_KEYS.includes(activeSubMenu as RiskMenuKey)) {
          return (
            <RiskIdentificationRouter
              activeSubMenu={activeSubMenu as RiskMenuKey}
              data={riskData}
              setData={setRiskData}
            />
          );
        }
        return <PlaceholderPage title={SIDEBAR_MENUS.flatMap(m => m.children).find(c => c.key === activeSubMenu)?.label ?? '模块'} />;
    }
  };

  return (
    <ConfigProvider locale={zhCN} theme={{ token: { colorPrimary: '#1e5bb5', borderRadius: 4 } }}>
      <Layout className="water-env-dashboard facility-mgmt-standalone">
        <div className="main-layout with-sidebar">
          <div className="sidebar-menu">
            <div className="sidebar-menu-title">应急协同</div>
            <div className="sidebar-menu-list">
              {SIDEBAR_MENUS.map(menu => {
                const isExpanded = expandedKeys.includes(menu.key);
                return (
                  <div key={menu.key} className="sidebar-menu-item-wrapper">
                    <div
                      className={`sidebar-menu-item ${activeModule === menu.key ? 'active' : ''}`}
                      onClick={() => {
                        toggleExpand(menu.key);
                        setActiveModule(menu.key);
                      }}
                      role="button"
                      tabIndex={0}
                    >
                      <span className="sidebar-menu-icon">{menu.icon}</span>
                      <span className="sidebar-menu-label">{menu.label}</span>
                      <span className={`sidebar-menu-arrow ${isExpanded ? 'expanded' : ''}`}>
                        <DownOutlined />
                      </span>
                    </div>
                    {isExpanded && (
                      <div className="sidebar-submenu">
                        {menu.children.map(child => (
                          <div
                            key={child.key}
                            className={`sidebar-submenu-item ${activeSubMenu === child.key ? 'active' : ''}`}
                            onClick={() => {
                              setActiveModule(menu.key);
                              setActiveSubMenu(child.key);
                            }}
                            role="button"
                            tabIndex={0}
                          >
                            {child.label}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
          <div className="main-content-area">
            <div className="breadcrumb-bar">
              <EnvironmentOutlined style={{ marginRight: 8 }} />
              <span className="breadcrumb-current">{getBreadcrumbPath()}</span>
            </div>
            <Content className="main-content with-sidebar">
              <div className="content-wrapper">{renderContent()}</div>
            </Content>
          </div>
        </div>
      </Layout>
    </ConfigProvider>
  );
};

export default App;
