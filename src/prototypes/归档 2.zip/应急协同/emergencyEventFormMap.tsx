/**
 * 应急事件新增/编辑 · 事发位置地图（单击标点 + 拖拽平移一体；事发地点 + 经纬度联动）
 *
 * 不区分选点/平移：保持 **`dragPan.enable()`**，单击落点依赖 **`map.on('click')`**（拖移后 MapLibre **suppressClick** 抑制误触）
 * 与 **`document` 捕获 `click` 备用**（Modal 内更稳）：**`getCanvasContainer().contains`** + **`mousePosOnCanvas`** + `unproject`。
 * 底图：与工业园区同源 **OpenFreeMap Liberty**（`EMERGENCY_MAPLIBRE_BASEMAP_STYLE`）；**无坐标**时视图中心为 **韶山市政府**（`EMERGENCY_MAP_SHAOSHAN_GOVERNMENT_CENTER`），**有标记**时中心为标记点；无点缩放与园区再导出同源。
 * 经纬度或图钉变化后 **`jumpTo`** 默认把标记点**居中**；`idle` 首帧亦对齐。
 * DOM：**外壳**定高 + **内层 host** 专供 Map 挂载。
 */
import React, { useCallback, useEffect, useMemo, useRef } from 'react';
import { Typography } from 'antd';
import maplibregl from 'maplibre-gl';
import Point from '@mapbox/point-geometry';
import 'maplibre-gl/dist/maplibre-gl.css';
import { parseEmergencyEventLngLat } from './emergencyEventDetailMap';
import {
  EMERGENCY_MAP_INCIDENT_ZOOM,
  EMERGENCY_MAPLIBRE_BASEMAP_STYLE,
  EMERGENCY_MAPLIBRE_DEFAULT_ZOOM,
  EMERGENCY_MAP_SHAOSHAN_GOVERNMENT_CENTER,
} from './emergencyMapLibreStyle';

const { Text } = Typography;

/** 编辑地图：有坐标则相机对准图钉，否则园区默认视野 */
function jumpFormMapToMarkerOrDefault(m: maplibregl.Map, point: [number, number] | null) {
  if (!m.isStyleLoaded()) return;
  try {
    if (point) {
      m.jumpTo({ center: point, zoom: EMERGENCY_MAP_INCIDENT_ZOOM, pitch: 0, bearing: 0 });
    } else {
      m.jumpTo({
        center: EMERGENCY_MAP_SHAOSHAN_GOVERNMENT_CENTER,
        zoom: EMERGENCY_MAPLIBRE_DEFAULT_ZOOM,
        pitch: 0,
        bearing: 0,
      });
    }
  } catch {
    /* 忽略 */
  }
}

function isAutoLocationText(loc: string): boolean {
  const t = loc.trim();
  if (!t) return true;
  return /^(地图标注|地图选点)/i.test(t) || /^WGS84/i.test(t);
}

function locationFromPick(lng: string, lat: string): string {
  return `地图标注 WGS84 ${lng}，${lat}`;
}

/** 与 MapLibre `MapMouseEvent` 内 `DOM.mousePos(map.getCanvas(), e)` 一致，保证 `unproject` 正确 */
function mousePosOnCanvas(canvas: HTMLCanvasElement, e: MouseEvent): Point {
  const rect = canvas.getBoundingClientRect();
  const scaleX = (rect.width / canvas.offsetWidth) || 1;
  const scaleY = (rect.height / canvas.offsetHeight) || 1;
  return new Point(
    ((e.clientX - rect.left) / scaleX) - canvas.clientLeft,
    ((e.clientY - rect.top) / scaleY) - canvas.clientTop,
  );
}

export interface EmergencyEventFormMapProps {
  longitude: string;
  latitude: string;
  location: string;
  onFormSync: (patch: { longitude: string; latitude: string; location?: string }) => void;
}

export const EmergencyEventFormMap: React.FC<EmergencyEventFormMapProps> = ({
  longitude,
  latitude,
  location,
  onFormSync,
}) => {
  const shellRef = useRef<HTMLDivElement>(null);
  const mapHostRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);
  const markerRef = useRef<maplibregl.Marker | null>(null);
  const onFormSyncRef = useRef(onFormSync);
  const parsedRef = useRef<[number, number] | null>(null);
  const locationRef = useRef(location);
  const commitPickRef = useRef<(map: maplibregl.Map, lngLat: maplibregl.LngLatLike) => void>(() => {});
  const lastPickTsRef = useRef(0);

  onFormSyncRef.current = onFormSync;
  locationRef.current = location;

  const parsed = useMemo(() => parseEmergencyEventLngLat(longitude, latitude), [longitude, latitude]);
  parsedRef.current = parsed;

  const commitPick = useCallback((map: maplibregl.Map, lngLat: maplibregl.LngLatLike) => {
    const now = typeof performance !== 'undefined' ? performance.now() : Date.now();
    if (now - lastPickTsRef.current < 80) return;
    lastPickTsRef.current = now;

    const ll = maplibregl.LngLat.convert(lngLat);
    if (!Number.isFinite(ll.lng) || !Number.isFinite(ll.lat)) return;

    const lngStr = ll.lng.toFixed(6);
    const latStr = ll.lat.toFixed(6);
    const pair: [number, number] = [ll.lng, ll.lat];

    if (!markerRef.current) {
      const mk = new maplibregl.Marker({
        color: '#1677ff',
        scale: 1.12,
        anchor: 'bottom',
        draggable: true,
      })
        .setLngLat(pair)
        .addTo(map);
      markerRef.current = mk;
      mk.on('dragend', () => {
        const m = mapRef.current;
        if (!m) return;
        commitPickRef.current(m, mk.getLngLat());
      });
    } else {
      markerRef.current.setLngLat(pair);
    }

    const locPrev = locationRef.current;
    const patch: { longitude: string; latitude: string; location?: string } = {
      longitude: lngStr,
      latitude: latStr,
    };
    if (isAutoLocationText(locPrev)) {
      patch.location = locationFromPick(lngStr, latStr);
    }
    onFormSyncRef.current(patch);
  }, []);

  commitPickRef.current = commitPick;

  const syncVisualToParsed = useCallback(() => {
    const map = mapRef.current;
    const p = parsedRef.current;
    if (!map) return;

    if (p) {
      if (!markerRef.current) {
        const mk = new maplibregl.Marker({
          color: '#1677ff',
          scale: 1.12,
          anchor: 'bottom',
          draggable: true,
        })
          .setLngLat(p)
          .addTo(map);
        markerRef.current = mk;
        mk.on('dragend', () => {
          const m = mapRef.current;
          if (!m) return;
          commitPickRef.current(m, mk.getLngLat());
        });
      } else {
        markerRef.current.setLngLat(p);
      }
    } else {
      markerRef.current?.remove();
      markerRef.current = null;
    }
  }, []);

  useEffect(() => {
    if (!parsed) return;
    if (!isAutoLocationText(location)) return;
    const lngS = parsed[0].toFixed(6);
    const latS = parsed[1].toFixed(6);
    const want = locationFromPick(lngS, latS);
    if (location.trim() === want) return;
    onFormSyncRef.current({ longitude: lngS, latitude: latS, location: want });
  }, [parsed, location]);

  /** Modal 内备用：`getCanvasContainer().contains` + 与 MapLibre 一致的 `mousePos` */
  useEffect(() => {
    const onDocClickCapture = (e: MouseEvent) => {
      if (e.button !== 0) return;
      const map = mapRef.current;
      if (!map?.isStyleLoaded()) return;
      const t = e.target as Node | null;
      const canvasContainer = map.getCanvasContainer();
      if (!t || !canvasContainer.contains(t)) return;
      const el = t instanceof Element ? t : null;
      if (el?.closest?.('.maplibregl-marker')) return;
      if (el?.closest?.('.maplibregl-ctrl')) return;

      const canvas = map.getCanvas();
      const pt = mousePosOnCanvas(canvas, e);
      const lngLat = map.unproject(pt);
      commitPickRef.current(map, lngLat);
    };

    document.addEventListener('click', onDocClickCapture, true);
    return () => document.removeEventListener('click', onDocClickCapture, true);
  }, []);

  useEffect(() => {
    const shell = shellRef.current;
    const host = mapHostRef.current;
    if (!shell || !host) return;

    let disposed = false;
    let map: maplibregl.Map | null = null;

    const canLayout = () => shell.clientWidth >= 48 && shell.clientHeight >= 48;

    const bumpResize = () => {
      if (!map || disposed) return;
      map.resize();
      requestAnimationFrame(() => {
        if (!map || disposed) return;
        map.resize();
      });
    };

    const mountMap = () => {
      if (disposed || map) return;
      if (!canLayout()) return;

      const start = parsedRef.current ?? EMERGENCY_MAP_SHAOSHAN_GOVERNMENT_CENTER;
      const zoom = parsedRef.current ? EMERGENCY_MAP_INCIDENT_ZOOM : EMERGENCY_MAPLIBRE_DEFAULT_ZOOM;
      const m = new maplibregl.Map({
        container: host,
        style: EMERGENCY_MAPLIBRE_BASEMAP_STYLE,
        center: start,
        zoom,
        attributionControl: { compact: true },
      });
      map = m;
      mapRef.current = m;

      m.addControl(new maplibregl.NavigationControl({ showCompass: false }), 'top-right');

      m.once('load', () => {
        if (disposed || !map) return;
        syncVisualToParsed();
        bumpResize();
        m.once('idle', () => {
          bumpResize();
          jumpFormMapToMarkerOrDefault(m, parsedRef.current);
        });

        /**
         * 部分环境下 `click` 与 document 捕获仍不可靠；在画布容器上用 pointer 轻点判定补一条落点路径
         *（位移小于阈值视为点选，大于则视为拖移平移）
         */
        const container = m.getCanvasContainer();
        let ptrDown: { x: number; y: number } | null = null;
        const onPtrDown = (e: PointerEvent) => {
          if (e.button !== 0) return;
          const el = e.target instanceof Element ? e.target : null;
          if (el?.closest?.('.maplibregl-marker') || el?.closest?.('.maplibregl-ctrl')) return;
          ptrDown = { x: e.clientX, y: e.clientY };
        };
        const onPtrUp = (e: PointerEvent) => {
          if (e.button !== 0 || !ptrDown) return;
          const start = ptrDown;
          ptrDown = null;
          const el = e.target instanceof Element ? e.target : null;
          if (el?.closest?.('.maplibregl-marker') || el?.closest?.('.maplibregl-ctrl')) return;
          if (Math.hypot(e.clientX - start.x, e.clientY - start.y) > 8) return;
          const canvas = m.getCanvas();
          const pt = mousePosOnCanvas(canvas, e as unknown as MouseEvent);
          commitPickRef.current(m, m.unproject(pt));
        };
        container.addEventListener('pointerdown', onPtrDown, true);
        container.addEventListener('pointerup', onPtrUp, true);
        m.once('remove', () => {
          container.removeEventListener('pointerdown', onPtrDown, true);
          container.removeEventListener('pointerup', onPtrUp, true);
        });
      });

      m.on('click', (ev: maplibregl.MapMouseEvent) => {
        const t = ev.originalEvent.target as Node | null;
        const el = t instanceof Element ? t : null;
        if (el?.closest?.('.maplibregl-marker')) return;
        if (el?.closest?.('.maplibregl-ctrl')) return;
        commitPickRef.current(m, ev.lngLat);
      });
    };

    const onRo = () => {
      if (disposed) return;
      if (!map) mountMap();
      else bumpResize();
    };

    const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(onRo) : null;
    ro?.observe(shell);

    const delays = [0, 50, 120, 280, 480, 800, 1200];
    const timers = delays.map(ms =>
      window.setTimeout(() => {
        if (disposed) return;
        mountMap();
        bumpResize();
      }, ms),
    );

    requestAnimationFrame(() => {
      if (disposed) return;
      mountMap();
      bumpResize();
    });

    return () => {
      disposed = true;
      timers.forEach(t => window.clearTimeout(t));
      ro?.disconnect();
      markerRef.current?.remove();
      markerRef.current = null;
      map?.remove();
      map = null;
      mapRef.current = null;
    };
  }, [syncVisualToParsed]);

  useEffect(() => {
    syncVisualToParsed();
  }, [parsed, syncVisualToParsed]);

  /** 经纬度变化或图钉更新后，默认把标记点置于视图中心 */
  useEffect(() => {
    const map = mapRef.current;
    if (!map?.isStyleLoaded()) return;
    const raf = requestAnimationFrame(() => {
      const m = mapRef.current;
      if (!m?.isStyleLoaded()) return;
      const fromMarker = markerRef.current?.getLngLat();
      const center: [number, number] | null = fromMarker
        ? [fromMarker.lng, fromMarker.lat]
        : parsedRef.current;
      jumpFormMapToMarkerOrDefault(m, center);
    });
    return () => cancelAnimationFrame(raf);
  }, [parsed, longitude, latitude]);

  return (
    <div className="emergency-event-form-map-wrap">
      <div className="emergency-event-form-map-toolbar">
        <Text type="secondary" style={{ fontSize: 12 }}>
          在地图上轻点即可更新经纬度（拖拽为平移）；图钉可拖动。若事发地点为手工描述，点选后只更新坐标，不覆盖文字。
        </Text>
      </div>
      <div
        ref={shellRef}
        className="emergency-event-form-map emergency-event-form-map-shell maplibre-emergency-event maplibre-park-boundary-emergency"
        role="application"
        aria-label="事发位置地图"
      >
        <div ref={mapHostRef} className="emergency-event-form-map-host" aria-hidden />
      </div>
    </div>
  );
};
