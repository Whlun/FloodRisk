/**
 * 河湖长制数据字段说明（依据 DB4401/T 138—2021《河（湖）长制管理信息系统数据规范》）
 * 对应表：FOU_RIVER 河流（涌）信息表、表9「一河一档」河流（段）自然属性表 FOU_RIVER_INFO_DOC、
 * DYN_PATROL、DYN_WATER_QUALITY 等
 */

export type AdminLevel = 'A' | 'B' | 'C' | 'D' | 'E';
export type RiverSide = 'L' | 'R' | 'A';
export type SectionType = 1 | 2 | 3 | 4;

/** 管理级别 ADMIN_LEVEL：A 省管 B 市管 C 县管 D 镇管 E 其他 */
export const ADMIN_LEVEL_LABEL: Record<AdminLevel, string> = {
  A: '省管',
  B: '市管',
  C: '县管',
  D: '镇管',
  E: '其他',
};

/** 河段类型 SENCTION_TYPE：1 河流 2 河流区段 3 镇（街）段 4 村（居）段 */
export const SECTION_TYPE_LABEL: Record<number, string> = {
  1: '河流',
  2: '河流区段',
  3: '镇（街）段',
  4: '村（居）段',
};

/** 河流左右岸别 RIVER_SIDE：L 左岸 R 右岸 A 全段 */
export const RIVER_SIDE_LABEL: Record<RiverSide, string> = {
  L: '左岸',
  R: '右岸',
  A: '全段',
};

/** 表9 FOU_RIVER_INFO_DOC：行政区与河段位置关系 RIVER_DIST（L/R/T/E，与涌信息表 RIVER_SIDE 取值集不同） */
export type RiverDist = 'L' | 'R' | 'T' | 'E';

export const RIVER_DIST_LABEL: Record<RiverDist, string> = {
  L: '左岸',
  R: '右岸',
  T: '穿境',
  E: '其他',
};

/** FOU_RIVER + 表9 FOU_RIVER_INFO_DOC 自然属性（原型合并于一条责任段记录） */
export interface RiverSectionRow {
  key: string;
  /** SECTION_ID 河段编码 26 位 */
  sectionId: string;
  /** SECTION_NAME */
  sectionName: string;
  /** RIVER_SYSTEM 所属水系 */
  riverSystem: string;
  /** RIVER_SIDE（涌信息表） */
  riverSide: RiverSide;
  /** START_ADDR / END_ADDR */
  startAddr: string;
  endAddr: string;
  /** SENCTION_TYPE */
  sectionType: SectionType;
  /** ADDVCD 行政区划代码 */
  addvcd: string;
  /** ADMIN_LEVEL */
  adminLevel: AdminLevel;
  /** 河段长度 RIVER_LEN，单位 km */
  riverLenKm: number;
  /** 汇水面积 AREA，单位 km² */
  basinAreaKm2: number;
  /** ADMIN_AGENCY 管理机构 */
  adminAgency: string;
  /** INTRODUCTION */
  introduction: string;
  /** REMARKS */
  remarks: string;
  /** 关联展示：河长姓名（规范见 FOU_USER） */
  chiefName: string;
  /** 关联展示：手机 MOBILE */
  chiefMobile: string;

  /**
   * 所属河流（涌）对象编码：与河流信息主表 `RiverChannelMasterRow.riverObjectId` 外键对应。
   * 规范关系：**河段（SECTION_ID，FOU_RIVER/表9 合并台账）** 自属于 **河流（涌）对象**；**上一级河段**仍用 `parentId`（PARENT_ID）表达段际衔接。
   */
  linkedRiverObjectId: string;

  /** —— 以下字段来自表9「一河一档」河流（段）自然属性表 FOU_RIVER_INFO_DOC —— */
  /** PARENT_NAME 上一级河流名称 */
  parentName: string;
  /** PARENT_ID 上一级河段编码 */
  parentId: string;
  /** START_LGTD / START_LTTD 河段起点经度、纬度（°，保留 6 位小数） */
  startLgtd: number;
  startLttd: number;
  /** END_LGTD / END_LTTD 河段讫点经度、纬度（°） */
  endLgtd: number;
  endLttd: number;
  /** RIVER_DIST 行政区与河段位置关系 */
  riverDist: RiverDist;
  /** RUNOFF_VOLUME 多年平均径流量，单位 m³ */
  runoffVolume: number;
  /** LOWFLOW_VOLUME 多年平均枯水期流量，单位 m³/s */
  lowflowVolume: number;
  /** GAUGING_STATION 水文站数量 */
  gaugingStation: number;
  /** LEFT_BRANCH 左岸支流数量 */
  leftBranch: number;
  /** RIGHT_BRANCH 右岸支流数量 */
  rightBranch: number;
}

/**
 * 河流（涌）信息主表 — 对齐 DB4401/T 138—2021 **FOU_RIVER 河流（涌）信息表** 语义（河道对象级）。
 * 与「责任段信息」中按河段（SECTION_ID）维护的分段数据为 **1:N**：责任段 `linkedRiverObjectId` 指向本表 `riverObjectId`；责任段承载几何与表9一河一档属性，本表承载河流通道身份、水系、行政区与管理属性汇总。
 */
export interface RiverChannelMasterRow {
  key: string;
  /** 河流（涌）对象标识/业务主键（对接可与平台河流码、编码规则扩展一致） */
  riverObjectId: string;
  /** 河流（涌）名称，对应规范 SECTION_NAME 语义的干流/涌道名称 */
  riverName: string;
  /** RIVER_SYSTEM 所属水系 */
  riverSystem: string;
  /** RIVER_SIDE：相对上一级河道的岸别，单线河道常用 A 全段 */
  riverSide: RiverSide;
  /** SENCTION_TYPE 主体类型，河道对象多为 1 河流 */
  sectionType: SectionType;
  /** ADDVCD */
  addvcd: string;
  /** ADMIN_LEVEL */
  adminLevel: AdminLevel;
  /** 河流（全流域或市域汇总）河长 km，对应 RIVER_LEN 类度量汇总（原型可手工维护） */
  totalRiverLenKm: number;
  /** 汇水面积 AREA（km²） */
  basinAreaKm2: number;
  /** ADMIN_AGENCY 管理机构 */
  adminAgency: string;
  /**
   * 代表河段编码（可选）：建议填本河流对象下主段或平台默认展示的 SECTION_ID，与责任段表互查。
   */
  representativeSectionId?: string;
  remarks?: string;
}

/**
 * 湖泊信息 — 对齐规范中 **湖泊（含水库）水体** 要素常见字段（原型命名与单位在表单中注明；正式库表以地方入库为准）。
 */
export interface LakeWaterBodyRow {
  key: string;
  /** 湖泊（水体）对象编码 */
  lakeObjectId: string;
  /** 湖泊名称 */
  lakeName: string;
  /** 所属河湖水系或流域 */
  belongHydroSystem: string;
  /** 所在行政区（展示用） */
  regionName: string;
  addvcd: string;
  adminLevel: AdminLevel;
  /** 水体类型：天然湖泊 / 水库 / 塘堰等 */
  lakeCategory: string;
  /** 水面面积（km²） */
  surfaceAreaKm2: number;
  /** 平均水深（m，示意） */
  avgDepthM?: number;
  /** 总库容或蓄水量（万 m³，示意） */
  storage10kM3?: number;
  /** 水功能区或水质目标（文字） */
  waterFuncTarget?: string;
  adminAgency: string;
  /**
   * 主要汇出/相连河流对象编码：外键 `RiverChannelMasterRow.riverObjectId`，表达河湖连通中湖泊与河流的归属或泄流关系（可空）。
   */
  connectedRiverObjectId?: string;
  /**
   * 汇出（或相连）河段编码 SECTION_ID：外键关联责任段台账，精确定位湖口/连通断面所在河段（可空）。
   */
  connectedSectionId?: string;
  /** 河湖连通、补给关系等补充说明（原型文字） */
  lakeRiverRelationNote?: string;
  remarks?: string;
}

/** 巡河记录 · 单条「发现问题」子表 */
export interface PatrolProblemItem {
  /** 问题编号 */
  problemNo: string;
  problemDesc: string;
  /** 上报人员 */
  reporterName: string;
  /** 上报人联系电话 */
  reporterPhone: string;
  /** 发现时间 */
  foundTime: string;
  /** 位置（描述或经纬度文字） */
  location: string;
  /** 图片地址列表（可多图，详情可点击预览） */
  imageUrls: string[];
  /** 视频地址列表（可多条，详情可点击播放） */
  videoUrls: string[];
  handleSuggestion: string;
  /** 是否已整改闭环（统计整改率用；对接后由事务闭环状态回写） */
  rectified?: boolean;
}

/**
 * 表 13 DYN_PATROL 单条「巡检记录」续表字段（含起止时间、距离、时长、起终点经纬度）。
 * 字段代码与水利规范一致：LGTD=经度，LTTD=纬度（°，保留 6 位小数）。
 * 每条巡检记录与一条巡河轨迹一对一（trackSummary / 接口轨迹 ID 由后端回写，原型仅展示）。
 */
export interface PatrolSegmentRecord {
  key: string;
  /** 段级业务编号（如 xxx-S01）；原型表格不展示，保存时按行生成或与历史行保留 */
  segmentPatrolNo: string;
  /** 本段巡检人员（多人） */
  segmentPersonnel: string[];
  /** STRTIME 开始时间 */
  strtime: string;
  /** ENDTIME 结束时间 */
  endtime: string;
  /** DISTANCE 巡河距离 km */
  distanceKm: number;
  /** DURATION 持续时长 min */
  durationMin: number;
  startLgtd: number;
  startLttd: number;
  endLgtd: number;
  endLttd: number;
  /** 与本段一对一的轨迹说明或 GeoJSON 占位 */
  trackSummary: string;
}

/**
 * 一条「巡检信息」：台账头 + 多条巡检记录（segments）+ 发现问题。
 * 列表/详情头字段为整次巡检；时间、距离、轨迹以 segments 为准。
 */
export interface PatrolRecordRow {
  key: string;
  patrolId: string;
  sectionId: string;
  sectionName: string;
  chiefName: string;
  /** 巡河人员（多人） */
  personnel: string[];
  /** 巡河方式 */
  patrolMode: string;
  /** 多条巡检记录，每条与巡河轨迹一对一 */
  segments: PatrolSegmentRecord[];
  problems: PatrolProblemItem[];
  /** 以下字段保留作统计或对接扩展 */
  userId?: string;
}

/** DYN_WATER_QUALITY — 水质监测记录表（水质类别 1–6 类）；与责任段（FOU_RIVER）通过 sectionId / sectionName 关联 */
export interface WaterQualityRow {
  key: string;
  id: string;
  sectionId: string;
  /** 与责任段信息一致的河段名称 */
  sectionName: string;
  /** 区域名称（下拉筛选用短名，如区县） */
  regionShort: string;
  /** 水体名称 */
  waterBody: string;
  /** 所在行政区（完整展示） */
  regionName: string;
  detectionDate: string;
  /** 监测时间 */
  monitorTime: string;
  addvcd: string;
  /** 监测点名称（自动站/人工点等） */
  monitorPointName: string;
  qualityClass: 1 | 2 | 3 | 4 | 5 | 6;
  /** 水温（摄氏度） */
  waterTemp: number;
  /** 酸碱度（无量纲） */
  ph: number;
  /** 溶解氧（毫克每升） */
  dissolvedOxygen: number;
  /** 高锰酸盐指数（毫克每升） */
  permanganate: number;
  /** 氨氮（毫克每升） */
  ammoniaNitrogen: number;
  /** 总磷（毫克每升） */
  totalPhosphorus: number;
}

export const QUALITY_CLASS_LABEL: Record<number, string> = {
  1: 'Ⅰ类',
  2: 'Ⅱ类',
  3: 'Ⅲ类',
  4: 'Ⅳ类',
  5: 'Ⅴ类',
  6: '劣Ⅴ类',
};

export const HC_TYPE_LABEL: Record<number, string> = {
  0: '不予评价',
  1: '无黑臭',
  2: '轻度黑臭',
  3: '重度黑臭',
};

/** 示例数据：河段编码格式参考标准 5.2.2（26 位组合码） */
export const initialRiverSectionData: RiverSectionRow[] = [
  {
    key: '1',
    sectionId: 'AHD030212000000-040110131R',
    sectionName: '湘江长沙岳麓段（右岸）',
    riverSystem: '湘江流域',
    riverSide: 'R',
    startAddr: '橘子洲头',
    endAddr: '月亮岛',
    sectionType: 3,
    addvcd: '430104000000',
    adminLevel: 'B',
    riverLenKm: 58.5,
    basinAreaKm2: 125.6,
    adminAgency: '长沙市河长办',
    introduction: '湘江长沙段重点管护河段，面向下游右岸。',
    remarks: '示范河段',
    chiefName: '张伟',
    chiefMobile: '138****1234',
    linkedRiverObjectId: 'ROV-AHD030212-XJ-MAIN',
    parentName: '湘江干流',
    parentId: 'AHD030212000000-040110000A',
    startLgtd: 112.965432,
    startLttd: 28.200128,
    endLgtd: 112.881256,
    endLttd: 28.245612,
    riverDist: 'R',
    runoffVolume: 2850000000,
    lowflowVolume: 128.5,
    gaugingStation: 3,
    leftBranch: 2,
    rightBranch: 4,
  },
  {
    key: '2',
    sectionId: 'AHD030338000000-13011T012A',
    sectionName: '浏阳河城区段（全段）',
    riverSystem: '浏阳河流域',
    riverSide: 'A',
    startAddr: '城区上游断面',
    endAddr: '城区下游闸坝',
    sectionType: 2,
    addvcd: '430181000000',
    adminLevel: 'B',
    riverLenKm: 32.8,
    basinAreaKm2: 68.4,
    adminAgency: '浏阳市河长办',
    introduction: '浏阳河城区黑臭水体治理巩固段。',
    remarks: '',
    chiefName: '李强',
    chiefMobile: '139****5678',
    linkedRiverObjectId: 'ROV-AHD030338-LYH',
    parentName: '浏阳河',
    parentId: 'AHD030338000000-130110000A',
    startLgtd: 113.051234,
    startLttd: 28.148956,
    endLgtd: 113.018765,
    endLttd: 28.182341,
    riverDist: 'T',
    runoffVolume: 920000000,
    lowflowVolume: 45.2,
    gaugingStation: 2,
    leftBranch: 1,
    rightBranch: 1,
  },
  {
    key: '3',
    sectionId: 'AHD030121000000-110050021L',
    sectionName: '捞刀河下游段（左岸）',
    riverSystem: '捞刀河流域',
    riverSide: 'L',
    startAddr: '支流汇入口',
    endAddr: '湘江汇入口',
    sectionType: 4,
    addvcd: '430121000000',
    adminLevel: 'C',
    riverLenKm: 28.3,
    basinAreaKm2: 52.1,
    adminAgency: '长沙县水利局',
    introduction: '捞刀河下游岸线管护。',
    remarks: '',
    chiefName: '王明',
    chiefMobile: '137****9012',
    linkedRiverObjectId: 'ROV-AHD030121-LDH',
    parentName: '捞刀河',
    parentId: 'AHD030121000000-110110000A',
    startLgtd: 113.082156,
    startLttd: 28.352089,
    endLgtd: 113.045678,
    endLttd: 28.318234,
    riverDist: 'L',
    runoffVolume: 410000000,
    lowflowVolume: 22.8,
    gaugingStation: 1,
    leftBranch: 0,
    rightBranch: 2,
  },
  {
    key: '4',
    sectionId: 'AHD030112000000-180060031A',
    sectionName: '靳江河段',
    riverSystem: '靳江流域',
    riverSide: 'A',
    startAddr: '靳江源头',
    endAddr: '汇入湘江口',
    sectionType: 1,
    addvcd: '430112000000',
    adminLevel: 'B',
    riverLenKm: 45.2,
    basinAreaKm2: 89.7,
    adminAgency: '望城区河长办',
    introduction: '靳江河长制责任河段。',
    remarks: '预警关注',
    chiefName: '刘芳',
    chiefMobile: '136****3456',
    linkedRiverObjectId: 'ROV-AHD030112-JJ',
    parentName: '靳江',
    parentId: 'AHD030112000000-180060000A',
    startLgtd: 112.852341,
    startLttd: 28.118765,
    endLgtd: 112.889012,
    endLttd: 28.156234,
    riverDist: 'T',
    runoffVolume: 380000000,
    lowflowVolume: 18.6,
    gaugingStation: 1,
    leftBranch: 3,
    rightBranch: 2,
  },
];

/** 示例：FOU_RIVER 层河流（涌）主数据（与 initialRiverSectionData 中 parentName/水系可对应） */
export const initialRiverChannelMasterData: RiverChannelMasterRow[] = [
  {
    key: 'rch-1',
    riverObjectId: 'ROV-AHD030212-XJ-MAIN',
    riverName: '湘江干流',
    riverSystem: '湘江流域',
    riverSide: 'A',
    sectionType: 1,
    addvcd: '430100000000',
    adminLevel: 'B',
    totalRiverLenKm: 143.6,
    basinAreaKm2: 956.2,
    adminAgency: '长沙市河长办',
    representativeSectionId: 'AHD030212000000-040110131R',
    remarks: '示例：与责任段「湘江长沙岳麓段」同属湘江流域。',
  },
  {
    key: 'rch-2',
    riverObjectId: 'ROV-AHD030338-LYH',
    riverName: '浏阳河',
    riverSystem: '浏阳河流域',
    riverSide: 'A',
    sectionType: 1,
    addvcd: '430181000000',
    adminLevel: 'B',
    totalRiverLenKm: 224.0,
    basinAreaKm2: 412.5,
    adminAgency: '浏阳市河长办',
    representativeSectionId: 'AHD030338000000-13011T012A',
    remarks: '示例：城区段责任段已建档。',
  },
  {
    key: 'rch-3',
    riverObjectId: 'ROV-AHD030121-LDH',
    riverName: '捞刀河',
    riverSystem: '捞刀河流域',
    riverSide: 'A',
    sectionType: 1,
    addvcd: '430121000000',
    adminLevel: 'C',
    totalRiverLenKm: 108.0,
    basinAreaKm2: 268.0,
    adminAgency: '长沙县水利局',
    representativeSectionId: 'AHD030121000000-110050021L',
    remarks: '',
  },
  {
    key: 'rch-4',
    riverObjectId: 'ROV-AHD030112-JJ',
    riverName: '靳江',
    riverSystem: '靳江流域',
    riverSide: 'A',
    sectionType: 1,
    addvcd: '430112000000',
    adminLevel: 'B',
    totalRiverLenKm: 45.2,
    basinAreaKm2: 89.7,
    adminAgency: '望城区河长办',
    representativeSectionId: 'AHD030112000000-180060031A',
    remarks: '示例：与责任段表河段编码族一致。',
  },
];

/** 示例：湖泊（水库）水体主数据 */
export const initialLakeWaterBodyData: LakeWaterBodyRow[] = [
  {
    key: 'lk-1',
    lakeObjectId: 'LK-430382-QNSK-001',
    lakeName: '青年水库',
    belongHydroSystem: '韶河流域',
    regionName: '湖南省湘潭市韶山市',
    addvcd: '430382000000',
    adminLevel: 'C',
    lakeCategory: '水库',
    surfaceAreaKm2: 2.8,
    avgDepthM: 12.5,
    storage10kM3: 1860,
    waterFuncTarget: '饮用水水源二级保护区（示意）',
    adminAgency: '韶山市水利局',
    lakeRiverRelationNote: '韶河流域汇出河段可在河流主数据扩展后补充 connectedRiverObjectId / connectedSectionId。',
    remarks: '与韶山片区河长制示范数据配套。',
  },
  {
    key: 'lk-2',
    lakeObjectId: 'LK-430104-YZL-001',
    lakeName: '洋湖湿地公园湖泊',
    belongHydroSystem: '湘江流域',
    regionName: '湖南省长沙市岳麓区',
    addvcd: '430104000000',
    adminLevel: 'B',
    lakeCategory: '天然湖泊（城市湿地）',
    surfaceAreaKm2: 4.85,
    avgDepthM: 2.2,
    storage10kM3: undefined,
    waterFuncTarget: '景观娱乐用水区',
    adminAgency: '岳麓区河长办',
    connectedRiverObjectId: 'ROV-AHD030212-XJ-MAIN',
    connectedSectionId: 'AHD030212000000-040110131R',
    lakeRiverRelationNote: '城市湿地经湘西联络河等与湘江干流连通，泄水关联至示例湘江岳麓责任段。',
    remarks: '',
  },
  {
    key: 'lk-3',
    lakeObjectId: 'LK-430181-DTH-001',
    lakeName: '道吾山天池（示意）',
    belongHydroSystem: '浏阳河流域',
    regionName: '湖南省长沙市浏阳市',
    addvcd: '430181000000',
    adminLevel: 'C',
    lakeCategory: '天然湖泊',
    surfaceAreaKm2: 0.35,
    avgDepthM: 8.0,
    storage10kM3: 28,
    waterFuncTarget: '一般湿地保护',
    adminAgency: '浏阳市水利局',
    connectedRiverObjectId: 'ROV-AHD030338-LYH',
    connectedSectionId: 'AHD030338000000-13011T012A',
    lakeRiverRelationNote: '示意：山洪径流汇入浏阳河城区段责任河段。',
    remarks: '原型演示用高山湖泊要素。',
  },
];

export const initialPatrolData: PatrolRecordRow[] = [
  {
    key: 'p1',
    patrolId: 'PATROL-20240615-001',
    sectionId: 'AHD030212000000-040110131R',
    sectionName: '湘江长沙岳麓段（右岸）',
    userId: 'USER-001',
    chiefName: '张伟',
    personnel: ['张伟', '河长办巡查员李某', '保洁对接王某'],
    patrolMode: '步行巡河',
    segments: [
      {
        key: 'p1-s1',
        segmentPatrolNo: 'PATROL-20240615-001-S01',
        segmentPersonnel: ['张伟', '河长办巡查员李某'],
        strtime: '2024-06-15 08:30:00',
        endtime: '2024-06-15 09:15:00',
        distanceKm: 3.1,
        durationMin: 45,
        startLgtd: 112.965432,
        startLttd: 28.200128,
        endLgtd: 112.9482,
        endLttd: 28.2156,
        trackSummary: '橘子洲头—滨江步道北段，GPS 折线示意。',
      },
      {
        key: 'p1-s2',
        segmentPatrolNo: 'PATROL-20240615-001-S02',
        segmentPersonnel: ['张伟', '保洁对接王某'],
        strtime: '2024-06-15 09:20:00',
        endtime: '2024-06-15 10:15:00',
        distanceKm: 3.1,
        durationMin: 55,
        startLgtd: 112.9482,
        startLttd: 28.2156,
        endLgtd: 112.931,
        endLttd: 28.2289,
        trackSummary: '观沙岭段岸线复查，途经排污口巡查点。',
      },
    ],
    problems: [
      {
        problemNo: 'PRB-20240615-001',
        problemDesc: '岸线漂浮少量枯枝与塑料袋',
        reporterName: '李某',
        reporterPhone: '139****7788',
        foundTime: '2024-06-15 09:05:00',
        location: '湘江长沙岳麓段（右岸）K2+100 栈桥上游约 30m',
        imageUrls: [
          'https://picsum.photos/seed/eco-p1a/640/400',
          'https://picsum.photos/seed/eco-p1b/640/400',
        ],
        videoUrls: [],
        handleSuggestion: '通知属地保洁单位24 小时内清理并拍照反馈。',
        rectified: true,
      },
      {
        problemNo: 'PRB-20240615-002',
        problemDesc: '观沙岭段护栏一处松动',
        reporterName: '河长办巡查员赵某',
        reporterPhone: '137****1122',
        foundTime: '2024-06-15 09:42:00',
        location: '观沙岭堤段桩号 3+050 北侧护栏',
        imageUrls: ['https://picsum.photos/seed/eco-p1c/640/400'],
        videoUrls: ['https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4'],
        handleSuggestion: '报市政维护，设置临时警示，7 日内完成加固。',
        rectified: false,
      },
    ],
  },
  {
    key: 'p2',
    patrolId: 'PATROL-20240614-002',
    sectionId: 'AHD030338000000-13011T012A',
    sectionName: '浏阳河城区段（全段）',
    userId: 'USER-002',
    chiefName: '李强',
    personnel: ['李强', '生态环境局张某'],
    patrolMode: '车巡+步行',
    segments: [
      {
        key: 'p2-s1',
        segmentPatrolNo: 'PATROL-20240614-002-S01',
        segmentPersonnel: ['李强'],
        strtime: '2024-06-14 14:00:00',
        endtime: '2024-06-14 15:00:00',
        distanceKm: 2.4,
        durationMin: 60,
        startLgtd: 113.051234,
        startLttd: 28.148956,
        endLgtd: 113.042,
        endLttd: 28.159,
        trackSummary: '堤顶路车巡段（东岸）。',
      },
      {
        key: 'p2-s2',
        segmentPatrolNo: 'PATROL-20240614-002-S02',
        segmentPersonnel: ['李强', '生态环境局张某'],
        strtime: '2024-06-14 15:05:00',
        endtime: '2024-06-14 16:20:00',
        distanceKm: 2.4,
        durationMin: 75,
        startLgtd: 113.042,
        startLttd: 28.159,
        endLgtd: 113.035,
        endLttd: 28.168,
        trackSummary: '桥下空间步行核查段，与本段轨迹一对一。',
      },
    ],
    problems: [
      {
        problemNo: 'PRB-20240614-001',
        problemDesc: '桥下空间堆放建筑垃圾',
        reporterName: '张某',
        reporterPhone: '136****5566',
        foundTime: '2024-06-14 15:10:00',
        location: '浏阳河城区段××桥下东南侧空地',
        imageUrls: [
          'https://picsum.photos/seed/eco-p2a/640/400',
          'https://picsum.photos/seed/eco-p2b/640/400',
          'https://picsum.photos/seed/eco-p2c/640/400',
        ],
        videoUrls: [],
        handleSuggestion: '移交城管执法核查来源，限期清运并加强巡查。',
        rectified: false,
      },
    ],
  },
  {
    key: 'p3',
    patrolId: 'PATROL-20240613-003',
    sectionId: 'AHD030121000000-110050021L',
    sectionName: '捞刀河下游段（左岸）',
    userId: 'USER-003',
    chiefName: '王明',
    personnel: ['王明'],
    patrolMode: '步行巡河',
    segments: [
      {
        key: 'p3-s1',
        segmentPatrolNo: 'PATROL-20240613-003-S01',
        segmentPersonnel: ['王明'],
        strtime: '2024-06-13 09:00:00',
        endtime: '2024-06-13 09:45:00',
        distanceKm: 2.1,
        durationMin: 45,
        startLgtd: 113.082156,
        startLttd: 28.352089,
        endLgtd: 113.068,
        endLttd: 28.338,
        trackSummary: '左岸堤防单程，无涉水作业；轨迹由接口绘制。',
      },
    ],
    problems: [
      {
        problemNo: 'PRB-20240613-001',
        problemDesc: '农业面源沟渠雨后浑浊入河',
        reporterName: '王明',
        reporterPhone: '135****8899',
        foundTime: '2024-06-13 09:18:00',
        location: '捞刀河下游左岸××村排沟入河口',
        imageUrls: [],
        videoUrls: [
          'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4',
        ],
        handleSuggestion: '农业农村部门跟进沟渠清淤与田埂缓冲带建设。',
        rectified: true,
      },
    ],
  },
];

export const initialWaterQualityData: WaterQualityRow[] = [
  {
    key: 'w1',
    id: 'WQ-20240601-001',
    sectionId: 'AHD030212000000-040110131R',
    sectionName: '湘江长沙岳麓段（右岸）',
    regionShort: '岳麓区',
    waterBody: '湘江干流',
    regionName: '湖南省长沙市岳麓区',
    detectionDate: '2024-06-01',
    monitorTime: '2024-06-01 12:00',
    addvcd: '430104000000',
    monitorPointName: '岳麓段右岸主河道自动监测点',
    qualityClass: 3,
    waterTemp: 22.4,
    ph: 7.6,
    dissolvedOxygen: 7.8,
    permanganate: 3.2,
    ammoniaNitrogen: 0.42,
    totalPhosphorus: 0.08,
  },
  {
    key: 'w2',
    id: 'WQ-20240601-002',
    sectionId: 'AHD030338000000-13011T012A',
    sectionName: '浏阳河城区段（全段）',
    regionShort: '浏阳市',
    waterBody: '浏阳河',
    regionName: '湖南省长沙市浏阳市',
    detectionDate: '2024-06-01',
    monitorTime: '2024-06-01 12:00',
    addvcd: '430181000000',
    monitorPointName: '城区段中游浮标站',
    qualityClass: 4,
    waterTemp: 23.1,
    ph: 7.4,
    dissolvedOxygen: 6.5,
    permanganate: 4.1,
    ammoniaNitrogen: 0.85,
    totalPhosphorus: 0.12,
  },
  {
    key: 'w3',
    id: 'WQ-20240515-003',
    sectionId: 'AHD030112000000-180060031A',
    sectionName: '靳江河段',
    regionShort: '望城区',
    waterBody: '靳江',
    regionName: '湖南省长沙市望城区',
    detectionDate: '2024-05-15',
    monitorTime: '2024-05-15 12:00',
    addvcd: '430112000000',
    monitorPointName: '靳江控制断面自动站',
    qualityClass: 5,
    waterTemp: 24.0,
    ph: 7.2,
    dissolvedOxygen: 5.1,
    permanganate: 5.6,
    ammoniaNitrogen: 1.15,
    totalPhosphorus: 0.18,
  },
  {
    key: 'w4',
    id: 'WQ-20240610-004',
    sectionId: 'AHD030121000000-110050021L',
    sectionName: '捞刀河下游段（左岸）',
    regionShort: '长沙县',
    waterBody: '捞刀河',
    regionName: '湖南省长沙市长沙县',
    detectionDate: '2024-06-10',
    monitorTime: '2024-06-10 08:00',
    addvcd: '430121000000',
    monitorPointName: '捞刀河入湘江汇口左岸站',
    qualityClass: 4,
    waterTemp: 21.8,
    ph: 7.5,
    dissolvedOxygen: 6.9,
    permanganate: 3.8,
    ammoniaNitrogen: 0.55,
    totalPhosphorus: 0.09,
  },
];

/** FOU_USER 用户类型 USER_TYPE（节选，规范表 8） */
export const USER_TYPE_LABEL: Record<number, string> = {
  1: '市第一总河长',
  2: '市总河长',
  3: '市副总河长',
  4: '市河长',
  5: '区总河长',
  6: '区副总河长',
  7: '区河长',
  8: '镇（街）总河长',
  9: '镇（街）副总河长',
  10: '镇（街）河长',
  11: '村（居）河长',
};

// ==================== 河长通讯录（标准化台账，合并 FOU_USER 等字段） ====================

/** 通讯录人员大类：各级河长 / 管护人员 / 相关部门负责人 */
export type ContactRoleCategory = 'chief' | 'custodian' | 'department';

export const CONTACT_ROLE_LABEL: Record<ContactRoleCategory, string> = {
  chief: '河长',
  custodian: '管护人员',
  department: '部门负责人',
};

/** 部门类型（便于按条线查询、应急联动） */
export const CONTACT_DEPT_TYPES = [
  '河湖长办',
  '水务（水利）',
  '生态环境',
  '应急管理',
  '农业农村',
  '其他',
] as const;

/** 责任区域筛选项（示意，可与责任段/行政区划关联） */
export const CONTACT_AREA_OPTIONS = [
  '全市',
  '清溪镇',
  '银田镇',
  '韶山乡',
  '高新区',
  '韶河省控断面流域',
  '东郊水库汇水范围',
  '长沙市岳麓区',
  '浏阳市城区',
  '长沙县',
  '长沙市望城区',
];

export interface RiverChiefContactRow {
  id: string;
  /** FOU_USER.USER_ID，对接平台用户唯一标识（通讯录与河湖长用户主数据合并后必填） */
  userId: string;
  name: string;
  roleCategory: ContactRoleCategory;
  /** 河长级别：对应 USER_TYPE；非河长为 null */
  userType: number | null;
  areaName: string;
  deptType: string;
  orgName: string;
  title: string;
  mobile: string;
  tel: string;
  officeAddr?: string;
  /** FOU_USER.ADDVCD 行政区划代码 */
  addvcd?: string;
  /** 关联责任河段 SECTION_ID（履职范围示意） */
  sectionId?: string;
  email?: string;
  remarks?: string;
}

/** 示例通讯录（各级河长、管护、部门负责人；含合并后的 FOU_USER 字段） */
export const initialRiverChiefContacts: RiverChiefContactRow[] = [
  {
    id: 'c1',
    userId: 'USER-SS-0001',
    name: '陈国华',
    roleCategory: 'chief',
    userType: 2,
    areaName: '全市',
    deptType: '河湖长办',
    orgName: '韶山市河长制工作委员会办公室',
    title: '市总河长',
    mobile: '138****0101',
    tel: '0731-5678****',
    officeAddr: '市政府大楼 A 座 8 层',
    addvcd: '430382000000',
  },
  {
    id: 'c2',
    userId: 'USER-SS-0002',
    name: '李秀英',
    roleCategory: 'chief',
    userType: 7,
    areaName: '清溪镇',
    deptType: '河湖长办',
    orgName: '清溪镇人民政府',
    title: '区河长',
    mobile: '139****0202',
    tel: '0731-5566****',
    officeAddr: '清溪镇行政服务中心',
    addvcd: '430382000000',
  },
  {
    id: 'c3',
    userId: 'USER-SS-0003',
    name: '王强',
    roleCategory: 'chief',
    userType: 10,
    areaName: '银田镇',
    deptType: '河湖长办',
    orgName: '银田镇河长办',
    title: '镇（街）河长',
    mobile: '137****0303',
    tel: '0731-5577****',
    officeAddr: '银田镇水利服务站',
    addvcd: '430382000000',
  },
  {
    id: 'c4',
    userId: 'USER-SS-0004',
    name: '赵敏',
    roleCategory: 'chief',
    userType: 11,
    areaName: '韶山乡',
    deptType: '河湖长办',
    orgName: '韶山乡农业农村办',
    title: '村（居）河长',
    mobile: '136****0404',
    tel: '—',
    officeAddr: '韶山乡水利协管站',
    addvcd: '430382000000',
  },
  {
    id: 'c5',
    userId: 'USER-SS-0005',
    name: '周伟',
    roleCategory: 'custodian',
    userType: null,
    areaName: '韶河省控断面流域',
    deptType: '水务（水利）',
    orgName: '市水利综合服务中心',
    title: '河道管护员',
    mobile: '135****0505',
    tel: '0731-5688****',
    officeAddr: '河道管理站值班室',
    addvcd: '430382000000',
  },
  {
    id: 'c6',
    userId: 'USER-SS-0006',
    name: '吴静',
    roleCategory: 'custodian',
    userType: null,
    areaName: '东郊水库汇水范围',
    deptType: '水务（水利）',
    orgName: '水库管理所',
    title: '水库巡查员',
    mobile: '134****0606',
    tel: '0731-5699****',
    addvcd: '430382000000',
  },
  {
    id: 'c7',
    userId: 'USER-SS-0007',
    name: '郑涛',
    roleCategory: 'department',
    userType: null,
    areaName: '全市',
    deptType: '生态环境',
    orgName: '市生态环境局韶山分局',
    title: '水环境应急联系人',
    mobile: '133****0707',
    tel: '0731-12369',
    officeAddr: '分局水生态环境股',
    addvcd: '430382000000',
  },
  {
    id: 'c8',
    userId: 'USER-SS-0008',
    name: '孙丽',
    roleCategory: 'department',
    userType: null,
    areaName: '全市',
    deptType: '应急管理',
    orgName: '市应急管理局',
    title: '防汛抗旱联络员',
    mobile: '132****0808',
    tel: '0731-5110****',
    addvcd: '430382000000',
  },
  {
    id: 'c9',
    userId: 'USER-SS-0009',
    name: '马军',
    roleCategory: 'department',
    userType: null,
    areaName: '高新区',
    deptType: '农业农村',
    orgName: '高新区社会事务局',
    title: '涉农涉水协调',
    mobile: '131****0909',
    tel: '0731-5777****',
    addvcd: '430382000000',
  },
  {
    id: 'c10',
    userId: 'USER-SS-0010',
    name: '林峰',
    roleCategory: 'chief',
    userType: 4,
    areaName: '全市',
    deptType: '河湖长办',
    orgName: '市水利局',
    title: '市河长（联系部门）',
    mobile: '130****1010',
    tel: '0731-5600****',
    officeAddr: '市水利局河长制工作科',
    addvcd: '430382000000',
  },
  {
    id: 'c11',
    userId: 'USER-RC-2024001',
    name: '张伟',
    roleCategory: 'chief',
    userType: 7,
    areaName: '长沙市岳麓区',
    deptType: '河湖长办',
    orgName: '长沙市岳麓区河长办',
    title: '区级河长',
    mobile: '138****1234',
    tel: '—',
    addvcd: '430104000000',
    sectionId: 'AHD030212000000-040110131R',
    email: 'zhangwei@example.gov.cn',
    remarks: '与责任段「湘江长沙岳麓段」台账关联示意。',
  },
  {
    id: 'c12',
    userId: 'USER-RC-2024002',
    name: '李强',
    roleCategory: 'chief',
    userType: 10,
    areaName: '浏阳市城区',
    deptType: '河湖长办',
    orgName: '浏阳市城区河长办',
    title: '镇（街）河长',
    mobile: '139****5678',
    tel: '—',
    addvcd: '430181000000',
    sectionId: 'AHD030338000000-13011T012A',
    email: 'liqiang@example.gov.cn',
  },
  {
    id: 'c13',
    userId: 'USER-RC-2024003',
    name: '王明',
    roleCategory: 'chief',
    userType: 10,
    areaName: '长沙县',
    deptType: '河湖长办',
    orgName: '长沙县水利局',
    title: '镇级河长联络员',
    mobile: '137****9012',
    tel: '—',
    addvcd: '430121000000',
    sectionId: 'AHD030121000000-110050021L',
  },
  {
    id: 'c14',
    userId: 'USER-RC-2024004',
    name: '刘芳',
    roleCategory: 'chief',
    userType: 7,
    areaName: '长沙市望城区',
    deptType: '河湖长办',
    orgName: '长沙市望城区河长办',
    title: '区级河长',
    mobile: '136****3456',
    tel: '—',
    addvcd: '430112000000',
    sectionId: 'AHD030112000000-180060031A',
    email: 'liufang@example.gov.cn',
    remarks: '预警关注河段责任人。',
  },
  {
    id: 'c15',
    userId: 'USER-SS-0011',
    name: '李娜',
    roleCategory: 'chief',
    userType: 7,
    areaName: '清溪镇',
    deptType: '河湖长办',
    orgName: '清溪镇人民政府',
    title: '区级河长（接任）',
    mobile: '138****1111',
    tel: '0731-5566****',
    officeAddr: '清溪镇行政服务中心',
    addvcd: '430382000000',
    remarks: '河长变更记录示例：接任河长。',
  },
];

/** 信息来源（对齐规范上报事件「来源」类语义） */
export const RIVER_GUARD_INFO_SOURCES = [
  '河长制信息系统',
  '巡河台账',
  '电话举报',
  '网络及热线',
  '上级交办',
  '部门移送',
  '媒体舆情',
  '其他',
] as const;

/** 处理状态 */
export const RIVER_GUARD_HANDLE_STATUS = ['待分派', '处置中', '待验收', '已办结', '已退回'] as const;

/** 严重程度 */
export const RIVER_GUARD_SEVERITY = ['一般', '较重', '紧急'] as const;

/**
 * 上报事件问题类型（对齐 DB4401/T 138—2021《河（湖）长制管理信息系统数据规范》**上报事件表**「问题类型」代码表语义：
 * 以河湖「清四乱」（乱占、乱采、乱堆、乱建）为纲，并列入水面保洁、排污与排水、水质异常等常见类别；正式入库以规范字典代码为准，原型用中文展示值。
 */
export const RIVER_GUARD_PROBLEM_TYPES = [
  '乱占',
  '乱采',
  '乱堆',
  '乱建',
  '水面漂浮物及保洁问题',
  '排污口与违法排污',
  '排水与溢流问题',
  '水质异常',
  '其他',
] as const;

/**
 * 事务列表/上报事件表单专用问题类型（业务口径；末项「其他」需在表单中补充输入具体类型）
 */
export const RIVER_GUARD_AFFAIR_EVENT_PROBLEM_TYPES = [
  '工业废水排放',
  '养殖污染',
  '排水设施',
  '违法建设',
  '农家乐',
  '建筑废弃物',
  '堆场码头',
  '工程维护',
  '生活垃圾',
  '其他',
] as const;

/** 将台账中的 problemType 拆成表单：预设项直接选中，否则归为「其他」并填入输入框 */
export function resolveAffairProblemTypeForForm(stored: string): { select: string; other: string } {
  const presets = RIVER_GUARD_AFFAIR_EVENT_PROBLEM_TYPES as readonly string[];
  if (presets.includes(stored)) {
    return { select: stored, other: '' };
  }
  return { select: '其他', other: stored };
}

export const RIVER_GUARD_REGION_OPTIONS = [
  '韶山市',
  '长沙市岳麓区',
  '浏阳市',
  '长沙县',
  '长沙市望城区',
  '清溪镇',
  '银田镇',
] as const;

/** 韶山市及下辖镇乡（事务登记「所属区域」下拉；编码为原型示意，对接以民政发布为准） */
export const SHAOSHAN_ADDVCD_OPTIONS: { value: string; label: string }[] = [
  { value: '430382000000', label: '韶山市（市本级）' },
  { value: '430382100000', label: '清溪镇' },
  { value: '430382101000', label: '银田镇' },
  { value: '430382102000', label: '韶山乡' },
  { value: '430382103000', label: '杨林乡' },
];

export function getShaoshanAddvcdLabel(code: string | undefined | null): string {
  if (!code?.trim()) return '—';
  const c = code.trim();
  const hit = SHAOSHAN_ADDVCD_OPTIONS.find(o => o.value === c);
  return hit ? hit.label : c;
}

/** 下拉选项：含台账中不在清单内的历史区划编码 */
export function shaoshanAddvcdSelectOptionsWithLegacy(legacyCode: string | undefined | null): {
  value: string;
  label: string;
}[] {
  const cur = (legacyCode ?? '').trim();
  if (!cur || SHAOSHAN_ADDVCD_OPTIONS.some(o => o.value === cur)) {
    return SHAOSHAN_ADDVCD_OPTIONS;
  }
  return [...SHAOSHAN_ADDVCD_OPTIONS, { value: cur, label: `${cur}（台账）` }];
}

/** 河湖管护事务处置信息（规范中处置过程类字段，原型嵌套） */
export interface RiverGuardAffairDisposal {
  /** 处置负责人 */
  disposalLeader: string;
  contactPhone: string;
  disposalDescribe: string;
  completedTime: string;
  images: string[];
}

/**
 * 河湖管护事务台账（字段参考 DB4401/T 138—2021 上报事件表扩展）。
 * 原型「基本信息」表单顺序（纵向布局 + 栅格，与应急协同应急事件编辑一致）：事务编号（只读）与事务名称同一行 → 关联责任段 → **所属区域**（`addvcd`）→ 问题类型 → **信息来源与严重程度**（同一行）→ **责任主体与责任人**（同一行）→ 位置与地图经纬度（台账可保留 `deadline`，编辑表单不维护）
 * → **上报信息**（两行：上报人/联系电话、发现时间/上报时间）→ 问题描述与影响范围 → 现场照片与本地上传视频（无「分级与责任」等分隔标题）。台账仍保留 `situationDescribe` 等历史字段（编辑表单不展示）；`regionName` 可由所属区域选择结果同步。**处理状态、办结日期**及处置过程见「事务处置」Tab。
 */
export interface RiverGuardAffairRow {
  key: string;
  /** 事务编号 */
  affairCode: string;
  /** 事务名称 */
  affairTitle: string;
  /** 事务发起时间 */
  initiateTime: string;
  /** 发起主体（单位/个人/平台等） */
  initiateSubject: string;
  /** 交办单位 */
  assignOrg: string;
  /** 承办单位 */
  undertakeOrg: string;
  /** 问题描述（概要，可与情况描述并存） */
  problemDescribe: string;
  /** 现场照片（登记阶段，原型多为 data URL） */
  scenePhotos: string[];
  /** 视频链接列表 */
  sceneVideos: string[];
  /** 关联责任段河段编码，可空 */
  sectionId: string;
  problemType: string;
  infoSource: string;
  /** 发现时间 */
  discoverTime: string;
  /** 上报时间 */
  reportTime: string;
  /** 要求完成时间 */
  deadline: string;
  addvcd: string;
  regionName: string;
  location: string;
  longitude: string;
  latitude: string;
  situationDescribe: string;
  impactScope: string;
  severity: string;
  reporterName: string;
  reporterPhone: string;
  handleStatus: string;
  responsibleOrg: string;
  leaderName: string;
  /** 是否先行处置 */
  preemptDisposal: string;
  disposalProgress: string;
  /** 处理措施 */
  measuresTaken: string;
  /** 处理过程 */
  handlingProcess: string;
  /** 联动部门或单位 */
  coordParties: string;
  /** 处理结果 */
  disposalResult: string;
  /** 反馈意见（上级、群众或平台回访等） */
  feedbackComment: string;
  /** 办结日期 */
  finishDate: string;
  disposal: RiverGuardAffairDisposal;
}

export const initialRiverGuardAffairs: RiverGuardAffairRow[] = [
  {
    key: 'aff-1',
    affairCode: 'HB-SW-2025-0015',
    affairTitle: '韶河清溪段岸线堆存建筑垃圾',
    initiateTime: '2025-03-08 09:15',
    initiateSubject: '清溪镇河长办',
    assignOrg: '',
    undertakeOrg: '清溪镇综合执法办',
    problemDescribe: '堤脚闲置地块堆存砖渣与包装袋约30㎡，降雨有冲刷入河风险。',
    scenePhotos: [],
    sceneVideos: [],
    sectionId: 'AHD030382000000-010020031L',
    problemType: '建筑废弃物',
    infoSource: '巡河台账',
    discoverTime: '2025-03-08 09:20',
    reportTime: '2025-03-08 10:05',
    deadline: '2025-03-20',
    addvcd: '430382000000',
    regionName: '韶山市',
    location: '韶河清溪镇段右岸堤脚闲置地块',
    longitude: '112.528600',
    latitude: '27.914200',
    situationDescribe: '镇级河长巡河发现堤脚堆存砖渣与包装袋约30㎡，距主槽约 8 米，降雨存在冲刷入河风险。',
    impactScope: '可能影响近岸水质感官与行洪断面',
    severity: '较重',
    reporterName: '李秀英',
    reporterPhone: '139****0202',
    handleStatus: '处置中',
    responsibleOrg: '清溪镇综合执法办、镇河长办',
    leaderName: '镇分管负责人',
    preemptDisposal: '是',
    disposalProgress: '已约谈当事人，责令 3 日内清运并覆盖防尘网',
    measuresTaken: '现场拍照取证；下达整改通知书；网格员每日巡查打卡',
    handlingProcess: '当日现场复核并约谈当事人；责令3日内清运；网格员每日打卡直至销号。',
    coordParties: '市水利局河长科（督导）',
    disposalResult: '',
    feedbackComment: '',
    finishDate: '',
    disposal: {
      disposalLeader: '镇综合执法办联络员',
      contactPhone: '0731-5566****',
      disposalDescribe: '清运完成后再测岸坡，确认无残留后销号',
      completedTime: '',
      images: [],
    },
  },
  {
    key: 'aff-2',
    affairCode: 'HB-SW-2025-0088',
    affairTitle: '群众举报支流排水口雨天冒溢',
    initiateTime: '2025-04-02 13:40',
    initiateSubject: '12345政务服务热线',
    assignOrg: '市城管执法局',
    undertakeOrg: '市住建局排水中心',
    problemDescribe: '强降雨时涵口浑浊水涌出伴异味，怀疑雨污混接。',
    scenePhotos: [],
    sceneVideos: [],
    sectionId: 'AHD030338000000-13011T012A',
    problemType: '排水设施',
    infoSource: '电话举报',
    discoverTime: '2025-04-02 14:00',
    reportTime: '2025-04-02 15:30',
    deadline: '2025-04-15',
    addvcd: '430181000000',
    regionName: '浏阳市',
    location: '浏阳河城区段某支涵汇入点下游50 米',
    longitude: '113.643100',
    latitude: '28.141500',
    situationDescribe: '市民反映强降雨时涵口有浑浊水涌出，伴有异味，怀疑雨污混接。',
    impactScope: '支流汇口下游约 1.2 千米河段',
    severity: '紧急',
    reporterName: '匿名（热线登记）',
    reporterPhone: '12345转办',
    handleStatus: '待验收',
    responsibleOrg: '市住建局排水中心、区河长办',
    leaderName: '排水运维专班负责人',
    preemptDisposal: '否',
    disposalProgress: '已完成 CCTV 排查，发现支管错接1 处，正在切改',
    measuresTaken: '临时抽排与水质快检；错接点封堵；编制整改方案',
    handlingProcess: '热线转办→排水中心接单→CCTV 排查定位错接→切改施工→快检跟踪。',
    coordParties: '生态环境分局',
    disposalResult: '错接整改完成后组织联合验收',
    feedbackComment: '举报人要求公示整改摘要（待验收后统一回复）。',
    finishDate: '',
    disposal: {
      disposalLeader: '排水中心运维班长',
      contactPhone: '0731-8366****',
      disposalDescribe: '验收通过后更新排口台账并向社会公示摘要',
      completedTime: '2025-04-10 17:00',
      images: [],
    },
  },
  {
    key: 'aff-3',
    affairCode: 'HB-SW-2025-0120',
    affairTitle: '省河长办交办疑似非法采砂线索核查',
    initiateTime: '2025-04-12 07:30',
    initiateSubject: '省河长制管理信息系统',
    assignOrg: '省河长办',
    undertakeOrg: '岳麓区水利局',
    problemDescribe: '卫星疑似堆砂图斑，需县级现场核查并限时反馈。',
    scenePhotos: [],
    sceneVideos: [],
    sectionId: '',
    problemType: '堆场码头',
    infoSource: '上级交办',
    discoverTime: '2025-04-12 08:00',
    reportTime: '2025-04-12 09:00',
    deadline: '2025-04-25',
    addvcd: '430104000000',
    regionName: '长沙市岳麓区',
    location: '湘江长沙岳麓段指定敏感岸线（坐标待核实）',
    longitude: '112.965400',
    latitude: '28.200100',
    situationDescribe: '上级平台下发卫星疑似堆砂图斑，要求县级现场核查并反馈。',
    impactScope: '待现场界定，涉及河道管理范围',
    severity: '一般',
    reporterName: '市河长办值班',
    reporterPhone: '0731-88×××××',
    handleStatus: '已办结',
    responsibleOrg: '岳麓区水利局、区城管执法大队',
    leaderName: '区级河长办副主任',
    preemptDisposal: '否',
    disposalProgress: '现场核查未发现新增堆砂，图斑为历史整治回填区',
    measuresTaken: '无人机复核；调阅采砂许可与巡查记录；形成书面核查报告',
    handlingProcess: '接办→联合执法现场踏勘→无人机复核→调档比对→出具核查报告→平台闭环。',
    coordParties: '省平台技术支撑单位',
    disposalResult: '结论为不属实（历史已处置），已平台上报闭环',
    feedbackComment: '省平台：同意结案，保留图斑年度复核。',
    finishDate: '2025-04-18',
    disposal: {
      disposalLeader: '联合核查组组长',
      contactPhone: '0731-88×××××',
      disposalDescribe: '附件含现场照片与核查报告编号',
      completedTime: '2025-04-18 16:30',
      images: [],
    },
  },
];
